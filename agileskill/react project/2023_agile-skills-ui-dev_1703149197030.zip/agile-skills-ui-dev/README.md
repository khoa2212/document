# AgileSkills-UI Project

This project was created with `create-react-app`.

## Running the application

1.Install the necessary dependencies

npm install

2.You can run your project by using these modes:

Local mode:
npm run start:local

Dev mode:
npm run start:dev

Test Mode:
npm run start:test

The project will automatically open a new web page on your browser.

In case you need to open it manually, the page is at
http://localhost:3000

The page will automatically update as you edit the files.

## Dependencies

`react`: 18.2.0
