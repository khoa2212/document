//Skill constants
export const MAX_SKILL_DESCRIPTION_CHAR = 2000;
export const MAX_SKILL_DESCRIPTION_LINE = 5;
export const MAX_SKILL_NAME_LENGTH = 255;

//Topic constants
export const MAX_TOPIC_DESCRIPTION_LENGTH = 2000;
export const MAX_TOPIC_DESCRIPTION_LINE = 5;
export const MAX_TOPIC_NAME_LENGTH = 255;
export const MIN_TOPIC_NAME_LENGTH = 3;

//Require array
export const REQUIRE_ARRAY = [
  { value: "MUST_HAVE", label: "Must have" },
  { value: "NICE_TO_HAVE", label: "Nice to have" },
];

//Level array
export const LEVEL_ARRAY = [
  { value: "MASTER", label: "Master" },
  { value: "USED", label: "Used" },
  { value: "LEARNED", label: "Learned" },
];

//String constants
export const MAX_STRING_LENGTH = 20;
