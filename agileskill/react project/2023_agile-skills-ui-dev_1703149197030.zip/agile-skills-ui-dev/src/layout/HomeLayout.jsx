import React, { Fragment } from "react";
import { Outlet } from "react-router-dom";

import Header from "../components/header/Header";
import Footer from "../components/footer/Footer";

export default function HomeLayout() {
  return (
    <Fragment>
      <Header />
      <div id="home-children">
        <Outlet />
      </div>
      <Footer />
    </Fragment>
  );
}
