import { request } from "../config/Http-common";

class GraphService {
  getGraphByPositionId(positionId) {
    return request({
      url: `/graphs?positionId=${positionId}`,
      method: "GET",
    });
  }

  save(data) {
    return request({
      url: `graphs`,
      method: "POST",
      data,
    });
  }

  delete(positionId) {
    return request({
      url: `graphs/${positionId}`,
      method: "DELETE",
    });
  }
}
const graphService = new GraphService();
export default graphService;
