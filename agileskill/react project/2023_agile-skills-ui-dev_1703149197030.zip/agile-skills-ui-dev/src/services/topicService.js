import { request } from "../config/Http-common";

class TopicService {
  create(data, skillId) {
    return request({
      url: `/skills/${skillId}/topics`,
      method: "POST",
      data,
    });
  }

  uploadFiles(file, skillId, topicId) {
    return request({
      url: `/skills/${skillId}/topics/${topicId}/upload`,
      method: "POST",
      data: file,
      headers: {
        "Content-Type": `multipart/form-data; boundary=${file._boundary}`,
      },
    });
  }

  getFiles(skillId, topicId) {
    return request({
      url: `/skills/${skillId}/topics/${topicId}/attachments`,
      method: "GET",
    });
  }

  downloadFile(fileName, skillId, topicId) {
    return request({
      url: `/skills/${skillId}/topics/${topicId}/download/${fileName}`,
      method: "GET",
      responseType: "arraybuffer",
    });
  }

  deleteFile(fileName, skillId, topicId) {
    return request({
      url: `/skills/${skillId}/topics/${topicId}/delete-file/${fileName}`,
      method: "DELETE",
    });
  }
}

const topicService = new TopicService();

export default topicService;
