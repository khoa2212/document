import { request } from "../config/Http-common";

class StatisticsService {
  getStatistics(year) {
    return request({
      url: `/statistics/${year}`,
      method: "GET",
    });
  }
}

const statisticsService = new StatisticsService();

export default statisticsService;
