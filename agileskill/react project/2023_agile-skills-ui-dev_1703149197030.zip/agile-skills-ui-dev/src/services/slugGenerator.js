export default function slugGenerator(str) {
  let resultString = str;
  resultString = resultString.trim();
  resultString = resultString.toLowerCase();
  let from = "àáäâèéëêìíïîòóöôùúüûñç·/_,:;";
  let to = "aaaaeeeeiiiioooouuuunc------";

  for (let i = 0, l = from.length; i < l; i++) {
    resultString = resultString.replace(
      new RegExp(from.charAt(i), "g"),
      to.charAt(i)
    );
  }

  resultString = resultString
    .replace(/\s+/g, "-") // collapse whitespace and replace by -
    .replace(/-+/g, "-"); // collapse dashes

  return resultString;
}
