import { request } from "../config/Http-common";

class TeamService {
  getActiveTeams() {
    return request({
      url: "/departments/teams",
      method: "GET",
    });
  }

  getTeamsByDepartmentId(departmentId) {
    return request({
      url: `departments/${departmentId}/teams`,
      method: "GET",
    });
  }
}
const teamService = new TeamService();
export default teamService;
