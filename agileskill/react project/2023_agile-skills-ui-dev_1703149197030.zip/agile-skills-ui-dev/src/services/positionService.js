import { request } from "../config/Http-common";

class PositionService {
  create(data) {
    return request({
      url: "/positions",
      method: "POST",
      data,
    });
  }

  getPositionList() {
    return request({
      url: "/positions",
      method: "GET",
    });
  }

  getPositionDetail(positionId) {
    return request({
      url: `/positions/${positionId}/updating`,
      method: "GET",
    });
  }

  getPositionWithRequiredSkillAndTopic(positionId) {
    return request({
      url: `/positions/${positionId}/filtered`,
      method: "GET",
    });
  }

  closePosition(positionId) {
    return request({
      url: `/positions/${positionId}`,
      method: "DELETE",
    });
  }

  search(word) {
    return request({
      url: `/positions/search?word=${word}`,
      method: "GET",
    });
  }

  update(positionId, data) {
    return request({
      url: `/positions/${positionId}`,
      method: "PUT",
      data,
    });
  }

  getYears() {
    return request({
      url: "/positions/years",
      method: "GET",
    });
  }
}

const positionService = new PositionService();

export default positionService;
