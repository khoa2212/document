import { request } from "../config/Http-common";

class SkillService {
  getAllSkills() {
    return request({
      url: "/skills",
      method: "GET",
    });
  }
  getPagedSkills(page, size) {
    return request({
      url: `/skills?page=${page}&size=${size}`,
      method: "GET",
    });
  }
  getSkill(skillId) {
    return request({
      url: `/skills/${skillId}`,
      method: "GET",
    });
  }
  getTopicBySkill(skillId) {
    return request({
      url: `/skills/${skillId}/topics`,
      method: "GET",
    });
  }
  create(data) {
    return request({
      url: `/skills`,
      method: "POST",
      data,
    });
  }
  update(data, skillId) {
    return request({
      url: `/skills/${skillId}`,
      method: "PUT",
      data,
    });
  }
  getSkillWithTopicList() {
    return request({
      url: "/skills/skills-with-topics",
      method: "GET",
    });
  }
  importSkillList(file) {
    const formData = new FormData();

    formData.append("file", file);

    return request({
      url: "/skills/upload-file",
      method: "POST",
      data: formData,
    });
  }
}
const skillService = new SkillService();
export default skillService;
