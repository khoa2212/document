import { request } from "../config/Http-common";

class DepartmentService {
    getActiveDepartments() {
        return request({
          url: "/departments",
          method: "GET",
        });
      }
}
const departmentService = new DepartmentService();
export default departmentService;