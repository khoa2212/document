import jwt_decode from "jwt-decode";

import { request } from "../config/Http-common";

class AuthService {
  async login(data) {
    return request({
      url: "/auth/login",
      method: "POST",
      data,
    }).then((response) => {
      if (response.data.token) {
        let token = response.data.token;
        window.localStorage.setItem("token", JSON.stringify(token));
      }
    });
  }
  getRole() {
    if (window.localStorage.getItem("token")) {
      try {
        let tokenDecoded = jwt_decode(
          JSON.parse(window.localStorage.getItem("token"))
        );
        return tokenDecoded.ROLE;
      } catch (error) {
        localStorage.removeItem("token");
      }
    }
    return null;
  }
  isTokenExpired() {
    if (window.localStorage.getItem("token")) {
      try {
        let expDate = jwt_decode(
          JSON.parse(window.localStorage.getItem("token"))
        ).exp;
        let currentDate = Date.now();
        if (expDate * 1000 - currentDate <= 0) {
          return true;
        }
      } catch (error) {
        localStorage.removeItem("token");
      }
    }
    return null;
  }
  getToken() {
    if (window.localStorage.getItem("token")) {
      try {
        jwt_decode(JSON.parse(window.localStorage.getItem("token")));
        return JSON.parse(window.localStorage.getItem("token"));
      } catch (error) {
        localStorage.removeItem("token");
      }
    }
    return null;
  }
}

const authService = new AuthService();

export default authService;
