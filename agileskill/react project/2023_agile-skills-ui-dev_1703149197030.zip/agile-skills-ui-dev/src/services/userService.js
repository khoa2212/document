import { request } from "../config/Http-common";

class UserService {
  async create(data) {
    return request({
      url: `/users`,
      method: "POST",
      data,
    });
  }

  async changePassword(data) {
    return request({
      url: `/users/change-password`,
      method: "PUT",
      data,
    });
  }
}

const userService = new UserService();
export default userService;
