import { MAX_STRING_LENGTH } from "../constants/common";

export function reduceFilename(name) {
  if (name.length <= MAX_STRING_LENGTH) {
    return name;
  } else {
    return name.substring(0, MAX_STRING_LENGTH) + "...";
  }
}
