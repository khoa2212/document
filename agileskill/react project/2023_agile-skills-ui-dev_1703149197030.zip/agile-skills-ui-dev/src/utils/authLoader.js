import { redirect } from "react-router-dom";
import authService from "../services/authService";

export function checkLoggedInLoader() {
  const token = authService.getToken();
  if (token !== null) {
    return redirect("/");
  }
  return null;
}

export function checkExpiredToken() {
  return authService.isTokenExpired();
}

export function checkRegisteredUserLoader() {
  const token = authService.getToken();
  if (token === null) {
    return redirect("/access-denied");
  } else if (token && authService.isTokenExpired()) {
    localStorage.removeItem("token");
    return redirect("/");
  }
  return null;
}

export function checkAdminLoader() {
  const role = authService.getRole();
  if (role && role !== "ROLE_ADMIN") {
    return redirect("/access-denied");
  }
  return null;
}
