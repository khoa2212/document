import { Row } from "react-bootstrap";
import { Link } from "react-router-dom";

export default function SkillItem(props) {
  const { skill } = props;
  const base64Id = btoa(skill.id);

  return (
    <Row className="skill-item mt-2">
      <Link to={`/skills/${base64Id}`}>
        <h3 className="skill-name">{skill.name}</h3>
      </Link>
      <p className="skill-description">{skill.description}</p>
    </Row>
  );
}
