import logo from "../../assets/images/logo.png";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <div id="footer">
      <img id="logo" src={logo} alt="Logo Axon Active Vietnam" />
      <p id="copyright">
        &#169; Copyright {year}. AXON ACTIVE VIETNAM. All Rights Reserved.
      </p>
      <p id="version">version 1.0.0</p>
    </div>
  );
}
