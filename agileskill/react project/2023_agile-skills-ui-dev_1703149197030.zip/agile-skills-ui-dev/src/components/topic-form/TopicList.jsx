import React, { Fragment, useEffect } from "react";

import deleteIcon from "../../assets/images/trash.svg";
import addIcon from "../../assets/images/plus-square.svg";
import {
  MAX_TOPIC_DESCRIPTION_LENGTH,
  MAX_TOPIC_DESCRIPTION_LINE,
  MAX_TOPIC_NAME_LENGTH,
} from "../../constants/common";
import { Field, FieldArray } from "formik";

export default function TopicList(props) {
  const { values, errors, setFieldValue } = props.formik;
  const { isUpdatingSkill } = props.isUpdatingSkill;

  useEffect(() => {
    const topicDescriptionTextareaList =
      document.getElementsByClassName(`topic-description`);

    const topicDescriptionList = Array.from(topicDescriptionTextareaList);

    topicDescriptionList.forEach((ele) => {
      if (ele.value.length <= MAX_TOPIC_DESCRIPTION_LENGTH) {
        ele.style.height = "auto";

        const lineHeight = parseInt(getComputedStyle(ele).lineHeight);
        const lines = Math.ceil(ele.scrollHeight / lineHeight);

        if (lines > MAX_TOPIC_DESCRIPTION_LINE) {
          ele.style.height = `${4.5 * lineHeight}px`;
          ele.style.overflowY = "auto";
        } else {
          ele.style.height = `${(lines - 0.5) * lineHeight}px`;
        }
      }
    });
  }, []);

  const handleTextareaChange = (e, name, topicIndex) => {
    e.preventDefault();

    const textarea =
      document.getElementsByClassName(`topic-description`)[topicIndex];

    const { value } = e.target;

    if (value.length <= MAX_TOPIC_DESCRIPTION_LENGTH) {
      setFieldValue(name, value);

      textarea.style.height = "auto";

      const lineHeight = parseInt(getComputedStyle(textarea).lineHeight);
      const lines = Math.ceil(textarea.scrollHeight / lineHeight);

      if (lines > MAX_TOPIC_DESCRIPTION_LINE) {
        textarea.style.height = `${4.5 * lineHeight}px`;
        textarea.style.overflowY = "auto";
      } else {
        textarea.style.height = `${(lines - 0.5) * lineHeight}px`;
      }
    }
  };

  const handleAddTopic = (e, push) => {
    e.preventDefault();

    const addedTopic = {
      name: "",
      description: "",
    };

    push(addedTopic);
  };

  return (
    <div id="new-topic">
      <FieldArray name="topicList">
        {({ push, remove }) => (
          <Fragment>
            <ol className="topic-list">
              {values?.topicList.length > 0 &&
                values.topicList.map((topic, topicIndex) => {
                  return (
                    <li key={topicIndex} className="topic-number">
                      <div className="topic">
                        <div className="topic-form">
                          <div className="topic-name-wrapper">
                            <Field
                              className="topic-name"
                              placeholder="Topic Name"
                              maxLength={MAX_TOPIC_NAME_LENGTH}
                              name={`topicList.${topicIndex}.name`}
                              value={topic.name}
                              autoFocus={
                                !isUpdatingSkill &&
                                (values.name !== "" ||
                                  values.topicList.length >= 2 ||
                                  values.topicList[0]?.name !== "" ||
                                  values.topicList[0]?.description !== "")
                              }
                            />
                            <button
                              className="delete-button"
                              type="button"
                              onClick={() => remove(topicIndex)}
                            >
                              <img src={deleteIcon} alt="Delete" />
                            </button>
                            {errors.topicList &&
                              errors.topicList[`${topicIndex}`] &&
                              errors.topicList[`${topicIndex}`].name &&
                              topic.name !== "" && (
                                <div className="topic-verified">
                                  {errors.topicList[`${topicIndex}`].name}
                                </div>
                              )}
                          </div>
                          <textarea
                            className="topic-description"
                            style={{ borderRadius: "none" }}
                            name={`topicList.${topicIndex}.description`}
                            value={topic.description}
                            maxLength={MAX_TOPIC_DESCRIPTION_LENGTH}
                            rows={2}
                            placeholder="Topic Description"
                            onChange={(e) =>
                              handleTextareaChange(
                                e,
                                `topicList.${topicIndex}.description`,
                                topicIndex
                              )
                            }
                          />
                        </div>
                      </div>
                    </li>
                  );
                })}
            </ol>
            <button
              id="add-button"
              type="button"
              onClick={(e) => {
                handleAddTopic(e, push);
              }}
            >
              <img src={addIcon} alt="Add" />
            </button>
          </Fragment>
        )}
      </FieldArray>
    </div>
  );
}
