import React from "react";

export default function PositionForm(props) {
  const { values, setValues, errors, touched, handleBlur } = props.formik;

  // Constants
  const MAX_POSITION_NAME_LENGTH = 255;
  const MAX_POSITION_NOTE_CHAR = 2000;
  const MAX_POSITION_NOTE_LINE = 5;

  const handleInputChange = (e) => {
    setValues({ ...values, name: e.target.value });
  };

  const handleTextareaChange = (e) => {
    const textarea = document.getElementById(`position-note`);

    const { value } = e.target;

    if (value.length <= MAX_POSITION_NOTE_CHAR) {
      setValues({ ...values, note: value });

      textarea.style.height = "auto";

      const lineHeight = parseInt(getComputedStyle(textarea).lineHeight);
      const lines = Math.ceil(textarea.scrollHeight / lineHeight);

      if (lines > MAX_POSITION_NOTE_LINE) {
        textarea.style.height = `${4.5 * lineHeight}px`;
        textarea.style.overflowY = "auto";
      } else {
        textarea.style.height = `${(lines - 0.5) * lineHeight}px`;
      }
    }
  };

  return (
    <div id="position-form">
      <div>
        <input
          className="px-2"
          id="position-name"
          name="name"
          type="text"
          placeholder="Position Name"
          maxLength={MAX_POSITION_NAME_LENGTH}
          onChange={handleInputChange}
          onBlur={handleBlur}
          value={values.name}
        />
      </div>
      {errors.name && touched.name && (
        <span className="position-verified">
          {errors.name}
          <br />
        </span>
      )}
      <textarea
        className="position-note px-2"
        id="position-note"
        name="note"
        rows={3}
        placeholder="Note"
        maxLength={MAX_POSITION_NOTE_CHAR}
        onChange={handleTextareaChange}
        value={values.note}
      />
    </div>
  );
}
