import React, { useState } from "react";
import { Dropdown } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";

export default function HeaderDropDown(props) {
  const navItem = props.navItem;
  const navItemList = props.navItemList;

  const navigate = useNavigate();
  const location = useLocation();
  const [isShow, setIsShow] = useState(false);

  const handleHover = () => {
    setIsShow(!isShow);
  };

  const handleDropdownNavClick = (item) => {
    navigate(item.path, {
      state: { prevPath: location.pathname },
    });
    setIsShow(!isShow);
  };

  const renderNavDropdown = () => {
    return navItemList.map((item) => {
      return (
        item.render && (
          <Dropdown.Item
            key={item.id}
            onClick={() => handleDropdownNavClick(item)}
          >
            {item.name}
          </Dropdown.Item>
        )
      );
    });
  };

  return (
    <li
      key={navItem.id}
      className="nav-dropdown"
      onMouseEnter={() => handleHover()}
      onMouseLeave={() => handleHover()}
    >
      <Dropdown className="dropdown-button" show={isShow}>
        <Dropdown.Toggle className="custom-dropdown">
          {navItem.name}
        </Dropdown.Toggle>
        <Dropdown.Menu className="dropdown-menu">
          {isShow && renderNavDropdown()}
        </Dropdown.Menu>
      </Dropdown>
    </li>
  );
}
