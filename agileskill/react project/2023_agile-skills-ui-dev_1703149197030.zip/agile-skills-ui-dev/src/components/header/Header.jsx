import React, { Fragment, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";  

import headerLogo from "../../assets/images/headerLogo.png";
import authService from "../../services/authService";
import HeaderDropDown from "./HeaderDropDown";

export default function Header() {
  const navigate = useNavigate();
  const location = useLocation();

  const [path, setPath] = useState();
  const [role, setRole] = useState(null);

  const getRoleFromLocalStorage = () => {
    return authService.getRole();
  };

  useEffect(() => {
    setPath(location.pathname);
  }, [location.pathname]);

  useEffect(() => {
    if (!authService.isTokenExpired() && getRoleFromLocalStorage !== null) {
      setRole(getRoleFromLocalStorage);
    } else {
      setRole(null);
      localStorage.removeItem("token");
    }
  }, [role, getRoleFromLocalStorage]);

  const isAdmin = role && role.includes("ROLE_ADMIN");

  const isRegisteredUser =
    role?.includes("ROLE_ADMIN") || role?.includes("ROLE_USER") ? true : false;

  const navItemList = [
    {
      id: 1,
      name: "Positions",
      path: "/positions",
      render: true,
    },
    { id: 2, name: "Skills List", path: "/skills-list", render: true },
    { id: 3, name: "About", path: "/about", render: true },
    { id: 4, name: "Statistic", path: "/statistic", render: isRegisteredUser },
    { id: 5, name: "Configure", path: "/configure", render: isRegisteredUser },
  ];

  const configureNavItemList = [
    {
      id: 6,
      name: "New Position",
      path: "/new-position",
      render: isRegisteredUser,
    },
    { id: 7, name: "New Skill", path: "/new-skill", render: isRegisteredUser },
    { id: 11, name: "New User", path: "/new-user", render: isAdmin },
    {
      id: 8,
      name: "Import Data",
      path: "/import-data",
      render: isRegisteredUser,
    },
    {
      id: 9,
      name: "Department/Team",
      path: "/department-team",
      render: isRegisteredUser,
    },
    { id: 10, name: "Manage User", path: "/manage-user", render: isAdmin },
    {
      id: 12,
      name: "Change Password",
      path: "/change-password",
      render: isRegisteredUser,
    },
  ];

  const positionNavItemList = [
    {
      id: 13,
      name: "Open Positions",
      path: "/open-positions",
      render: true,
    },
    {
      id: 14,
      name: "Relation Graph",
      path: "/relation-graphs",
      render: true,
    },
  ];

  const handleHeaderNavClick = (item) => {
    navigate(item.path, {
      state: { prevPath: location.pathname },
    });
  };

  const handleLogout = () => {
    setRole(null);
    navigate("/");
    localStorage.removeItem("token");
    localStorage.removeItem("role");
  };

  const renderNavItem = () => {
    return navItemList.map((navItem) => {
      if (navItem.render) {
        switch (navItem.name) {
          case "Configure":
            return (
              <Fragment key={navItem.id}>
                <HeaderDropDown
                  navItem={navItem}
                  navItemList={configureNavItemList}
                />
              </Fragment>
            );

          case "Positions":
            return (
              <Fragment key={navItem.id}>
                <HeaderDropDown navItem={navItem} navItemList={positionNavItemList} />
              </Fragment>
            );

          default:
            return (
              <li
                key={navItem.id}
                onClick={() => handleHeaderNavClick(navItem)}
                className={`${path === navItem.path ? "active" : ""}`}
              >
                {navItem.name}
              </li>
            );
        }
      }
    });
  };

  return (
    <div id="header">
      <div className="header-content">
        <div className="header-logo link">
          <img
            src={headerLogo}
            alt="logo"
            onClick={() => {
              navigate("/");
            }}
          />
        </div>
        <div
          className="header-navigator link"
          onClick={() => {
            navigate("/");
          }}
        >
          <p id="agile-skills">AgileSkills</p>
          <p id="condense-guideline">Condensed Skill guideline</p>
        </div>
        <div className="header-items">
          <nav>
            <ul className="render-navitem">{renderNavItem()}</ul>
          </nav>
        </div>
        <div className="header-login-logout link">
          {role !== null ? (
            <button id="logout" onClick={handleLogout}>
              Logout
            </button>
          ) : (
            <button id="login" onClick={() => navigate("/log-in")}>
              Login
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
