import React, { useEffect } from "react";

import {
  MAX_SKILL_DESCRIPTION_CHAR,
  MAX_SKILL_DESCRIPTION_LINE,
  MAX_SKILL_NAME_LENGTH,
} from "../../constants/common";
import { Field } from "formik";

export default function SkillForm(props) {
  const { values, setValues, errors, touched, handleBlur } = props.formik;
  const { errorKey, setErrorKey } = props.error;
  const { isUpdatingSkill } = props.isUpdatingSkill;

  useEffect(() => {
    const skillDescriptionTextareaList =
      document.getElementsByClassName(`skill-description`);

    const skillDescriptionList = Array.from(skillDescriptionTextareaList);

    skillDescriptionList.forEach((ele) => {
      if (ele.value.length <= MAX_SKILL_DESCRIPTION_CHAR) {
        ele.style.height = "auto";

        const lineHeight = parseInt(getComputedStyle(ele).lineHeight);
        const lines = Math.ceil(ele.scrollHeight / lineHeight);

        if (lines > MAX_SKILL_DESCRIPTION_LINE) {
          ele.style.height = `${4.5 * lineHeight}px`;
          ele.style.overflowY = "auto";
        } else {
          ele.style.height = `${(lines - 0.5) * lineHeight}px`;
        }
      }
    });
  }, []);

  const handleInputChange = (e) => {
    setValues({ ...values, name: e.target.value });
    setErrorKey(null);
  };

  const handleTextareaChange = (e) => {
    const textarea = document.getElementById(`skill-description`);
    const { value } = e.target;

    if (value.length <= MAX_SKILL_DESCRIPTION_CHAR) {
      setValues({ ...values, description: value });
      textarea.style.height = "auto";
      const lineHeight = parseInt(getComputedStyle(textarea).lineHeight);
      const lines = Math.ceil(textarea.scrollHeight / lineHeight);

      if (lines > MAX_SKILL_DESCRIPTION_LINE) {
        textarea.style.height = `${4.5 * lineHeight}px`;
        textarea.style.overflowY = "auto";
      } else {
        textarea.style.height = `${(lines - 0.5) * lineHeight}px`;
      }
    }
  };

  return (
    <div id="new-skill">
      <Field
        id="skill-name"
        className="ps-1"
        name="name"
        placeholder="Skill Name"
        maxLength={MAX_SKILL_NAME_LENGTH}
        value={values.name}
        onChange={handleInputChange}
        onBlur={handleBlur}
        autoFocus={isUpdatingSkill}
      />
      {touched.name && errors.name && (
        <div id="skill-duplicate">{errors.name}</div>
      )}
      {errorKey === "exception.input.validation.skill.already.existed" && (
        <div id="skill-duplicate">That skill name is existed. Try another.</div>
      )}
      <Field
        as="textarea"
        className="skill-description"
        id="skill-description"
        name="description"
        rows={3}
        value={values.description}
        placeholder="Skill Description"
        maxLength={MAX_SKILL_DESCRIPTION_CHAR}
        onChange={handleTextareaChange}
      />
    </div>
  );
}
