import React, { useState } from "react";
import { Row, Button, Modal, Toast, ToastContainer } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";

import userService from "../../services/userService";
import closeIcon from "../../assets/images/close.svg";
import saveIcon from "../../assets/images/save.svg";
import hidePasswordIcon from "../../assets/images/hide-password.png";
import showPasswordIcon from "../../assets/images/show-password.png";

export default function NewUser() {
  const location = useLocation();
  const from = location.state?.prevPath || "/";
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmedPassword, setConfirmedPassword] = useState("");

  const [show, setShow] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [successful, setSuccessful] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [isPasswordMatch, setIsPasswordMatch] = useState(true);
  const [isEmailDuplicated, setIsEmailDuplicated] = useState(false);
  const [isEmailBlank, setIsEmailBlank] = useState(false);
  const [isValidPassword, setIsValidPassword] = useState(true);
  const [isEmailValid, setIsEmailValid] = useState(true);
  const [isNameValid, setIsNameValid] = useState(true);

  const handleError = (errorResponse) => {
    errorResponse.forEach((errorItem) => {
      switch (errorItem.errorKey) {
        case "exception.input.validation.email.wrong.format":
          setIsEmailValid(false);
          break;

        case "exception.input.validation.user.already.existed":
          setIsEmailDuplicated(true);
          break;

        case "exception.input.validation.email.blank.or.null":
          setIsEmailBlank(true);
          break;

        case "exception.input.validation.password.not.match.pattern":
          setIsValidPassword(false);
          break;

        case "exception.input.validation.user.name.over.max.length":
          setIsNameValid(false);
          break;

        case "exception.input.validation.password.blank.or.null":
          setIsValidPassword(false);
          break;

        default:
          setSuccessful(false);
          break;
      }
    });
  };

  const createUser = async () => {
    if (confirmedPassword !== password) {
      setIsPasswordMatch(false);
      setConfirmedPassword("");
    } else {
      try {
        const userName =
          name.trim() === "" ? email.trim().split("@")[0] : name.trim();
        const userEmail = email.trim();
        const encodedPassword = btoa(password);
        await userService.create({
          name: userName,
          email: userEmail,
          password: encodedPassword,
        });

        setShowToast(true);
        setSuccessful(true);
        setTimeout(() => {
          navigate(from);
        }, 1000);
      } catch (error) {
        const errorResponse = error.response.data;
        if (Array.isArray(errorResponse)) {
          handleError(errorResponse);
        } else {
          switch (error.response.data.errorKey) {
            case "exception.input.validation.user.already.existed":
              setIsEmailDuplicated(true);
              break;

            case "exception.input.validation.password.not.match.pattern":
              setIsValidPassword(false);
              break;
          }
        }
      }
    }
  };

  const handleNameChange = (e) => {
    e.preventDefault();
    setIsNameValid(true);
    setName(e.target.value);
  };

  const handleEmailChange = (e) => {
    e.preventDefault();
    setIsEmailBlank(false);
    setIsEmailDuplicated(false);
    setIsEmailValid(true);
    setEmail(e.target.value.trim());
  };

  const handlePasswordChange = (e) => {
    e.preventDefault();
    setIsValidPassword(true);
    setPassword(e.target.value);
  };

  const handleConfirmedPasswordChange = (e) => {
    e.preventDefault();
    setIsPasswordMatch(true);
    setConfirmedPassword(e.target.value);
  };

  const handleCloseButton = () => {
    if (
      name.trim() === "" &&
      email.trim() === "" &&
      password.trim() === "" &&
      confirmedPassword.trim() === ""
    ) {
      navigate(from);
    } else {
      setShow(true);
    }
  };

  const handleClose = () => setShow(false);

  const cancelField = () => {
    setName("");
    setEmail("");
    setPassword("");
    setConfirmedPassword("");
    navigate(from);
    setShow(false);
  };

  const handleTogglePassword = () => {
    setShowPassword(!showPassword);
  };

  const handleVerifyEmailWhenLostFocus = () => {
    const emailPattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (email.trim() === "") {
      setIsEmailBlank(true);
    } else if (!emailPattern.test(email)) {
      setIsEmailValid(false);
    }
  };

  const handlePasswordWhenLostFocus = () => {
    if (!/\d/.test(password) || password.length < 6) {
      setIsValidPassword(false);
    }
  };
  const handleRetypePasswordWhenLostFocus = () => {
    if (password !== confirmedPassword) {
      setIsPasswordMatch(false);
    }
  };

  return (
    <div className="new-user-page">
      <ToastContainer id="toast-container" className="p-3">
        <Toast
          onClose={() => setShowToast(false)}
          show={showToast}
          delay={2500}
          autohide
        >
          <Toast.Body className={successful ? "bg-success" : "bg-danger"}>
            {successful ? "Create successfully!" : "Please try again!"}
          </Toast.Body>
        </Toast>
      </ToastContainer>
      <div className="new-user-container">
        <Row className="new-user-title">
          <h3>New User</h3>
        </Row>
        <Row className="new-user-buttons">
          <Button className="save-button" onClick={createUser}>
            <img src={saveIcon} alt="Save" />
          </Button>
          <Button className="close-button" onClick={handleCloseButton}>
            <img src={closeIcon} alt="Close" />
          </Button>
        </Row>
        <form className="new-user-form">
          <Row className="new-user-row">
            <label className="user-label">Name</label>
            <div className="input-wrapper">
              <input
                className="user-textbox"
                type="text"
                name="name"
                value={name}
                onChange={handleNameChange}
                placeholder={email.split("@")[0]}
              />
              {!isNameValid && (
                <span className="name-verified">Name is too long!</span>
              )}
            </div>
          </Row>
          <Row className="new-user-row">
            <label className="user-label">
              Email<b className="ps-2 text-danger">*</b>
            </label>
            <div className="input-wrapper">
              <input
                className="user-textbox"
                type="text"
                name="email"
                value={email}
                autoComplete="username"
                onChange={handleEmailChange}
                onBlur={handleVerifyEmailWhenLostFocus}
              />
              {isEmailBlank && (
                <span className="email-verified">Email is required!</span>
              )}
              {isEmailDuplicated && (
                <span className="email-verified">
                  This email address is existed. Try another.
                </span>
              )}
              {!isEmailValid && (
                <span className="email-verified">
                  Email address doesn't have right format. Try another.
                </span>
              )}
            </div>
            <label className="user-label"></label>
          </Row>

          <Row className="new-user-row">
            <label className="user-label" htmlFor="password">
              Password<b className="ps-2 text-danger">*</b>
            </label>
            <div className="input-wrapper">
              <input
                className="user-textbox"
                type={showPassword ? "text" : "password"}
                name="password"
                aria-describedby="passwordHelpBlock"
                value={password}
                autoComplete="new-password"
                onChange={handlePasswordChange}
                onBlur={handlePasswordWhenLostFocus}
              />
              {password && (
                <Button className="eye-button" onClick={handleTogglePassword}>
                  {showPassword ? (
                    <img src={hidePasswordIcon} alt="Hide Password" />
                  ) : (
                    <img src={showPasswordIcon} alt="Show Password" />
                  )}
                </Button>
              )}
              {!isValidPassword && (
                <span className="password-valid">
                  Password is not valid. Try again.
                </span>
              )}
            </div>
          </Row>
          <Row className="new-user-row">
            <div className="user-label"></div>
            <div className="input-wrapper">
              <input
                className="user-textbox"
                type={showPassword ? "text" : "password"}
                name="confirmedPassword"
                aria-describedby="passwordHelpBlock"
                placeholder="Re-enter password"
                value={confirmedPassword}
                autoComplete="new-password"
                onChange={handleConfirmedPasswordChange}
                onBlur={handleRetypePasswordWhenLostFocus}
              />
              {confirmedPassword && (
                <Button
                  className="eye-button eye-button-confirm"
                  onClick={handleTogglePassword}
                >
                  {showPassword ? (
                    <img src={hidePasswordIcon} alt="Hide Password" />
                  ) : (
                    <img src={showPasswordIcon} alt="Show Password" />
                  )}
                </Button>
              )}
              {!isPasswordMatch && (
                <span className="password-valid">
                  Those passwords didn't match. Try again.
                </span>
              )}
            </div>
          </Row>
          <span id="passwordHelpBlock" muted>
            (Password must be more than 5 characters and have at least 1 number)
          </span>
        </form>
        <Modal show={show} onHide={handleClose}>
          <Modal.Header className="modal-header">
            <Modal.Title className="modal-title">Unsaved changes</Modal.Title>
          </Modal.Header>
          <Modal.Body className="modal-body">
            Are you sure you want to discard changes?
          </Modal.Body>
          <Modal.Footer className="modal-footer">
            <Button id="skill-cancel" onClick={handleClose}>
              Cancel
            </Button>
            <Button id="skill-discard" onClick={cancelField}>
              Discard
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </div>
  );
}
