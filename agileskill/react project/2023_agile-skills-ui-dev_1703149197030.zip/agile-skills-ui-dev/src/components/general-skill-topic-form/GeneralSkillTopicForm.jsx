import { Formik, Form as FormikForm } from "formik";
import React, { useContext, useState } from "react";
import { Button, Container, Modal } from "react-bootstrap";
import { object, string, array } from "yup";
import { useLocation, useNavigate } from "react-router-dom";

import skillService from "../../services/skillService";
import SkillForm from "../skill-form/SkillForm";
import saveIcon from "../../assets/images/save.svg";
import closeIcon from "../../assets/images/close.svg";
import ToastContext from "../../context/ToastContext";
import TopicList from "../topic-form/TopicList";

export default function GeneralSkillTopicForm(props) {
  const isUpdatingSkill = Object.keys(props).length > 0;

  const skillDetails = isUpdatingSkill && props.skillFullDetails.skillDetails;
  const topicList = isUpdatingSkill && props.skillFullDetails.topicList;
  const skillIdBase64 = isUpdatingSkill && props.skillFullDetails.skillIdBase64;

  const [errorKey, setErrorKey] = useState(null);

  const initialSkill = isUpdatingSkill
    ? {
        name: skillDetails?.name,
        description: skillDetails?.description,
        topicList: topicList,
      }
    : {
        name: "",
        description: "",
        topicList: [
          {
            name: "",
            description: "",
          },
        ],
      };

  const navigate = useNavigate();
  const toastContext = useContext(ToastContext);
  const location = useLocation();
  const from = location.state?.prevPath || "/";
  const [showModal, setShowModal] = useState(false);

  const skillValidation = object().shape({
    name: string().trim().max(255).required("Skill name is required!"),
    description: string().trim().max(2000),
    topicList: array()
      .of(
        object().shape({
          name: string()
            .trim()
            .test(
              "min",
              "Topic name must be more than 2 characters!",
              function (value) {
                if (value && value.trim().length > 0) {
                  return value.trim().length >= 3;
                }
                return true;
              }
            )
            .max(255),
          description: string().trim().max(2000),
        })
      )
      .test({
        test: function (topicList) {
          const topicNames = [];
          for (const topic of topicList) {
            if (
              topicNames.some(
                (name) => name.toLowerCase() === topic.name?.toLowerCase()
              )
            ) {
              return this.createError({
                path: `topicList[${topicList.indexOf(topic)}].name`,
                message: "Duplicated topic name!",
              });
            }
            if (topic.name?.length > 0) {
              topicNames.push(topic.name.toLowerCase());
            }
          }
          return true;
        },
      }),
  });

  const handleCreateSkill = async (values, setSubmitting) => {
    let submitData = {
      name: values.name?.trim(),
      description: values.description?.trim(),
      topicList: values.topicList
        ? values.topicList.filter((topic) => topic.name.trim().length > 0)
        : [],
    };

    try {
      if (isUpdatingSkill) {
        await skillService.update(submitData, skillDetails.id);
        toastContext.setToastState({
          actionState: true,
          showToast: true,
          message: "Update successfully!",
        });

        navigate(`/skills/${skillIdBase64}`);
        setSubmitting(false);
      } else {
        await skillService.create(submitData);
        toastContext.setToastState({
          actionState: true,
          showToast: true,
          message: "Create successfully!",
        });

        navigate(`/skills-list`);
        setSubmitting(false);
      }
    } catch (error) {
      setSubmitting(false);
      setErrorKey(error.response.data.errorKey);
      const errorResponse = error.response.data;

      if (
        errorResponse.errorKey ===
        "exception.input.validation.skill.already.existed"
      ) {
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Please try again!",
        });
      }
    }
  };

  const handleCancelCreateSkill = (values) => {
    if (
      values.name.trim().length === 0 &&
      values.description.trim().length === 0 &&
      values.topicList.length === 0
    ) {
      navigate(from);
    } else {
      setShowModal(true);
    }
  };

  const handleDiscardChanges = (resetForm) => {
    resetForm();
    setShowModal(false);
    navigate(from);
  };

  return (
    <Container>
      <div id="new-skill-container">
        <Formik
          initialValues={initialSkill}
          validationSchema={skillValidation}
          onSubmit={(values, { setSubmitting }) => {
            handleCreateSkill(values, setSubmitting);
          }}
        >
          {({
            values,
            setValues,
            errors,
            resetForm,
            isSubmitting,
            touched,
            handleBlur,
            setFieldValue,
          }) => (
            <FormikForm id="new-skill-form">
              <div id="new-skill-container">
                <div className="skill-title d-flex justify-content-between pe-2">
                  {isUpdatingSkill ? <h3>Edit Skill</h3> : <h3>New Skill</h3>}
                  <div>
                    <div className="skill-buttons">
                      <button
                        id="save-button"
                        type="submit"
                        disabled={isSubmitting}
                      >
                        <img src={saveIcon} alt="Save" />
                      </button>
                      <button
                        id="close-button"
                        type="button"
                        onClick={() => handleCancelCreateSkill(values)}
                      >
                        <img src={closeIcon} alt="Close" />
                      </button>
                    </div>
                  </div>
                </div>
                <SkillForm
                  formik={{ values, setValues, errors, touched, handleBlur }}
                  error={{ errorKey, setErrorKey }}
                  isUpdatingSkill={{ isUpdatingSkill }}
                />
                <TopicList
                  formik={{ values, errors, setFieldValue }}
                  isUpdatingSkill={{ isUpdatingSkill }}
                />
              </div>
              <Modal show={showModal} onHide={() => setShowModal(false)}>
                <Modal.Header className="modal-header">
                  <Modal.Title className="modal-title">
                    Unsaved changes
                  </Modal.Title>
                </Modal.Header>
                <Modal.Body className="modal-body">
                  Are you sure you want to discard changes?
                </Modal.Body>
                <Modal.Footer className="modal-footer">
                  <Button id="skill-cancel" onClick={() => setShowModal(false)}>
                    Cancel
                  </Button>
                  <Button
                    id="skill-discard"
                    onClick={() => handleDiscardChanges(resetForm)}
                  >
                    Discard
                  </Button>
                </Modal.Footer>
              </Modal>
            </FormikForm>
          )}
        </Formik>
      </div>
    </Container>
  );
}
