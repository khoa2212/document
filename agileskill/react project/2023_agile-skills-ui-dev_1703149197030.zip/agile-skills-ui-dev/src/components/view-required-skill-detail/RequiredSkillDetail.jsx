import React, { Fragment } from "react";
import checkIcon from "../../assets/images/check-mark.png";
import RequiredTopicDetail from "./RequiredTopicDetail";

export default function RequiredSkillDetail(props) {
  const requiredSkillList = props.position.requiredSkillList;

  return (
    <table id="table-required-skill">
      <thead>
        <tr>
          <th rowSpan="2" className="table-skill">
            Skills/Topics
          </th>
          <th rowSpan="2">Require?</th>
          <th colSpan="3" className="table-level">
            Level
          </th>
          <th rowSpan="2" className="table-note">
            Note
          </th>
        </tr>
        <tr>
          <th className="master-th">
            3 <br /> Master
          </th>
          <th className="used-th">
            2 <br /> Used
          </th>
          <th className="learned-th">
            1 <br /> Learned
          </th>
        </tr>
      </thead>

      <tbody>
        {requiredSkillList &&
          requiredSkillList.map((requiredSkill) => (
            <Fragment key={requiredSkill.id}>
              <tr className="table-skill-data">
                <td>
                  <h5 className="skill-name">{requiredSkill.skillName}</h5>
                </td>
                <td rowSpan="2" className="require-td">
                  {requiredSkill.require === "MUST_HAVE"
                    ? "Must have"
                    : requiredSkill.require === "NICE_TO_HAVE"
                    ? "Nice to have"
                    : ""}
                </td>
                <td rowSpan="2" className="level-td">
                  {requiredSkill.level === "MASTER" ? (
                    <img src={checkIcon} alt="check-icon" />
                  ) : (
                    ""
                  )}
                </td>
                <td rowSpan="2" className="level-td">
                  {requiredSkill.level === "USED" ? (
                    <img src={checkIcon} alt="check-icon" />
                  ) : (
                    ""
                  )}
                </td>
                <td rowSpan="2" className="level-td">
                  {requiredSkill.level === "LEARNED" ? (
                    <img src={checkIcon} alt="check-icon" />
                  ) : (
                    ""
                  )}
                </td>
                <td rowSpan="2" className="skill-note">
                  {requiredSkill.note}
                </td>
              </tr>
              <tr>
                <td className="description-td table-skill-data">
                  {requiredSkill.skillDescription}
                </td>
              </tr>
              {requiredSkill.requiredTopicList.map((requiredTopic, index) => {
                return (
                  <Fragment key={requiredTopic.id}>
                    <RequiredTopicDetail
                      skillId={requiredSkill.skillId}
                      requiredTopic={requiredTopic}
                      index={index}
                    />
                  </Fragment>
                );
              })}
            </Fragment>
          ))}
      </tbody>
    </table>
  );
}
