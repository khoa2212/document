import React, {
  Fragment,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import checkIcon from "../../assets/images/check-mark.png";
import topicService from "../../services/topicService";
import ToastContext from "../../context/ToastContext";

import { LEVEL_ARRAY } from "../../constants/common";
import { Row } from "react-bootstrap";

export default function RequiredTopicDetail(props) {
  const toastContext = useContext(ToastContext);

  const [fileList, setFileList] = useState([]);

  const skillId = props.skillId;

  const { require, level, topicName, topicDescription, note, topicId } =
    props.requiredTopic;

  const index = props.index;

  const fetchFileList = useCallback(async () => {
    const response = await topicService.getFiles(skillId, topicId);
    setFileList(response.data);
  }, []);

  const retractDateTimeSuffix = (name) => {
    let suffixIndex = name.lastIndexOf("_");
    return name.slice(0, suffixIndex);
  };

  const handleDownloadFile = async (fileName) => {
    try {
      const response = await topicService.downloadFile(
        fileName,
        skillId,
        topicId
      );

      const url = window.URL.createObjectURL(
        new Blob([response.data], {
          type: response.headers["content-type"],
        })
      );
      const link = document.createElement("a");
      link.href = url;

      link.setAttribute("download", fileName);
      document.body.appendChild(link);

      link.click();
    } catch (error) {
      let arrayBufferConverted = JSON.parse(
        String.fromCharCode.apply(null, new Uint8Array(error.response.data))
      );
      if (
        arrayBufferConverted.errorKey ==
        "exception.input.validation.file.not.found"
      ) {
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "The selected file(s) may have been deleted",
        });
      } else {
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Something went wrong. Please try again.",
        });
      }
    } finally {
      fetchFileList();
    }
  };

  useEffect(() => {
    fetchFileList();
  }, [fetchFileList]);

  return (
    <Fragment>
      <tr className="view-topic">
        <td>
          <b>
            {index + 1}.&nbsp;
            {topicName}
          </b>
        </td>
        <td rowSpan="2" className="require-td">
          {require === "MUST_HAVE"
            ? "Must have"
            : require === "NICE_TO_HAVE"
            ? "Nice to have"
            : ""}
        </td>
        {LEVEL_ARRAY.map((ele) => {
          return (
            <td key={ele.label} rowSpan="2" className="level-td">
              {level === ele.value ? (
                <img src={checkIcon} alt="check-icon" />
              ) : (
                ""
              )}
            </td>
          );
        })}
        <td rowSpan="2" className="topic-note">
          {note}
        </td>
      </tr>
      <tr className="view-topic">
        <td className="description-td">
          {topicDescription}
          {fileList?.map((fileName) => {
            let compactName = retractDateTimeSuffix(fileName);

            return (
              <Row className="file-row" key={fileName}>
                <p
                  className="file-name m-0 ps-2 ms-2"
                  onClick={() => handleDownloadFile(fileName)}
                >
                  {compactName}
                </p>
              </Row>
            );
          })}
        </td>
      </tr>
    </Fragment>
  );
}
