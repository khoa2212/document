import React, { Fragment, useCallback, useEffect, useState } from "react";

import editIcon from "../../assets/images/edit-pencil.png";
import { useNavigate } from "react-router-dom";
import authService from "../../services/authService";

export default function SkillDetails(props) {
  const skillFullDetails = props.skillFullDetails;
  const navigate = useNavigate();

  const [token, setToken] = useState(null);

  const getTokenFromLocalStorage = useCallback(() => {
    return authService.getToken();
  }, []);

  useEffect(() => {
    if (getTokenFromLocalStorage !== null) {
      setToken(getTokenFromLocalStorage);
    }
  }, [token, getTokenFromLocalStorage]);

  return (
    <Fragment>
      <div className="pt-1 skill-name d-flex justify-content-between align-items-center">
        <h3 className="mb-0">{skillFullDetails.skillDetails.name}</h3>
        {token && (
          <img
            src={editIcon}
            alt="edit-icon"
            className="img-fluid edit-button me-3"
            onClick={() =>
              navigate(`/update-skill/${skillFullDetails.skillIdBase64}`)
            }
          />
        )}
      </div>
      <p className="skill-description pt-2">
        {skillFullDetails.skillDetails.description}
      </p>
    </Fragment>
  );
}
