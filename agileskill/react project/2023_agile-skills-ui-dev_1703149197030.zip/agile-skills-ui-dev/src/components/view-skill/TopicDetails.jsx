import React, {
  createRef,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { Button, Modal, Row } from "react-bootstrap";
import { AiOutlineFileAdd } from "react-icons/ai";
import { TiDeleteOutline } from "react-icons/ti";

import topicService from "../../services/topicService";
import authService from "../../services/authService";
import ToastContext from "../../context/ToastContext";

export default function TopicDetails(props) {
  const { id, name, description } = props.topic;
  const skillId = atob(props.skillId);

  const fileInputRef = createRef();

  const [showModal, setShowModal] = useState(false);
  const [fileList, setFileList] = useState([]);
  const [token, setToken] = useState(null);

  const toastContext = useContext(ToastContext);

  const getTokenFromLocalStorage = useCallback(() => {
    return authService.getToken();
  }, []);

  useEffect(() => {
    if (getTokenFromLocalStorage !== null) {
      setToken(getTokenFromLocalStorage);
    }
  }, [token, getTokenFromLocalStorage]);

  const fetchFileList = useCallback(async () => {
    const response = await topicService.getFiles(skillId, id);
    setFileList(response.data);
  }, []);

  useEffect(() => {
    fetchFileList();
  }, [fetchFileList]);

  const packFiles = (files) => {
    const data = new FormData();
    const filesArray = files ? [...files] : [];
    filesArray.forEach((file) => {
      if (file.size > 5 * 1024 * 1024) {
        throw new Error("File(s) exceeds the maximum size allowed (5MB)");
      }
      data.append(`attachment`, file, file.name);
    });

    const totalFileSize = filesArray.reduce(
      (accumulator, currentValue) => accumulator + currentValue.size,
      0
    );

    if (totalFileSize > 5 * 1024 * 1024) {
      throw new Error("File(s) exceeds the maximum size allowed (5MB)");
    }

    return data;
  };

  const handleError = (errorKey) => {
    switch (errorKey) {
      case "exception.input.validation.attachment.name.length.over.max.length":
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Attachment Name length cannot exceed 255 characters",
        });
        break;

      case "exception.input.validation.invalid.form":
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Invalid form",
        });
        break;

      case "exception.input.validation.attachment.not.found":
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "The selected file(s) is unavailable",
        });
        break;

      case "exception.input.validation.file.size.exceed.max.allowed":
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "File(s) exceeds the maximum size allowed (5MB)",
        });
        break;

      case "exception.input.validation.path.cannot.contain.special.character":
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "File name can't contain special characters",
        });
        break;

      case "exception.input.validation.file.not.found":
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "The selected file(s) may have been deleted",
        });
        break;

      default:
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Something went wrong. Please try again.",
        });
        break;
    }
  };

  const handleUploadFiles = async (e) => {
    e.preventDefault();

    try {
      const data = packFiles(e.target.files);
      await topicService.uploadFiles(data, skillId, id);
      fetchFileList();
    } catch (error) {
      if (error.message === "File(s) exceeds the maximum size allowed (5MB)") {
        setShowModal(true);
      } else {
        handleError(error.response?.data.errorKey);
      }
    }
  };

  const handleDeleteFile = async (fileName) => {
    try {
      await topicService.deleteFile(fileName, skillId, id);
    } catch (e) {
    } finally {
      fetchFileList();
    }
  };

  const handleDownloadFile = async (fileName) => {
    try {
      const response = await topicService.downloadFile(fileName, skillId, id);

      const url = window.URL.createObjectURL(
        new Blob([response.data], {
          type: response.headers["content-type"],
        })
      );
      const link = document.createElement("a");
      link.href = url;

      link.setAttribute("download", fileName);
      document.body.appendChild(link);

      link.click();
    } catch (error) {
      let arrayBufferConverted = JSON.parse(
        String.fromCharCode.apply(null, new Uint8Array(error.response.data))
      );
      handleError(arrayBufferConverted.errorKey);
    } finally {
      fetchFileList();
    }
  };

  const subtractDateTimeSuffix = (topicName) => {
    let suffixIndex = topicName.lastIndexOf("_");
    return topicName.slice(0, suffixIndex);
  };

  const renderFiles = fileList?.map((fileName) => {
    let compactName = subtractDateTimeSuffix(fileName);

    return (
      <Row className="file-row" key={fileName}>
        <p
          className="file-name m-0 ps-2 ms-2"
          onClick={() => handleDownloadFile(fileName)}
        >
          {compactName}
        </p>
        {token && (
          <TiDeleteOutline
            className="delete-icon"
            onClick={() => handleDeleteFile(fileName)}
          />
        )}
      </Row>
    );
  });

  return (
    <>
      <Row key={props.topic.id}>
        <h6>
          <li className="mt-2" key={props.topic.id}>
            {name}{" "}
            {token && (
              <>
                <input
                  className="file-input"
                  type="file"
                  onChange={handleUploadFiles}
                  multiple
                  onClick={(e) => (fileInputRef.current.value = null)}
                  ref={fileInputRef}
                />
                <AiOutlineFileAdd
                  className="upload-file-icon"
                  onClick={() => {
                    fileInputRef.current.click();
                  }}
                />
              </>
            )}
          </li>
        </h6>
        <p className="topic-description">{description}</p>
        <div className="attachments-container">{renderFiles}</div>
      </Row>
      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header className="position-modal-header">
          <Modal.Title className="position-modal-title">Caution</Modal.Title>
        </Modal.Header>
        <Modal.Body className="position-modal-body">
          <p>File(s) exceeds the maximum size allowed (5MB)</p>
        </Modal.Body>
        <Modal.Footer className="position-detail-modal-footer">
          <Button id="position-discard" onClick={() => setShowModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
