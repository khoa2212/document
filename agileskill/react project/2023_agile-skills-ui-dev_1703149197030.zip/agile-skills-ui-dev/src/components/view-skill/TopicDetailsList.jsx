import { Fragment } from "react";
import TopicDetails from "./TopicDetails";

export default function TopicDetailsList(props) {
  const renderTopics = props.topicsList
    .filter((topics) => topics.status === "ACTIVE")
    .sort((S1, S2) => S1.name.localeCompare(S2.name))
    .map((topic) => {
      return (
        <Fragment key={topic.id}>
          <TopicDetails topic={topic} skillId={props.skillId} />
        </Fragment>
      );
    });
  return <ol className="view-topic">{renderTopics}</ol>;
}
