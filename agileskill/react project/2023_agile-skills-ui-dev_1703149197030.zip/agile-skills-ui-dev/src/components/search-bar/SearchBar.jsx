import { useState } from "react";

import { Dropdown, Form } from "react-bootstrap";

export function SearchBar(props) {
  const { skillList, formik, addRequireSkilled } = props;

  const [searchValue, setSearchValue] = useState("");
  const [filteredSkillList, setFilteredSkillList] = useState([]);

  const handleInputChange = (e) => {
    const inputValue = e.target.value.trim().toLowerCase();
    setSearchValue(e.target.value);

    const filteredSkills = skillList.filter(
      (skill) =>
        skill.name.toLowerCase().includes(inputValue) &&
        !formik.values.requiredSkillList.some(
          (requiredSkill) =>
            requiredSkill.skillName.toLowerCase() === skill.name.toLowerCase()
        )
    );

    setFilteredSkillList(filteredSkills);
  };

  const handleSelectSkill = (e, skill) => {
    e.preventDefault();

    let requiredSkill = {
      skillId: skill.id,
      skillName: skill.name,
      skillDescription: skill.description,
      require: "",
      level: "",
      note: "",
      requiredTopicList: skill.topicList.map((requiredTopic) => {
        return {
          topicId: requiredTopic.id,
          topicName: requiredTopic.name,
          topicDescription: requiredTopic.description,
          require: "",
          level: "",
          note: "",
        };
      }),
    };

    addRequireSkilled(requiredSkill);
    setSearchValue("");
  };

  return (
    <div className="mt-2">
      <Dropdown show={searchValue.length > 0 && filteredSkillList.length > 0}>
        <Dropdown.Toggle>
          <Form.Group controlId="exampleForm.ControlInput1">
            <Form.Control
              type="text"
              placeholder="Search for a skill"
              value={searchValue === "" ? "" : searchValue}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                }
              }}
              onChange={(e) => handleInputChange(e)}
            />
          </Form.Group>
        </Dropdown.Toggle>

        <Dropdown.Menu>
          {searchValue.length > 0 &&
            filteredSkillList.length > 0 &&
            filteredSkillList.map((skill) => {
              return (
                <Dropdown.Item
                  variant="light"
                  onClick={(e) => handleSelectSkill(e, skill)}
                  key={skill.id}
                  value={skill.name}
                  className="skill-dropdown-item"
                >
                  {skill.name}
                </Dropdown.Item>
              );
            })}
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
}
