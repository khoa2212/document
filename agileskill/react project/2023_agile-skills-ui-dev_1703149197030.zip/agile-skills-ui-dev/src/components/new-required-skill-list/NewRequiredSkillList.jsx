import { Field, FieldArray } from "formik";
import React, { Fragment, useEffect, useState } from "react";
import { SearchBar } from "../search-bar/SearchBar";

import NewRequiredSkillRow from "./NewRequiredSkillRow";
import { LEVEL_ARRAY, REQUIRE_ARRAY } from "../../constants/common";

export default function NewRequiredSkillList(props) {
  const MAX_NOTE_CHAR = 2000;

  const { values, setValues, errors } = props.formik;
  const trigger = props.trigger;
  const setTrigger = props.setTrigger;
  const [checked, setChecked] = useState(false);

  const handleCheck = (form, address, value) => {
    setTrigger(false);
    setChecked(!checked);
    checked
      ? form.setFieldValue(address, undefined)
      : form.setFieldValue(address, value);
  };
  useEffect(() => {
    setChecked(true);
  }, [checked]);

  return (
    <FieldArray name="requiredSkillList">
      {({ remove, push, form }) => (
        <Fragment>
          <table className="required-skill-list">
            <thead className="text-center" id="sticky-table-header">
              <tr>
                <th className="table-skill">Skills/Topics</th>
                <th>Require</th>
                <th>Level</th>
                <th className="table-note">Note (Optional)</th>
              </tr>
            </thead>
            <tbody>
              <Fragment>
                {values.requiredSkillList.length > 0 &&
                  values.requiredSkillList.map((rqSkill, skillIndex) => (
                    <Fragment key={rqSkill.skillId}>
                      <NewRequiredSkillRow
                        formik={{ values, setValues, errors, form, remove }}
                        requiredSkillObject={{ rqSkill, skillIndex }}
                        validationCheck={{ checked, setChecked }}
                        trigger={trigger}
                        handleCheck={handleCheck}
                      />

                      {rqSkill.requiredTopicList.map((rqTopic, topicIndex) => {
                        return (
                          <tr
                            key={rqTopic.topicId}
                            className="table-topic-data"
                          >
                            <td className="topic-data">
                              <h5 className="topic-data-header">
                                {rqTopic.topicName}
                              </h5>
                              <p>{rqTopic.topicDescription}</p>
                            </td>
                            <td className="topic-require">
                              <div
                                className="require-radio-group"
                                role="group"
                                aria-labelledby="my-radio-group"
                              >
                                {REQUIRE_ARRAY.map((ele, index) => {
                                  return (
                                    <Fragment key={index}>
                                      <label>
                                        <Field
                                          type="radio"
                                          name={`requiredSkillList.${skillIndex}.requiredTopicList.${topicIndex}.require`}
                                          value={ele.value}
                                          onClick={(e) => {
                                            handleCheck(
                                              form,
                                              e.target.name,
                                              e.target.value
                                            );
                                          }}
                                        />
                                        {ele.label}
                                      </label>
                                      <br />
                                    </Fragment>
                                  );
                                })}

                                {errors.requiredSkillList &&
                                  errors.requiredSkillList[`${skillIndex}`] &&
                                  errors.requiredSkillList[`${skillIndex}`]
                                    .requiredTopicList &&
                                  errors.requiredSkillList[`${skillIndex}`]
                                    .requiredTopicList[`${topicIndex}`] && (
                                    <div className="level-require-verified">
                                      {
                                        errors.requiredSkillList[
                                          `${skillIndex}`
                                        ].requiredTopicList[`${topicIndex}`]
                                          .require
                                      }
                                    </div>
                                  )}
                              </div>
                            </td>
                            <td className="topic-level">
                              <div
                                className="level-radio-group"
                                role="group"
                                aria-labelledby="my-radio-group"
                              >
                                {LEVEL_ARRAY.map((ele, index) => {
                                  return (
                                    <Fragment key={index}>
                                      <label>
                                        <Field
                                          type="radio"
                                          name={`requiredSkillList.${skillIndex}.requiredTopicList.${topicIndex}.level`}
                                          value={ele.value}
                                          onClick={(e) => {
                                            handleCheck(
                                              form,
                                              e.target.name,
                                              e.target.value
                                            );
                                          }}
                                        />
                                        {ele.label}
                                      </label>
                                      <br />
                                    </Fragment>
                                  );
                                })}

                                {errors.requiredSkillList &&
                                  errors.requiredSkillList[`${skillIndex}`] &&
                                  errors.requiredSkillList[`${skillIndex}`]
                                    .requiredTopicList &&
                                  errors.requiredSkillList[`${skillIndex}`]
                                    .requiredTopicList[`${topicIndex}`] && (
                                    <div className="level-require-verified">
                                      {
                                        errors.requiredSkillList[
                                          `${skillIndex}`
                                        ].requiredTopicList[`${topicIndex}`]
                                          .level
                                      }
                                    </div>
                                  )}
                              </div>
                            </td>
                            <td className="topic-note">
                              <div
                                className="content"
                                role="group"
                                aria-labelledby="my-radio-group"
                              >
                                <Field
                                  as="textarea"
                                  name={`requiredSkillList.${skillIndex}.requiredTopicList.${topicIndex}.note`}
                                  placeholder="Note"
                                  maxLength={MAX_NOTE_CHAR}
                                />
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </Fragment>
                  ))}
              </Fragment>
            </tbody>
          </table>

          <SearchBar
            skillList={props.skillList}
            formik={{ values, setValues }}
            addRequireSkilled={push}
          />
        </Fragment>
      )}
    </FieldArray>
  );
}
