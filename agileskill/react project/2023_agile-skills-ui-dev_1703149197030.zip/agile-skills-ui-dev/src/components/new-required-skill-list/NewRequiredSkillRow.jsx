import { Field } from "formik";
import React, { Fragment, useState } from "react";

import deleteIcon from "../../assets/images/trash.svg";
import { Button, Modal } from "react-bootstrap";
import { LEVEL_ARRAY, REQUIRE_ARRAY } from "../../constants/common";

export default function NewRequiredSkillRow(props) {
  const MAX_NOTE_CHAR = 2000;

  const { rqSkill, skillIndex } = props.requiredSkillObject;
  const { values, errors, form, remove } = props.formik;
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const handleCheck = props.handleCheck;

  const trigger = props.trigger;

  const handleRemoveSkillFromPosition = (skillIdx, rm) => {
    rm(skillIdx);
    setShowConfirmationModal(false);
  };

  return (
    <tr className="table-skill-data">
      <td className="skill-data">
        <div className="skill-data-header">
          <h5 className="m-0">{rqSkill.skillName}</h5>
          <button
            className="delete-button"
            type="button"
            onClick={() => setShowConfirmationModal(true)}
          >
            <img src={deleteIcon} alt="" />
          </button>
        </div>
        <hr className="m-0 text-dark mb-2" />
        <p>{rqSkill.skillDescription}</p>
      </td>
      <td className="skill-require">
        <div
          className="require-radio-group"
          role="group"
          aria-labelledby="my-radio-group"
        >
          {REQUIRE_ARRAY.map((ele, index) => {
            return (
              <Fragment key={index}>
                <label>
                  <Field
                    type="radio"
                    name={`requiredSkillList.${skillIndex}.require`}
                    value={ele.value}
                    onClick={(e) => {
                      handleCheck(form, e.target.name, e.target.value);
                    }}
                  />
                  {ele.label}
                </label>
                <br />
              </Fragment>
            );
          })}
          {trigger &&
          values.requiredSkillList[`${skillIndex}`].requiredTopicList.some(
            (rqTopic) =>
              rqTopic.level !== undefined &&
              rqTopic.level !== "" &&
              rqTopic.require !== undefined &&
              rqTopic.require !== ""
          ) &&
          (values.requiredSkillList[`${skillIndex}`].level === "" ||
            values.requiredSkillList[`${skillIndex}`].level === undefined) &&
          (values.requiredSkillList[`${skillIndex}`].require === "" ||
            values.requiredSkillList[`${skillIndex}`].require === undefined) ? (
            <div className="position-verified">Require is required</div>
          ) : (
            <div className="position-verified"></div>
          )}

          {errors.requiredSkillList &&
            errors.requiredSkillList[`${skillIndex}`] &&
            errors.requiredSkillList[`${skillIndex}`].require && (
              <label className="level-require-verified">
                {errors.requiredSkillList[`${skillIndex}`].require}
              </label>
            )}
        </div>
      </td>
      <td className="skill-level">
        <div
          className="level-radio-group"
          role="group"
          aria-labelledby="my-radio-group"
        >
          {LEVEL_ARRAY.map((ele, index) => {
            return (
              <Fragment key={index}>
                <label>
                  <Field
                    type="radio"
                    name={`requiredSkillList.${skillIndex}.level`}
                    value={ele.value}
                    onClick={(e) => {
                      handleCheck(form, e.target.name, e.target.value);
                    }}
                  />
                  {ele.label}
                </label>
                <br />
              </Fragment>
            );
          })}
          {trigger &&
            values.requiredSkillList[`${skillIndex}`].requiredTopicList.some(
              (rqTopic) =>
                rqTopic.level !== undefined &&
                rqTopic.level !== "" &&
                rqTopic.require !== undefined &&
                rqTopic.require !== ""
            ) &&
            (values.requiredSkillList[`${skillIndex}`].level === "" ||
              values.requiredSkillList[`${skillIndex}`].level === undefined) &&
            (values.requiredSkillList[`${skillIndex}`].require === "" ||
              values.requiredSkillList[`${skillIndex}`].require ===
                undefined) && (
              <div className="position-verified">Level is required</div>
            )}
          {errors.requiredSkillList &&
            errors.requiredSkillList[`${skillIndex}`] &&
            errors.requiredSkillList[`${skillIndex}`].level && (
              <label className="level-require-verified">
                {errors.requiredSkillList[`${skillIndex}`].level}
              </label>
            )}
        </div>
      </td>
      <td className="skill-note">
        <div className="content" role="group" aria-labelledby="my-radio-group">
          <Field
            as="textarea"
            name={`requiredSkillList.${skillIndex}.note`}
            placeholder="Note"
            maxLength={MAX_NOTE_CHAR}
          />
        </div>
      </td>

      <Modal
        id="remove-skill-confirmation"
        show={showConfirmationModal}
        onHide={() => setShowConfirmationModal(false)}
      >
        <Modal.Header className="modal-header">
          <Modal.Title className="modal-title">
            Delete Skill and its Topics
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="modal-body">
          Do you want to delete{" "}
          <span>
            <b>{rqSkill.skillName}</b>
          </span>{" "}
          from this position?
        </Modal.Body>
        <Modal.Footer className="modal-footer">
          <Button
            id="skill-cancel"
            onClick={() => setShowConfirmationModal(false)}
          >
            No
          </Button>
          <Button
            id="skill-discard"
            onClick={() => handleRemoveSkillFromPosition(skillIndex, remove)}
          >
            Yes
          </Button>
        </Modal.Footer>
      </Modal>
    </tr>
  );
}
