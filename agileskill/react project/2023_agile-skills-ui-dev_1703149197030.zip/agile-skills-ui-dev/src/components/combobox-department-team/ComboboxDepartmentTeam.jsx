import { Fragment, useState } from "react";
import { useLoaderData } from "react-router-dom";

import departmentService from "../../services/departmentService";
import teamService from "../../services/teamService";

export default function ComboboxDepartmentTeam(props) {
  const { values, setValues, errors, touched, handleBlur } = props.formik;

  const { departmentList, teamList } = useLoaderData();
  const [teamListByDepartment, setTeamListByDepartment] = useState([]);
  const [isDepartmentSelected, setIsDepartmentSelected] = useState(false);
  const [isTeamSelected, setIsTeamSelected] = useState(false);
  const [departmentName, setDepartmentName] = useState("Department");

  const handleDepartmentChange = (e) => {
    const selectedOption = e.target.options[e.target.selectedIndex];
    const departmentNameValue = selectedOption.getAttribute("value");

    if (selectedOption.getAttribute("value") === "All") {
      setTeamListByDepartment(teamList);
      setDepartmentName(departmentNameValue);
    } else {
      setIsDepartmentSelected(true);
      setDepartmentName(departmentNameValue);

      const filteredTeams = teamList.filter(
        (team) => team.departmentName === departmentNameValue
      );
      setTeamListByDepartment(filteredTeams);

      setValues({
        ...values,
        teamId: filteredTeams[0].id,
        departmentName: departmentNameValue,
        teamName: filteredTeams[0].name,
      });
    }
  };

  const handleTeamChange = (e) => {
    const selectedOption = e.target.options[e.target.selectedIndex];
    const deptName = selectedOption.getAttribute("data-department");

    setValues({
      ...values,
      teamId: e.target.value,
      departmentName: deptName,
      teamName: selectedOption.textContent,
    });

    setIsTeamSelected(true);
    setDepartmentName(deptName);
  };

  const handlePositionQuantityChange = (e) => {
    e.preventDefault();
    setValues({ ...values, quantity: e.target.value });
  };

  return (
    <Fragment>
      <div className="dept-team-quantity-combobox">
        <div className="department">
          <div className="label">
            <p>Department:</p>
          </div>
          {!isTeamSelected ? (
            <select
              className="combobox department-combobox"
              onChange={handleDepartmentChange}
              defaultValue="Department"
            >
              {values.departmentName !== "" ? (
                <>
                  <option hidden value={values.departmentName}>
                    {values.departmentName}
                  </option>
                  <option value="All">All</option>
                </>
              ) : (
                <option value="All">All</option>
              )}
              {departmentList &&
                departmentList.map((department) => (
                  <option
                    key={department.id}
                    value={department.name}
                    data-value={department.name}
                  >
                    {department.name}
                  </option>
                ))}
            </select>
          ) : (
            <select
              className="combobox department-combobox"
              onChange={handleDepartmentChange}
              value={
                departmentName === null
                  ? ""
                  : departmentName === "All"
                  ? "All"
                  : departmentName
              }
            >
              <option value="All">All</option>
              {departmentList &&
                departmentList.map((department) =>
                  department.name === departmentName ? (
                    <option key={department.id} value={department.name}>
                      {departmentName}
                    </option>
                  ) : (
                    <option key={department.id} value={department.name}>
                      {department.name}
                    </option>
                  )
                )}
            </select>
          )}
        </div>
        <div className="team">
          <div className="label">
            <p>Team:</p>
          </div>

          {!isDepartmentSelected ? (
            <div>
              <select
                name="teamId"
                className="combobox team-combobox"
                onChange={handleTeamChange}
                onBlur={handleBlur}
              >
                {values.teamName !== "" ? (
                  <>
                    <option hidden value={values.teamId}>
                      {values.teamName}
                    </option>
                    <option key="hidden" hidden>
                      All
                    </option>
                  </>
                ) : (
                  <option key="hidden" hidden>
                    All
                  </option>
                )}
                {teamList &&
                  teamList.map((team) => (
                    <option
                      key={team.id}
                      value={team.id}
                      data-department={team.departmentName}
                    >
                      {team.name}
                    </option>
                  ))}
              </select>
              {errors.teamId && touched.teamId && (
                <div className="position-verified">Team is required!</div>
              )}
            </div>
          ) : (
            <div>
              <select
                name="teamId"
                onChange={handleTeamChange}
                className="combobox team-combobox"
                onBlur={handleBlur}
              >
                {teamListByDepartment &&
                  teamListByDepartment.map((team) => (
                    <option
                      key={team.id}
                      value={team.id}
                      data-department={team.departmentName}
                    >
                      {team.name}
                    </option>
                  ))}
              </select>
              {errors.teamId && touched.teamId && (
                <div className="position-verified">Team is required!</div>
              )}
            </div>
          )}
        </div>
        <div>
          <input
            className="combobox"
            id="position-quantity"
            name="quantity"
            type="number"
            min={1}
            max={99}
            placeholder="Quantity"
            onChange={handlePositionQuantityChange}
            value={values.quantity}
            onKeyDown={(evt) =>
              ["+", "-", "."].includes(evt.key) && evt.preventDefault()
            }
            onInput={(e) => {
              if (e.target.value <= 0) {
                e.target.value = "";
              }

              if (e.target.value.length > 2) {
                e.target.value = e.target.value.slice(0, 2);
              }
            }}
            onBlur={handleBlur}
          />
          {errors.quantity && touched.quantity && (
            <div className="position-verified">Quantity is required!</div>
          )}
        </div>
      </div>
    </Fragment>
  );
}

export async function fetchActiveDeptsAndTeams() {
  const fetchActiveDeptList = await departmentService.getActiveDepartments();
  const departmentList = fetchActiveDeptList.data;
  const fetchActiveTeamList = await teamService.getActiveTeams();
  const teamList = fetchActiveTeamList.data;

  return { departmentList, teamList };
}
