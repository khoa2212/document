import * as React from "react";
import { Col, Row } from "react-bootstrap";
import { Fragment } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  Tooltip,
} from "recharts";

export default function SkillChart(props) {
  const statisticDetails = props.statisticDetails;

  statisticDetails.statisticData.map(
    (data) =>
      (data.skillName = data.skillName.startsWith("INACTIVE")
        ? data.skillName.replace(/^INACTIVE\d+_/, "")
        : data.skillName)
  );

  return (
    <Row className="list-of-years">
      <Col xs={5} className="statistic-skill-col">
        <Fragment>
          <table className="statistic-skill-list">
            <thead className="text-center" id="table-header">
              <tr>
                <th>Skills</th>
                <th>Appear</th>
                <th>Must</th>
                <th>Nice</th>
              </tr>
            </thead>
            <tbody>
              {statisticDetails.statisticData.map((statistic) => (
                <tr key={statistic.skillName}>
                  <td id="skill-col">
                    {statistic.skillName.length < 10
                      ? statistic.skillName
                      : `${statistic.skillName.substring(0, 10)}...`}
                  </td>
                  <td>{Math.round(statistic.appearancePercentage)}%</td>
                  <td>{Math.round(statistic.mustHavePercentage)}%</td>
                  <td>{Math.round(statistic.niceToHavePercentage)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Fragment>
      </Col>
      <Col xs={6}>
        <BarChart
          width={660}
          height={600}
          data={statisticDetails.statisticData}
          margin={{ top: 20, right: 20, left: 50, bottom: 5 }}
          layout="vertical"
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            type="number"
            dataKey="appearancePercentage"
            domain={[0, 100]}
            tickFormatter={(value) => `${value}%`}
          />
          <YAxis
            className="skill-name-axis"
            dataKey="skillName"
            type="category"
            position="insideTopRight"
            width={50}
            tickFormatter={(value) => {
              if (value.length < 15) return value;
              return `${value.substring(0, 9)}...`;
            }}
          />
          <Legend verticalAlign="bottom" height={25} />
          <Tooltip
            formatter={(value) => `${value}%`}
            labelFormatter={(value) =>
              value.length > 10 ? `${value.slice(0, 10)}...` : value
            }
          />
          <Bar
            dataKey="mustHavePercentage"
            fill="#01b0f1"
            name="Must"
            stackId="stacked"
            barSize={25}
          />
          <Bar
            dataKey="niceToHavePercentage"
            fill="#ffc000"
            name="Nice"
            stackId="stacked"
            barSize={25}
          />
        </BarChart>
      </Col>
    </Row>
  );
}
