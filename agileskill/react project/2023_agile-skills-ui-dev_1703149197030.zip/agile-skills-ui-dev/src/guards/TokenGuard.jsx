import React, { useContext, useEffect } from "react";
import { Outlet, useLoaderData, useNavigate } from "react-router";
import authService from "../services/authService";
import ToastContext from "../context/ToastContext";

export default function TokenGuard() {
  const isTokenExpired = useLoaderData();
  const toastContext = useContext(ToastContext);
  const navigate = useNavigate();

  const onFocus = () => {
    const isTokenExpiredOnFocus = authService.isTokenExpired();
    if (isTokenExpiredOnFocus) {
        localStorage.removeItem("token");
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Session expired!",
        });
        navigate("/");
      }
  };

  useEffect(() => {
    if (isTokenExpired) {
      localStorage.removeItem("token");
      toastContext.setToastState({
        actionState: false,
        showToast: true,
        message: "Session expired!",
      });
      navigate("/");
    }

    window.addEventListener("focus", onFocus);

    return () => {
      window.removeEventListener("focus", onFocus);
    };
  }, [isTokenExpired, navigate]);

  return <Outlet />;
}
