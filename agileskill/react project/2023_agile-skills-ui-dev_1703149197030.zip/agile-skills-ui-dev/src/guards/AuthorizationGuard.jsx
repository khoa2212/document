import React, { useEffect, useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import authService from "../services/authService";

export default function AuthorizationGuard() {
  const navigate = useNavigate();

  const tokenFromLocalStorage = authService.getToken();

  const [token, setToken] = useState(
    tokenFromLocalStorage ? tokenFromLocalStorage : null
  );

  // User has switched back to the tab
  const onFocus = () => {
    const refreshToken = authService.getToken();
    const refreshRole = authService.getRole();

    if (refreshToken === null || refreshRole === null) {
      navigate("/access-denied");
    } else if (refreshToken !== token) {
      setToken(refreshToken);
      navigate("/");
    }
  };

  useEffect(() => {
    window.addEventListener("focus", onFocus);

    return () => {
      window.removeEventListener("focus", onFocus);
    };
  }, [navigate]);

  return <Outlet />;
}
