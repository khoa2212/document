import React, { useEffect } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import authService from "../services/authService";

export default function AuthenticationGuard() {
  const navigate = useNavigate();

  const onFocus = () => {
    const token = authService.getToken();
    if (token !== null) {
      navigate("/");
    }
  };

  useEffect(() => {
    window.addEventListener("focus", onFocus);

    return () => {
      window.removeEventListener("focus", onFocus);
    };
  }, [navigate]);

  return <Outlet />;
}
