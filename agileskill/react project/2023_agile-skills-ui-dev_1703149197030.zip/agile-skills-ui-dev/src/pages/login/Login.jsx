import React, { Fragment, useContext } from "react";
import { Formik, Form as FormikForm, useField, ErrorMessage } from "formik";
import { object, string } from "yup";
import { Button, Container, Form } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import ToastContext from "../../context/ToastContext";
import authService from "../../services/authService";

const emailPattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;

const loginValidation = object().shape({
  email: string()
    .required("Invalid email format.")
    .email("Invalid email format.")
    .matches(emailPattern, "Invalid email format."),

  password: string(),
});

const Input = ({ name, label, ...props }) => {
  const [field] = useField(name);
  return (
    <Fragment>
      <Form.Group
        className="mb-1 d-flex justify-content-start"
        controlId="formBasicEmail"
      >
        <label className="fw-bold label" htmlFor={field.name}>
          {label}
        </label>
        <input className="input my-2 py-2 px-2" {...field} {...props} />
        <div className="forget-password"></div>
        {name === "password" && (
          <Link to={"/forget-password"} className="forget-password">
            Forget password?
          </Link>
        )}
      </Form.Group>

      {name === "email" && (
        <Form.Group className="mb-1 d-flex justify-content-start">
          <Form.Label className="fw-bold label"></Form.Label>
          <ErrorMessage
            name={field.name}
            component="div"
            className="text-danger"
          />
          <div className="forget-password"></div>
        </Form.Group>
      )}
    </Fragment>
  );
};

export default function Login() {
  const navigate = useNavigate();

  const toastContext = useContext(ToastContext);

  const handleLoginError = (errorResponse) => {
    errorResponse.forEach((errorItem) => {
      switch (errorItem.errorKey) {
        case "exception.input.validation.password.blank.or.null":
          toastContext.setToastState({
            actionState: false,
            showToast: true,
            message: "Please enter password!",
          });
          break;

        case "exception.input.validation.email.blank.or.null":
          toastContext.setToastState({
            actionState: false,
            showToast: true,
            message: "Please enter email!",
          });
          break;

        case "exception.input.validation.email.wrong.format":
          toastContext.setToastState({
            actionState: false,
            showToast: true,
            message: "Invalid email format!",
          });
          break;

        default:
          toastContext.setToastState({
            actionState: false,
            showToast: true,
            message: "Something went wrong. Please try again.",
          });
          break;
      }
    });
  };

  const handleLogin = async (values, setSubmitting) => {
    const encoder = new TextEncoder();

    let passwordWithSpecialChar = encoder.encode(values.password);

    let base64Password = btoa(String.fromCharCode(...passwordWithSpecialChar));

    const loginData = {
      email: values.email,
      password: base64Password,
    };

    try {
      await authService.login(loginData);
      navigate("/");
      toastContext.setToastState({
        actionState: true,
        showToast: true,
        message: "Login successfully!",
      });
      setSubmitting(false);
    } catch (error) {
      setSubmitting(false);
      const errorResponse = error.response?.data;
      if (Array.isArray(errorResponse)) {
        handleLoginError(errorResponse);
      } else if (!Array.isArray(errorResponse)) {
        switch (error.response?.data.errorKey) {
          case "exception.security.forbidden.access":
            toastContext.setToastState({
              actionState: false,
              showToast: true,
              delay: 10000,
              message:
                "Account is deactivated! Please contact Mr. Huy (Education manager)!",
            });
            break;

          case "exception.input.validation.email.password.wrong":
          case "exception.security.unauthorized.access":
            toastContext.setToastState({
              actionState: false,
              showToast: true,
              message: "Email or password is incorrect!",
            });
            break;

          default:
            toastContext.setToastState({
              actionState: false,
              showToast: true,
              message: "Something went wrong. Please try again.",
            });
            break;
        }
      } else {
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Something went wrong. Please try again.",
        });
      }
    }
  };

  return (
    <Container>
      <div id="login-container">
        <Formik
          initialValues={{
            email: "",
            password: "",
          }}
          onSubmit={(values, { setSubmitting }) => {
            handleLogin(values, setSubmitting);
          }}
          validationSchema={loginValidation}
        >
          {({ dirty, isValid, isSubmitting }) => {
            return (
              <FormikForm id="login-form">
                <Form.Group className="mb-1 d-flex justify-content-start">
                  <Form.Label className="fw-bold label"></Form.Label>
                  <Form.Label className="fw-bold">
                    <h2 id="login-title" className="mb-3">
                      Login
                    </h2>
                  </Form.Label>
                </Form.Group>

                <Input id="email" name="email" label="Email" />
                <Input name="password" label="Password" type="password" />

                <Form.Group
                  className="mb-1 d-flex justify-content-start"
                  controlId="formBasicPassword"
                >
                  <Form.Label className="fw-bold label"></Form.Label>
                  <Form.Text>
                    <Button
                      disabled={!(isValid && dirty) || isSubmitting}
                      id="login-button"
                      className="my-3"
                      variant="primary"
                      type="submit"
                    >
                      Login
                    </Button>
                  </Form.Text>

                  <div className="forget-password"></div>
                </Form.Group>

                <Form.Text>
                  <p className="my-4 fw-bold">
                    Don't have an account? Please contact Huy (Education
                    manager):{" "}
                    <a href="mailto:huy.nguyen@axonactive.com">
                      huy.nguyen@axonactive.com
                    </a>{" "}
                    or Skype: <a href="skype:huyedumgr?chat">huyedumgr</a>
                  </p>
                </Form.Text>
              </FormikForm>
            );
          }}
        </Formik>
      </div>
    </Container>
  );
}
