import React from "react";
import { useNavigate } from "react-router-dom";
import Button from "react-bootstrap/Button";
import { Container, Row } from "react-bootstrap";

import AccessDenyImage from "../../assets/images/403.png";
import TinyAccessDenyImage from "../../assets/images/403_tiny.png";
import ProgressiveImg from "../../components/progressive-img/ProgressiveImg";

export default function AccessDenied() {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate("/"); //navigate to homepage
  };

  return (
    <Container>
      <div className="forbidden-content">
        <Row className="image">
          <ProgressiveImg
            id="forbidden-image"
            src={AccessDenyImage}
            placeholderSrc={TinyAccessDenyImage}
          />
        </Row>
        <Row>
          <h1 id="forbidden-title">Access Denied</h1>
          <p id="forbidden-message">
            You don't have permission to access this resource!
          </p>
        </Row>
        <Button id="forbidden-button" onClick={handleGoBack}>
          Back to homepage
        </Button>
      </div>
    </Container>
  );
}
