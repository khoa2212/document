import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

import arrowIcon from "../../assets/images/arrow.svg";

const homeNavItem = [
  {
    id: 1,
    link: "Skills by Position",
    content:
      "View current open Position with details required Skills, level of expertise",
    path: "/skills-by-position",
  },
  {
    id: 2,
    link: "Skills List",
    content: "View generic Skills with complete Topics",
    path: "/skills-list",
  },
];

export default function Home() {
  const navigate = useNavigate();

  const renderHomeNavItem = homeNavItem.map((item) => {
    return (
      <Row key={item.id} className="position">
        <Col xs={2}>
          <h6
            className="view-position"
            onClick={() => {
              navigate(item.path);
            }}
          >
            {item.link}
          </h6>
        </Col>
        <Col xs={1}>
          <img src={arrowIcon} alt="Arrow" />
        </Col>
        <Col id="content">
          <span>{item.content}</span>
        </Col>
      </Row>
    );
  });

  return (
    <Container>
      <Row id="home-title">
        <h5 id="title">Align skills expectation for teams with AgileSkills</h5>
      </Row>
      <Row id="home-subtitle">{renderHomeNavItem}</Row>
    </Container>
  );
}
