import React, { useEffect } from "react";
import { useLoaderData, useNavigate, useParams } from "react-router-dom";

import GeneralSkillTopicForm from "../../components/general-skill-topic-form/GeneralSkillTopicForm";
import skillService from "../../services/skillService";
import slugGenerator from "../../services/slugGenerator";

export default function UpdateSkill() {
  const navigate = useNavigate();
  const { skillIdBase64 } = useParams();

  const { skillDetails, topicList } = useLoaderData();

  useEffect(() => {
    let str = slugGenerator(skillDetails.name);
    let newURL =
      window.location.origin + "/update-skill/" + skillIdBase64 + "/" + str;
    window.history.replaceState(null, "", newURL);
    skillDetails.status === "INACTIVE" && navigate("/not-found");
  }, [skillIdBase64, navigate]);

  return (
    <GeneralSkillTopicForm
      skillFullDetails={{ skillDetails, topicList, skillIdBase64 }}
    />
  );
}

export async function getRequiredDataForUpdateSkill(skillIdBase64) {
  const skillId = atob(skillIdBase64);
  const fetchSkillDetails = await skillService.getSkill(skillId);
  const skillDetails = fetchSkillDetails.data;

  const fetchTopicListBySkillId = await skillService.getTopicBySkill(skillId);
  const topicList = fetchTopicListBySkillId.data;

  return { skillDetails, topicList };
}
