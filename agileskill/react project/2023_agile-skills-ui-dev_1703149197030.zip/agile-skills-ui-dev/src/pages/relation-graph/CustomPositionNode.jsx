import React, { memo } from "react";
import { useNavigate } from "react-router-dom";
import { Handle, Position } from "reactflow";
import { reduceFilename} from "../../utils/textUtils";

function CustomPositionNode({ id, data, isConnectable }) {
  const navigate = useNavigate();

  return (
    <>
      <Handle
        type="source"
        position={Position.Bottom}
        isConnectable={isConnectable}
      />
      <div
        className="position-node d-flex justify-content-center align-items-center fw-bold"
        onClick={() => navigate(`/positions/${btoa(id)}`)}
      >
        {reduceFilename(data.label)}
      </div>
    </>
  );
}

export default memo(CustomPositionNode);
