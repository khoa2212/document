import React, {
  memo,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { Handle, Position } from "reactflow";
import topicService from "../../services/topicService";
import ToastContext from "../../context/ToastContext";
import { Row } from "react-bootstrap";
import { reduceFilename } from "../../utils/textUtils";

function CustomRequiredTopicNode({ id, data, isConnectable }) {
  const toastContext = useContext(ToastContext);

  const [fileList, setFileList] = useState([]);

  const { label, skillId, topicId } = data;

  const fetchFileList = useCallback(async () => {
    const response = await topicService.getFiles(skillId, topicId);
    setFileList(response.data);
  }, []);

  const handleError = (errorKey) => {
    switch (errorKey) {
      case "exception.input.validation.attachment.not.found":
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "The selected file(s) is unavailable",
        });
        break;

      case "exception.input.validation.file.not.found":
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "The selected file(s) may have been deleted",
        });
        break;

      default:
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Something went wrong. Please try again.",
        });
        break;
    }
  };

  const handleDownloadFile = async (fileName) => {
    try {
      const response = await topicService.downloadFile(
        fileName,
        skillId,
        topicId
      );

      const url = window.URL.createObjectURL(
        new Blob([response.data], {
          type: response.headers["content-type"],
        })
      );
      const link = document.createElement("a");
      link.href = url;

      link.setAttribute("download", fileName);
      document.body.appendChild(link);

      link.click();
    } catch (error) {
      let arrayBufferConverted = JSON.parse(
        String.fromCharCode.apply(null, new Uint8Array(error.response.data))
      );
      handleError(arrayBufferConverted.errorKey);
    } finally {
      fetchFileList();
    }
  };

  const subtractDateTimeSuffix = (name) => {
    const dateTimeIndex = name.lastIndexOf("_");

    return name.slice(0, dateTimeIndex);
  };

  const getEpochDateTimeString = (name) => {
    const extensionIndex = name.lastIndexOf(".");
    const nameWithoutExtension = name.slice(0, extensionIndex);

    const dateTimeIndex = nameWithoutExtension.lastIndexOf("_");

    return nameWithoutExtension.slice(
      dateTimeIndex + 1,
      nameWithoutExtension.length
    );
  };

  const displayDate = (dateTimeString) => {
    const date = new Date(+dateTimeString);
    let day = date.getDate();

    let month = date.getMonth();
    let year = date.getFullYear();

    return day + "/" + month + "/" + year;
  };

  const renderFiles =
    [...fileList].sort((a, b) => {
      return getEpochDateTimeString(a) - getEpochDateTimeString(b);
    })
    .map((fileName) => {
      let compactName = subtractDateTimeSuffix(fileName);

      return (
        <li key={fileName} className="topic-row">
          <Row
            className="m-0 topic-file d-flex p-0 flex-column justify-content-center align-items-start"
            onClick={() => handleDownloadFile(fileName)}
          >
            <p className="file-name m-0 p-0">{reduceFilename(compactName)}</p>
            <p className="file-date m-0 p-0">
              ({displayDate(getEpochDateTimeString(fileName))})
            </p>
          </Row>
        </li>
      );
    });
  useEffect(() => {
    fetchFileList();
  }, [fetchFileList]);

  return (
    <>
      <Handle
        type="target"
        position={Position.Top}
        isConnectable={isConnectable}
      />
      <div className="required-topic-node p-2 d-flex flex-column justify-content-center align-items-center">
        <p className="m-0 py-1">{reduceFilename(label)}</p>

        {fileList && (
          <ul className="mb-1 ps-2">
            {renderFiles}
          </ul>
        )}
      </div>
    </>
  );
}

export default memo(CustomRequiredTopicNode);
