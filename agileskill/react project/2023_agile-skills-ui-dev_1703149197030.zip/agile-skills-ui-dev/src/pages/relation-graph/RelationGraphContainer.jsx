import { Container, Dropdown } from "react-bootstrap";
import { useLoaderData, useNavigate } from "react-router-dom";
import React from "react";

import ReactFlow, {
  useNodesState,
  useEdgesState,
  Background,
  Controls,
  MiniMap,
  Panel,
} from "reactflow";
import CustomPositionNode from "./CustomPositionNode";

import dagre from "dagre";

import "reactflow/dist/style.css";

const nodeTypes = {
  selectorNode: CustomPositionNode,
};

const position = { x: 0, y: 0 };
const edgeType = "smoothstep";

export const sampleNodes = [
  {
    id: "1",
    type: "input",
    data: { label: "Position" },
    position,
  },
  {
    id: "2",
    data: { label: "Required Skill 1" },
    position,
  },
  {
    id: "3",
    data: { label: "Required Skill 2" },
    position,
  },
  {
    id: "4",
    type: "output",
    data: { label: "Required Topic 1" },
    position,
  },
  {
    id: "5",
    type: "output",
    data: { label: "Required Topic 2" },
    position,
  },
  {
    id: "6",
    type: "output",
    data: { label: "Required Topic 3" },
    position,
  },
  {
    id: "7",
    type: "output",
    data: { label: "Required Topic 4" },
    position,
  },
];

export const sampleEdges = [
  { id: "e12", source: "1", target: "2", type: edgeType },
  { id: "e13", source: "1", target: "3", type: edgeType },
  { id: "e24", source: "2", target: "4", type: edgeType },
  { id: "e25", source: "2", target: "5", type: edgeType },
  { id: "e36", source: "3", target: "6", type: edgeType },
  { id: "e37", source: "3", target: "7", type: edgeType },
];

const dagreGraph = new dagre.graphlib.Graph();
dagreGraph.setDefaultEdgeLabel(() => ({}));

const nodeWidth = 172;
const nodeHeight = 36;

const getLayoutedElements = (nodes, edges, direction = "TB") => {
  const isHorizontal = direction === "LR";
  dagreGraph.setGraph({ rankdir: direction });

  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  nodes.forEach((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    node.targetPosition = isHorizontal ? "left" : "top";
    node.sourcePosition = isHorizontal ? "right" : "bottom";

    node.position = {
      x: nodeWithPosition.x - nodeWidth / 2,
      y: nodeWithPosition.y - nodeHeight / 2,
    };

    return node;
  });

  return { nodes, edges };
};

const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(
  sampleNodes,
  sampleEdges
);

export default function RelationGraphContainer() {
  const positionList = useLoaderData().totalPositionList;
  const navigate = useNavigate();

  const [nodes, setNodes, onNodesChange] = useNodesState(layoutedNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(layoutedEdges);

  const renderPositionList = () => {
    return positionList.map((pos) => {
      return (
        <Dropdown.Item
          key={pos.id}
          onClick={() => {
            navigate(`/relation-graphs/${btoa(pos.id)}`);
          }}
        >
          {pos.name}
        </Dropdown.Item>
      );
    });
  };

  return (
    <Container id="position-relation-container">
      <Dropdown>
        <Dropdown.Toggle className="position-dropdown-button">
          Select a position
        </Dropdown.Toggle>

        <Dropdown.Menu className="position-dropdown-menu">
          {renderPositionList()}
        </Dropdown.Menu>
      </Dropdown>
      <div
        id="position-relation-graph"
      >
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          nodesConnectable={false}
          edgesUpdatable={false}
          edgesFocusable={false}
          edgeTypes={edgeType}
          nodeTypes={nodeTypes}
          fitView
        >
          <Panel position="center">
            <strong>Select a position to view its graph</strong>
          </Panel>
          <Controls />
          <MiniMap />
          <Background variant="dots" gap={12} size={1} />
        </ReactFlow>
      </div>
    </Container>
  );
}
