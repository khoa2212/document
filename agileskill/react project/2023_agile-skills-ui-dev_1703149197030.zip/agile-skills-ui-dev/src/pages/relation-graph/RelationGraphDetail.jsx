import { Container, Dropdown } from "react-bootstrap";
import {
  useLoaderData,
  useLocation,
  useNavigate,
  useParams,
} from "react-router-dom";
import RelationGraphWithDagreTree from "./RelationGraphWithDagreTree";
import React, { useEffect, useState } from "react";

export default function RelationGraphDetail() {
  const location = useLocation();
  const navigate = useNavigate();

  const { positionIdBase64 } = useParams();

  let { totalPositionList, selectedPosition, flow } = useLoaderData();

  const [flowKey, setFlowKey] = useState(+atob(positionIdBase64));

  useEffect(() => {
    let suffixIndex = location.pathname.lastIndexOf("/");
    let newPositionIdBase64 = location.pathname.slice(
      suffixIndex + 1,
      location.pathname.length
    );
    setFlowKey(+atob(newPositionIdBase64));
  }, [positionIdBase64]);

  const renderPositionList = () => {
    return totalPositionList.map((pos) => {
      return (
        <Dropdown.Item
          key={pos.id}
          onClick={() => {
            navigate(`/relation-graphs/${btoa(pos.id)}`);
          }}
        >
          {pos.name}
        </Dropdown.Item>
      );
    });
  };

  return (
    <Container id="position-relation-container">
      <Dropdown>
        <Dropdown.Toggle className="position-dropdown-button">
          {selectedPosition?.name}
        </Dropdown.Toggle>

        <Dropdown.Menu className="position-dropdown-menu">
          {renderPositionList()}
        </Dropdown.Menu>
      </Dropdown>
      <RelationGraphWithDagreTree
        selectedPosition={selectedPosition}
        flowKey={flowKey}
        flow={flow}
      />
    </Container>
  );
}
