import React, { memo } from "react";
import { useNavigate } from "react-router";
import { Handle, Position } from "reactflow";
import { reduceFilename } from "../../utils/textUtils";

function CustomRequiredSkillNode({ id, data, isConnectable }) {
  const navigate = useNavigate();

  return (
    <>
      <Handle
        type="target"
        position={Position.Top}
        isConnectable={isConnectable}
      />

      <div
        className="required-skill-node p-2 d-flex justify-content-center align-items-center fw-bold"
        onClick={() => navigate(`/skills/${btoa(data.skillId)}`)}
      >
        {reduceFilename(data.label)}
      </div>
      <Handle
        type="source"
        position={Position.Bottom}
        isConnectable={isConnectable}
      />
    </>
  );
}

export default memo(CustomRequiredSkillNode);
