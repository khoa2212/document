import React, { useEffect, useState, useCallback, useContext } from "react";

import { Button } from "react-bootstrap";
import ReactFlow, {
  Panel,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  useReactFlow,
  ReactFlowProvider,
} from "reactflow";
import CustomPositionNode from "./CustomPositionNode";
import CustomRequiredSkillNode from "./CustomRequiredSkillNode";
import CustomRequiredTopicNode from "./CustomRequiredTopicNode";
import dagre from "dagre";

import "reactflow/dist/style.css";
import { useNavigate } from "react-router-dom";
import positionService from "../../services/positionService";
import graphService from "../../services/graphService";
import ToastContext from "../../context/ToastContext";

const nodeTypes = {
  positionNode: CustomPositionNode,
  requiredSkillNote: CustomRequiredSkillNode,
  requiredTopicNote: CustomRequiredTopicNode,
};

const dagreGraph = new dagre.graphlib.Graph();
dagreGraph.setDefaultEdgeLabel(() => ({}));

const nodeWidth = 220;
const nodeHeight = 100;

const getLayoutedElements = (nodes, edges, direction = "TB") => {
  const isHorizontal = direction === "LR";
  dagreGraph.setGraph({ rankdir: direction });

  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  nodes.forEach((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    node.targetPosition = isHorizontal ? "left" : "top";
    node.sourcePosition = isHorizontal ? "right" : "bottom";

    node.position = {
      x: nodeWithPosition.x - nodeWidth / 2,
      y: nodeWithPosition.y - nodeHeight / 2,
    };

    return node;
  });

  return { nodes, edges };
};

const position = { x: -100, y: 0 };
const edgeType = "smoothstep";

function Flow(props) {
  let selectedPosition = props.selectedPosition;
  let flowKey = props.flowKey;
  let flow = props.flow;

  const toastContext = useContext(ToastContext);

  const navigate = useNavigate();

  const [isSubmitting, setIsSubmitting] = useState(false);

  const [captureElementClick, setCaptureElementClick] = useState(false);

  const onNodeClick = (event, node) => navigate(`/positions/${btoa(node.id)}`);

  const [rfInstance, setRfInstance] = useState(null);

  const reactFlowInstance = useReactFlow();

  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  const onSave = useCallback(async () => {
    if (rfInstance) {
      const flowString = rfInstance.toObject();

      const data = {
        graphValue: JSON.stringify(flowString),
        positionId: selectedPosition.id,
      };

      try {
        setIsSubmitting(true);
        await graphService.save(data);

        toastContext.setToastState({
          actionState: true,
          showToast: true,
          delay: 1000,
          message: "Save successfully!",
        });

        setTimeout(() => {
          setIsSubmitting(false);
        }, 1000);
      } catch (error) {
        const errorResponse = error.response.data;
        if (
          errorResponse.errorKey === "exception.resource.not.found.position"
        ) {
          toastContext.setToastState({
            actionState: false,
            showToast: true,
            message: "Position not found!",
          });
        }
        setTimeout(() => {
          setIsSubmitting(false);
        }, 1000);
      } finally {
        setTimeout(() => {
          setIsSubmitting(false);
        }, 1000);
      }
    }
  }, [rfInstance, flowKey]);

  const initialNodes = [
    {
      id: selectedPosition?.id.toString(),
      position,
      type: "positionNode",
      data: { label: selectedPosition?.name },
    },
  ];

  const initialEdges = [];

  const requiredSkillNodeList = selectedPosition?.requiredSkillList.map(
    (rqSkill) => {
      return {
        id: rqSkill.id.toString(),
        type: "requiredSkillNote",
        position,
        data: {
          label: rqSkill?.skillName,
          skillId: rqSkill?.skillId,
        },
      };
    }
  );

  const requiredTopicNodeList = selectedPosition?.requiredSkillList.map(
    (rqSkill) => {
      return rqSkill.requiredTopicList.map((rqTopic) => {
        return {
          id: rqTopic.id.toString(),
          type: "requiredTopicNote",
          position,
          data: {
            label: rqTopic.topicName,
            skillId: rqSkill?.skillId,
            topicId: rqTopic.topicId,
          },
        };
      });
    }
  );

  const handleAddInitNode = (additionalNodesArray) => {
    for (let i = 0; i < additionalNodesArray?.length; i++) {
      initialNodes.push(additionalNodesArray[i]);
    }
  };

  const handleAddInitEdge = (id, initArray, additionalEdge) => {
    initArray.push({
      id: `e${id}-${additionalEdge.id}`,
      source: `${id.toString()}`,
      target: `${additionalEdge.id.toString()}`,
      type: edgeType,
    });
  };

  const handleCreateEdgeList = (pos, requiredSkillList) => {
    for (let i = 0; i < requiredSkillList?.length; i++) {
      handleAddInitEdge(pos.id, initialEdges, requiredSkillList[i]);

      for (const requiredTopic of requiredSkillList[i].requiredTopicList) {
        handleAddInitEdge(requiredSkillList[i].id, initialEdges, requiredTopic);
      }
    }
  };

  const createGraph = () => {
    handleAddInitNode(requiredSkillNodeList);
    for (let i = 0; i < requiredTopicNodeList?.length; i++) {
      handleAddInitNode(requiredTopicNodeList[i]);
    }
    handleCreateEdgeList(selectedPosition, selectedPosition?.requiredSkillList);

    const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(
      initialNodes,
      initialEdges
    );
    setNodes(layoutedNodes);
    setEdges(layoutedEdges);
  };

  const renderGraph = () => {
    return Promise.resolve(createGraph());
  };

  const onRestore = useCallback(() => {
    const restoreFlow = async () => {
      if (flow !== "") {
        const { x = 0, y = 0, zoom = 1 } = flow.viewport;
        setNodes(flow.nodes || []);
        setEdges(flow.edges || []);
        reactFlowInstance.setViewport({ x, y, zoom });
      }
    };

    restoreFlow();
  }, [
    setNodes,
    setEdges,
    reactFlowInstance.setViewport,
    flowKey,
    selectedPosition,
  ]);

  useEffect(() => {
    renderGraph().then(setTimeout(reactFlowInstance.fitView, 4));
    onRestore();
  }, [selectedPosition, flowKey, flow, rfInstance]);

  return (
    <div id="position-relation-graph">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodesConnectable={false}
        edgesUpdatable={false}
        edgesFocusable={false}
        edgeTypes={edgeType}
        onNodeClick={captureElementClick ? onNodeClick : undefined}
        onInit={setRfInstance}
        nodeTypes={nodeTypes}
        fitView
      >
        <Panel position="top-right" className="m-0">
          <Button
            className="graph-save-button"
            onClick={onSave}
            disabled={isSubmitting}
          >
            Save
          </Button>
        </Panel>
        <Controls />
        <MiniMap />
        <Background variant="dots" gap={12} size={1} />
      </ReactFlow>
    </div>
  );
}

export default function RelationGraphWithDagreTree(props) {
  return (
    <ReactFlowProvider>
      <Flow
        selectedPosition={props.selectedPosition}
        flowKey={props.flowKey}
        flow={props.flow}
      />
    </ReactFlowProvider>
  );
}

export async function getPositionWithFileList(positionIdBase64) {
  const response = await positionService.getPositionList();
  const totalPositionList = response.data;
  let flow = "";

  const positionId = atob(positionIdBase64);
  const fetchPositionDetails =
    await positionService.getPositionWithRequiredSkillAndTopic(positionId);

  const selectedPosition = fetchPositionDetails.data;

  const graphDetails = await graphService.getGraphByPositionId(positionId);

  if (graphDetails.data !== "") {
    flow = JSON.parse(graphDetails.data.graphValue);
  }

  return { totalPositionList, selectedPosition, flow };
}
