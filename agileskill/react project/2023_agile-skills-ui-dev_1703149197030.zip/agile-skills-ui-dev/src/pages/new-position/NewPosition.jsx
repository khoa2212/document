import { Formik, Form as FormikForm } from "formik";
import React, { useContext, useState } from "react";
import { Button, Col, Container, Modal, Row } from "react-bootstrap";
import { number, object, string, array } from "yup";
import { useLoaderData, useLocation, useNavigate } from "react-router-dom";

import skillService from "../../services/skillService";
import saveIcon from "../../assets/images/save.svg";
import closeIcon from "../../assets/images/close.svg";
import departmentService from "../../services/departmentService";
import teamService from "../../services/teamService";
import ComboboxDepartmentTeam from "../../components/combobox-department-team/ComboboxDepartmentTeam";
import NewRequiredSkillList from "../../components/new-required-skill-list/NewRequiredSkillList";
import PositionForm from "../../components/position-form/PositionForm";
import ToastContext from "../../context/ToastContext";
import positionService from "../../services/positionService";

export default function NewPosition() {
  const { skillList } = useLoaderData();
  const toastContext = useContext(ToastContext);
  const location = useLocation();
  const from = location.state?.prevPath || "/";
  const navigate = useNavigate();

  const [trigger, setTrigger] = useState(false);

  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [showDuplicatePositionModal, setShowDuplicatePositionModal] =
    useState(false);

  const positionValidation = object().shape({
    teamId: number().required("Team is required!"),
    name: string()
      .required("Position name is required!")
      .trim()
      .min(3, "Position name must be more than 2 characters!")
      .max(255),
    note: string().max(2000),
    quantity: number().required().min(1).max(99),
    requiredSkillList: array().of(
      object().shape(
        {
          require: string()
            .nullable()
            .when("level", {
              is: (level, require) =>
                level !== undefined && require === undefined,
              then: (validation) => validation.required("Require is required"),
            }),
          level: string().when("require", {
            is: (require) => require !== undefined,
            then: (validation) => validation.required("Level is required"),
          }),
          requiredTopicList: array().of(
            object().shape(
              {
                require: string().when("level", {
                  is: (level, require) =>
                    level !== undefined && require === undefined,
                  then: (validation) =>
                    validation.required("Require is required"),
                }),
                level: string().when("require", {
                  is: (require) => require !== undefined,
                  then: (validation) =>
                    validation.required("Level is required"),
                }),
              },
              ["level", "require"]
            )
          ),
        },
        ["level", "require"]
      )
    ),
  });

  const initialPosition = {
    departmentName: "",
    teamName: "",
    teamId: "",
    name: "",
    note: "",
    quantity: "",
    requiredSkillList: [],
  };

  const handleCreatePosition = async (values, setSubmitting) => {
    try {
      let submitData = {
        teamId: values.teamId,
        name: values.name.trim(),
        note: values.note.trim(),
        quantity: values.quantity,
        requiredSkillList: values.requiredSkillList
          ? values.requiredSkillList.map((rqSkill) => {
              return {
                skillId: rqSkill.skillId,
                require: rqSkill.require === "" ? null : rqSkill.require,
                level: rqSkill.level === "" ? null : rqSkill.level,
                note: rqSkill.note,
                requiredTopicList: rqSkill.requiredTopicList
                  ? rqSkill.requiredTopicList.map((rqTopic) => {
                      return {
                        topicId: rqTopic.topicId,
                        require:
                          rqTopic.require === "" ? null : rqTopic.require,
                        level: rqTopic.level === "" ? null : rqTopic.level,
                        note: rqTopic.note,
                      };
                    })
                  : [],
              };
            })
          : [],
      };
      let response = await positionService.create(submitData);

      navigate(`/positions/${btoa(response.data.id)}`);

      toastContext.setToastState({
        actionState: true,
        showToast: true,
        message: "Create successfully!",
      });
      setSubmitting(false);
    } catch (error) {
      setSubmitting(false);
      const errorResponse = error.response.data;
      if (
        errorResponse?.errorKey ===
        "exception.input.validation.duplicated.position.name"
      ) {
        setShowDuplicatePositionModal(true);
      } else if (
        errorResponse?.errorKey ===
        "exception.input.validation.required.skill.level.must.be.master"
      ) {
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Level of Skill must be higher or equal to level of Topic!",
        });
      } else if (
        errorResponse?.errorKey ===
        "exception.input.validation.required.skill.require.must.be.must.have"
      ) {
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message:
            "Require of Skill must be higher or equal to require of Topic!",
        });
      } else if (
        errorResponse?.errorKey ===
          "exception.input.validation.skill.level.must.be.greater.than.zero" ||
        errorResponse?.errorKey ===
          "exception.input.validation.skill.require.must.be.must.have.or.nice.to.have"
      ) {
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Some Skills do not have require or level!",
        });
      }
    }
  };

  const handleCancelCreatePosition = (values) => {
    if (
      values.teamId.length === 0 &&
      values.name.trim().length === 0 &&
      values.note.trim().length === 0 &&
      (values.quantity === "" || values.quantity === 0) &&
      values.requiredSkillList.length === 0
    ) {
      navigate(from);
    } else {
      setShowConfirmationModal(true);
    }
  };

  const handleDiscardChanges = (resetForm) => {
    resetForm();
    setShowConfirmationModal(false);
    navigate(from);
  };

  return (
    <Container id="new-position">
      <Formik
        initialValues={initialPosition}
        onSubmit={(values, { setSubmitting }) => {
          handleCreatePosition(values, setSubmitting);
        }}
        validationSchema={positionValidation}
      >
        {({
          values,
          setValues,
          errors,
          touched,
          handleBlur,
          isSubmitting,
          resetForm,
          validateForm,
        }) => (
          <FormikForm id="new-position-form">
            <div className="sticky-content-group">
              <div className="position-title d-flex justify-content-between pe-2">
                <h3 className="mb-1">New Position</h3>
                <div className="position-buttons">
                  <button
                    id="save-button"
                    type="submit"
                    disabled={isSubmitting}
                    onClick={() => {
                      setTrigger(true);
                      validateForm().then(() => {
                        const skillErrorsExist = errors.requiredSkillList?.some(
                          (skill) => skill?.require || skill?.level
                        );
                        const topicErrorsExist = errors.requiredSkillList?.some(
                          (skill) =>
                            skill?.requiredTopicList &&
                            skill?.requiredTopicList.some(
                              (topic) => topic.require || topic.level
                            )
                        );
                        if (topicErrorsExist) {
                          toastContext.setToastState({
                            actionState: false,
                            showToast: true,
                            message:
                              "Some Topics do not have require or level!",
                          });
                        } else if (skillErrorsExist) {
                          toastContext.setToastState({
                            actionState: false,
                            showToast: true,
                            message:
                              "Some Skills do not have require or level!",
                          });
                        }
                      });
                    }}
                  >
                    <img src={saveIcon} alt="Save" />
                  </button>

                  <button
                    id="close-button"
                    type="button"
                    onClick={() => handleCancelCreatePosition(values)}
                  >
                    <img src={closeIcon} alt="Close" />
                  </button>
                </div>
              </div>
              <Row className="combobox-group">
                <Col xs={11}>
                  <ComboboxDepartmentTeam
                    formik={{ values, setValues, errors, touched, handleBlur }}
                    check={trigger}
                  />
                </Col>
              </Row>
              <PositionForm
                formik={{ values, setValues, errors, touched, handleBlur }}
              />
            </div>

            <NewRequiredSkillList
              formik={{ values, setValues, errors, positionValidation, Formik }}
              skillList={skillList}
              trigger={trigger}
              setTrigger={setTrigger}
            />

            <Modal
              show={showConfirmationModal}
              onHide={() => setShowConfirmationModal(false)}
            >
              <Modal.Header className="modal-header">
                <Modal.Title className="modal-title">
                  Unsaved changes
                </Modal.Title>
              </Modal.Header>
              <Modal.Body className="modal-body">
                Are you sure you want to discard changes?
              </Modal.Body>
              <Modal.Footer className="modal-footer">
                <Button
                  id="skill-cancel"
                  onClick={() => setShowConfirmationModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  id="skill-discard"
                  onClick={() => handleDiscardChanges(resetForm)}
                >
                  Discard
                </Button>
              </Modal.Footer>
            </Modal>
            <Modal
              show={showDuplicatePositionModal}
              onHide={() => setShowDuplicatePositionModal(false)}
              dialogClassName="modal-width"
            >
              <Modal.Header className="position-modal-header">
                <Modal.Title className="position-modal-title">
                  Duplicated Position
                </Modal.Title>
              </Modal.Header>
              <Modal.Body className="position-modal-body">
                Position&nbsp;<b className="position-text">{values.name}</b> is
                still open in Team{" "}
                <b className="position-text">{values.teamName}</b>
                &nbsp;- Department&nbsp;
                <b className="position-text">{values.departmentName}</b>.
                <br />
                <br />
                Please consider re-using the existing or refining new Position.
              </Modal.Body>
              <Modal.Footer className="position-modal-footer">
                <Button
                  id="position-ok"
                  onClick={() => setShowDuplicatePositionModal(false)}
                >
                  OK
                </Button>
              </Modal.Footer>
            </Modal>
          </FormikForm>
        )}
      </Formik>
    </Container>
  );
}

export async function getRequiredDataForPosition() {
  const fetchActiveSkillList = await skillService.getSkillWithTopicList();
  const skillList = fetchActiveSkillList.data;
  const fetchActiveDeptList = await departmentService.getActiveDepartments();
  const departmentList = fetchActiveDeptList.data;
  const fetchActiveTeamList = await teamService.getActiveTeams();
  const teamList = fetchActiveTeamList.data;

  return { skillList, departmentList, teamList };
}
