import React from "react";
import GeneralSkillTopicForm from "../../components/general-skill-topic-form/GeneralSkillTopicForm";

export default function NewSkill() {
  return <GeneralSkillTopicForm />;
}
