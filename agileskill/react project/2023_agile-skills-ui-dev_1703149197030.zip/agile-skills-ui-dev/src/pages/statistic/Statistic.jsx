import { Container, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import positionService from "../../services/positionService";
import { useEffect, useState } from "react";
export default function Statistic() {
  const navigate = useNavigate();

  const [yearList, setYearList] = useState([]);
  const fetchYearList = async () => {
    const response = await positionService.getYears();
    setYearList(response.data);
  };

  useEffect(() => {
    fetchYearList();
  }, []);

  return (
    <Container>
      <Row className="statistic-title">
        <h3>Yearly Statistics</h3>
      </Row>
      <Row className="list-of-years">
        <ul className="year-list">
          {yearList.map((year) => (
            <li key={year} className="year-item">
              <span
                onClick={() => {
                  navigate(`/skill-demand-report/${year}`);
                }}
              >
                {year}
              </span>
            </li>
          ))}
        </ul>
      </Row>
    </Container>
  );
}
