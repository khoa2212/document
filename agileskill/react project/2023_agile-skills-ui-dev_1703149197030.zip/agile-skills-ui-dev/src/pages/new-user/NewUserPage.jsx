import React from "react";
import { Container } from "react-bootstrap";
import NewUser from "../../components/new-user/NewUser";

export default function NewUserPage() {
  return (
    <Container>
      <NewUser />
    </Container>
  );
}
