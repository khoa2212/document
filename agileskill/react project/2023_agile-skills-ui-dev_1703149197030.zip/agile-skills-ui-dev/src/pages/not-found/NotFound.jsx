import React from "react";
import { useNavigate } from "react-router-dom";
import Button from "react-bootstrap/Button";
import { Container, Row } from "react-bootstrap";

import PageErrorImage from "../../assets/images/404.png";
import TinyPageErrorImage from "../../assets/images/404_tiny.jpg";
import ProgressiveImg from "../../components/progressive-img/ProgressiveImg";

export default function NotFound() {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate("/"); //navigate to homepage
  };

  return (
    <Container>
      <div id="not-found-page">
        <Row>
          <ProgressiveImg
            id="not-found-image"
            src={PageErrorImage}
            placeholderSrc={TinyPageErrorImage}
          />
        </Row>
        <Row>
          <h1 id="not-found-title">OOPS!</h1>
          <p id="not-found-message">
            We can't find the page you are looking for!
          </p>
        </Row>
        <Button id="not-found-button" onClick={handleGoBack}>
          Back to homepage
        </Button>
      </div>
    </Container>
  );
}
