import { Container } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect, useState } from "react";

import skillService from "../../services/skillService";
import slugGenerator from "../../services/slugGenerator";
import SkillDetails from "../../components/view-skill/SkillDetails";
import TopicDetailsList from "../../components/view-skill/TopicDetailsList";

export default function ViewSkill() {
  const [skillDetails, setSkillDetails] = useState({
    name: "loading...",
    description: "loading...",
  });

  const [topicsList, setTopicsList] = useState([]);

  const navigate = useNavigate();
  const { skillIdBase64 } = useParams();
  let skillId = "";

  const fetchTopicBySkill = async () => {
    try {
      const response = await skillService.getTopicBySkill(skillId);
      setTopicsList(response.data);
    } catch {
      navigate("/not-found");
    }
  };

  useEffect(() => {
    try {
      skillId = atob(skillIdBase64);
    } catch {
      navigate("/not-found");
    }
    skillService
      .getSkill(skillId)
      .then((response) => {
        var result = response.data;
        let str = slugGenerator(result.name);
        let newURL =
          window.location.origin + "/skills/" + skillIdBase64 + "/" + str;
        window.history.replaceState(null, "", newURL);
        result.status === "INACTIVE"
          ? navigate("/not-found")
          : setSkillDetails(response.data);
      })
      .catch(() => {
        navigate("/not-found");
      });

    fetchTopicBySkill();
  }, [skillId, skillIdBase64, navigate]);

  return (
    <Container>
      <div id="view-skill">
        <SkillDetails
          skillDetails={skillDetails}
          topicsList={topicsList}
          skillIdBase64={skillIdBase64}
          skillFullDetails={{ skillDetails, topicsList, skillIdBase64 }}
        />
        <TopicDetailsList skillId={skillIdBase64 } topicsList={topicsList} />
      </div>
    </Container>
  );
}
