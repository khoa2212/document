import { useState, useEffect, useContext } from "react";
import { Container } from "react-bootstrap";

import SkillItem from "../../components/skill-item/SkillItem";
import skillService from "../../services/skillService";
import InfiniteScroll from "react-infinite-scroll-component";
import ToastContext from "../../context/ToastContext";

export default function SkillsList() {
  const PAGE_SIZE = 15;
  const [skills, setSkills] = useState([]);
  const [pageData, setPageData] = useState({
    totalRecords: 0,
    currentPage: 0,
    totalPages: 0,
  });
  const [isHasMore, setIsHasMore] = useState(true);
  const toastContext = useContext(ToastContext);

  useEffect(() => {
    fetchNextSkills();
  }, []);
  

  const fetchNextSkills = async () => {
    try {
      const nextPage = pageData.currentPage + 1;
      const response = await skillService.getPagedSkills(nextPage, PAGE_SIZE);
      setSkills([...skills, ...response.data.listData]);
      setPageData(response.data.paginationData);
      setIsHasMore(
        response.data.paginationData.currentPage <
          response.data.paginationData.totalPages
      );
    } catch (error) {
      toastContext.setToastState({
        actionState: false,
        showToast: true,
        message: "Error fetching data. Please try again."
      });
    }
  };

  const renderSkills = skills
    .filter((skill) => skill.status === "ACTIVE")
    .sort((S1, S2) => S1.name.localeCompare(S2.name))
    .map((skill) => {
      return <SkillItem key={skill.id} skill={skill} />;
    });


  return (
    <InfiniteScroll
      dataLength={skills.length}
      next={fetchNextSkills}
      hasMore={isHasMore}
    >
      <Container id="skill-list">{renderSkills}</Container>
    </InfiniteScroll>
  );
}
