import React from "react";
import { Container } from "react-bootstrap";
import ReactMarkdown from "react-markdown";

export default function About() {
  const changelogText = `
  ## Change log

  ### Sprint 11 (28-09-2023)
  
  #### Added
  - Apply Formik for New skill page
  - Change password page
  - Import data page
  - Lazy load on skill list page
  - Update skill page

  ---

  ### Sprint 10 (13-09-2023)
  
  #### Added
  - Update position page
  - Yearly Overall Skill Demand report
  - Add timezone in create/update position fields
   
  #### Changed
  - Add required skills into Create position page
     
  ---
 
  ### Sprint 9 (30-08-2023)
  
  #### Added
  - Apply cache for Search API
  
  ---
  
  ### Sprint 8 (23-08-2023)
  
  #### Added
  - Using Formik for Login form
  - View Position's required skills
  - Search Position
  - Statistic page
  
  #### Changed
  - Unit tests
  
  #### Fixed
  - Create Position API

  ---

  ### Sprint 7 (17-08-2023)
  
  #### Added
  - Close Position
  
  #### Changed
  - Create Skill API
  - Create Position API
  - Improve UI
  
  ---
  
  ### Sprint 6 (10-08-2023)
  
  #### Added
  - New Position
  - View Position details
  - View Position List
  - More unit tests
  
  #### Changed
  - UI/UX differences
  
  #### Fixed
  - Expired token
  - Dancing menu bar
  - API document version
  - New User form
  - Losing new line in description

  ---

  ### Sprint 5 (02-08-2023)
  
  #### Added
  - API documentation
  - Jenkin server
  
  #### Changed
  - Login
  - Log files
  - Refactor BE
  - Create user
  - Team & Department APIs

  ---

  ### Sprint 4 (26-07-2023)
  
  #### Added
  - Create user
  - Login
  - Apply Authorization
  - APIs get teams, departments
  - Init sql files
  
  #### Changed
  - Refactor after FE code review
  - Log files

  ---

  ### Sprint 3 (19-07-2023)
  
  #### Added
  - Log files
  - Sonar scan
  
  #### Changed
  - Refactor back-end after code review

  ---

  ### Sprint 2 (12-07-2023)

  #### Added
  - Home
  - Readme on BE & FE repos
  - Postman collections
  
  #### Changed
  - About
  - Home
  - Menu

  #### Fixed
  - Pages footer
  - Create new Skill 
  - View Skill list
  - View Skill details
  - Create new Topic
  - Unit tests
  - Constants in code
  - Topic.getAll()
  - Audit against DoD
  ---
  ### Sprint 1 (04-07-2023)
  
  #### Added
  - Pages footer
  - Create new Skill 
  - View Skill list
  - View Skill details
  - Create new Topic
  - Edit Skill
  - Unit tests

  #### Changed
  - DoD: security scanning

  #### Fixed
  - Home page
  - Multiple SCSS files
  - Default wildfly password
  
  ---
  ### Sprint 0 (29-06-2023)
  #### Added
  - Project repos
  - About page
 
  `;
  return (
    <Container>
      <div id="about">
        <div className="about-content">
          <ReactMarkdown children={changelogText} />
        </div>
      </div>
    </Container>
  );
}
