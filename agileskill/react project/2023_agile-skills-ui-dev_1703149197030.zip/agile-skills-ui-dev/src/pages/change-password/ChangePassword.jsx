import { Field, Formik, Form as FormikForm } from "formik";
import React, { useContext, useState } from "react";
import { Button, Container, Modal, Row } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";
import { object, ref, string } from "yup";

import closeIcon from "../../assets/images/close.svg";
import saveIcon from "../../assets/images/save.svg";

import hidePasswordIcon from "../../assets/images/hide-password.png";
import showPasswordIcon from "../../assets/images/show-password.png";

import ToastContext from "../../context/ToastContext";
import userService from "../../services/userService";

const passwordRegex = /^(?=.*\d)(?=.*[a-zA-Z]).{6,}$/;

export default function ChangePassword() {
  const location = useLocation();
  const toastContext = useContext(ToastContext);
  const [showModal, setShowModal] = useState(false);
  const [errorKey, setErrorKey] = useState(null);
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);

  const from = location.state?.prevPath || "/";
  const navigate = useNavigate();

  const initialChangePasswordForm = {
    oldPassword: "",
    newPassword: "",
    confirmNewPassword: "",
  };

  const changePasswordValidation = object().shape({
    oldPassword: string().required("Please enter old password!"),
    newPassword: string()
      .required("Please enter new password!")
      .min(6, "New password is not valid. Try again.")
      .matches(passwordRegex, "New password is not valid. Try again."),
    confirmNewPassword: string()
      .required("Those passwords didn't match. Try again.")
      .oneOf([ref("newPassword")], "Those passwords didn't match. Try again."),
  });

  const convertPasswordWithSpecialChar = (str) => {
    const encoder = new TextEncoder();

    let passwordWithSpecialChar = encoder.encode(str);

    return btoa(String.fromCharCode(...passwordWithSpecialChar));
  };

  const handleChangePassword = async (values, setSubmitting) => {
    let submitData = {
      oldPassword: convertPasswordWithSpecialChar(values.oldPassword),
      newPassword: convertPasswordWithSpecialChar(values.newPassword),
    };

    try {
      await userService.changePassword(submitData);
      toastContext.setToastState({
        actionState: true,
        showToast: true,
        delay: 5000,
        message:
          "Change password successfully! \n Please log in with your new password.",
      });
      localStorage.removeItem("token");
      navigate("/log-in");

      setSubmitting(false);
    } catch (errors) {
      setSubmitting(false);

      const errorResponse = errors.response?.data;

      if (
        errorResponse.errorKey ===
        "exception.input.validation.password.incorrect"
      ) {
        setErrorKey(errors.response?.data.errorKey);
      } else {
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Something went wrong. Please try again.",
        });
      }
    }
  };

  const handleCancelChangePassword = (values) => {
    if (
      values.oldPassword.length === 0 &&
      values.newPassword.length === 0 &&
      values.confirmNewPassword.length === 0
    ) {
      navigate(from);
    } else {
      setShowModal(true);
    }
  };

  const handleDiscardChanges = (resetForm) => {
    resetForm();
    setShowModal(false);
    navigate(from);
  };

  const handleOldPasswordChange = (e, setFieldValue) => {
    setFieldValue(e.target.name, e.target.value);
    setErrorKey(null);
  };

  return (
    <Container>
      <div id="change-password-page">
        <div className="change-password-container">
          <Row className="password-title">
            <h3>Change Password</h3>
          </Row>
          <Formik
            initialValues={initialChangePasswordForm}
            validationSchema={changePasswordValidation}
            onSubmit={(values, { setSubmitting }) => {
              handleChangePassword(values, setSubmitting);
            }}
          >
            {({
              values,
              errors,
              touched,
              handleBlur,
              isSubmitting,
              setFieldValue,
              resetForm,
            }) => (
              <FormikForm className="change-password-form">
                <Row className="password-buttons">
                  <button
                    type="submit"
                    className="save-button"
                    disabled={isSubmitting}
                  >
                    <img src={saveIcon} alt="Save" />
                  </button>
                  <button
                    className="close-button"
                    type="button"
                    onClick={() => handleCancelChangePassword(values)}
                  >
                    <img src={closeIcon} alt="Close" />
                  </button>
                </Row>
                <Row className="password-row">
                  <label className="password-label">Old Password</label>
                  <div className="field-wrapper">
                    <input
                      className="password-textbox"
                      name="oldPassword"
                      type={showOldPassword ? "text" : "password"}
                      onChange={(e) => {
                        handleOldPasswordChange(e, setFieldValue);
                      }}
                      onBlur={handleBlur}
                      values={values.oldPassword}
                    />
                    {values.oldPassword && (
                      <Button
                        className="eye-button"
                        onClick={() => setShowOldPassword(!showOldPassword)}
                      >
                        {showOldPassword ? (
                          <img src={hidePasswordIcon} alt="Hide Password" />
                        ) : (
                          <img src={showPasswordIcon} alt="Show Password" />
                        )}
                      </Button>
                    )}

                    {touched.oldPassword && errors.oldPassword && (
                      <span
                        md={{ span: 6, offset: 6 }}
                        className="password-verified"
                      >
                        {errors.oldPassword}
                      </span>
                    )}

                    {errorKey ===
                      "exception.input.validation.password.incorrect" && (
                      <span className="password-verified">
                        Password is not correct.
                      </span>
                    )}
                  </div>
                </Row>

                <Row className="password-row">
                  <label className="password-label">New Password</label>

                  <div className="field-wrapper">
                    <Field
                      className="password-textbox"
                      name="newPassword"
                      type={showNewPassword ? "text" : "password"}
                    />

                    {values.newPassword && (
                      <Button
                        className="eye-button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                      >
                        {showNewPassword ? (
                          <img src={hidePasswordIcon} alt="Hide Password" />
                        ) : (
                          <img src={showPasswordIcon} alt="Show Password" />
                        )}
                      </Button>
                    )}

                    {touched.newPassword && errors.newPassword && (
                      <span
                        md={{ span: 6, offset: 6 }}
                        className="password-verified"
                      >
                        {errors.newPassword}
                      </span>
                    )}
                  </div>
                </Row>
                <Row className="password-row">
                  <label className="password-label"></label>

                  <div className="field-wrapper">
                    <Field
                      className="password-textbox"
                      name="confirmNewPassword"
                      type={showNewPassword ? "text" : "password"}
                      placeholder="Re-enter new password"
                    />

                    {values.confirmNewPassword && (
                      <Button
                        className="eye-button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                      >
                        {showNewPassword ? (
                          <img src={hidePasswordIcon} alt="Hide Password" />
                        ) : (
                          <img src={showPasswordIcon} alt="Show Password" />
                        )}
                      </Button>
                    )}

                    {touched.confirmNewPassword &&
                      errors.confirmNewPassword && (
                        <span
                          md={{ span: 6, offset: 6 }}
                          className="password-verified"
                        >
                          {errors.confirmNewPassword}
                        </span>
                      )}
                  </div>
                </Row>
                <span id="password-help-block" muted>
                  (Password must be more than 5 characters and have at least 1
                  number)
                </span>

                <Modal show={showModal} onHide={() => setShowModal(false)}>
                  <Modal.Header className="modal-header">
                    <Modal.Title className="modal-title">
                      Unsaved changes
                    </Modal.Title>
                  </Modal.Header>
                  <Modal.Body className="modal-body">
                    Are you sure you want to discard changes?
                  </Modal.Body>
                  <Modal.Footer className="modal-footer">
                    <Button
                      id="skill-cancel"
                      onClick={() => setShowModal(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      id="skill-discard"
                      onClick={() => handleDiscardChanges(resetForm)}
                    >
                      Discard
                    </Button>
                  </Modal.Footer>
                </Modal>
              </FormikForm>
            )}
          </Formik>
        </div>
      </div>
    </Container>
  );
}
