import { Container, Row } from "react-bootstrap";
import SkillChart from "../../components/charts/SkillChart";
import { useLoaderData, useParams } from "react-router";
import statisticsService from "../../services/statisticsService";

export default function SkillDemandReport() {
  const { year } = useParams();
  const statisticData = useLoaderData();

  return (
    <Container>
      <Row className="statistic-title">
        <h3>{year} Skills demand report </h3>
      </Row>
      <SkillChart statisticDetails={statisticData} />
    </Container>
  );
}

export async function getStatisticData(year) {
  const response = await statisticsService.getStatistics(year);
  const statisticData = response.data;

  return { statisticData };
}
