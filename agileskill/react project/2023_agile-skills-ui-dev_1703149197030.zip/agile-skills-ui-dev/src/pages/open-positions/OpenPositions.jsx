import React, { useState, useEffect, useCallback, useContext } from "react";
import { Col, Container, Row, Modal, Button } from "react-bootstrap";
import { useLoaderData, useNavigate, Link } from "react-router-dom";
import ToastContext from "../../context/ToastContext";
import { Field, Form, Formik } from "formik";

import authService from "../../services/authService";
import positionService from "../../services/positionService";
import closeIcon from "../../assets/images/close.svg";

export default function OpenPositions() {
  const { totalQuantity, totalPositionList } = useLoaderData();
  const navigate = useNavigate();
  const toastContext = useContext(ToastContext);

  const [showModal, setShowModal] = useState(false);
  const [token, setToken] = useState(null);
  const [selectedPosition, setSelectedPosition] = useState(null);

  const orderedList = totalPositionList
    .filter((pos) => pos.status === "OPEN")
    .sort((a, b) => {
      return (
        a.name.localeCompare(b.name) ||
        a.teamName.localeCompare(b.teamName) ||
        a.departmentName.localeCompare(b.departmentName)
      );
    });

  const [filteredPositionList, setFilteredPositionList] = useState(orderedList);

  const getTokenFromLocalStorage = useCallback(() => {
    return authService.getToken();
  }, []);

  useEffect(() => {
    if (getTokenFromLocalStorage !== null) {
      setToken(getTokenFromLocalStorage);
    }
  }, [token, getTokenFromLocalStorage]);

  const handleConfirmClose = (pos) => {
    setShowModal(true);
    setSelectedPosition(pos);
  };

  const handleClosePosition = async () => {
    try {
      await positionService.closePosition(selectedPosition.id);
      setShowModal(false);
      toastContext.setToastState({
        actionState: true,
        showToast: true,
        message: "Close successfully!",
      });
      setTimeout(() => {
        window.location.reload();
      }, 800);
    } catch (error) {
      if (
        error.response.data.errorKey === "exception.resource.not.found.position"
      ) {
        setShowModal(false);
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Position not found!",
        });
        setTimeout(() => {
          window.location.reload();
        }, 800);
      } else {
        setShowModal(false);
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Something went wrong.",
        });
      }
    }
  };

  const handleSearch = async (e) => {
    const word = e.searchBar.toLowerCase().trim();
    const modifiedWord = word.replace(/#/g, "!").replace(/\+/g, "@");
    let returnedPositionList = [];

    const response = await positionService.search(modifiedWord);

    returnedPositionList = response.data;

    const searchOrderList = returnedPositionList
      .filter((pos) => pos.status === "OPEN")
      .sort((a, b) => {
        return (
          a.name.localeCompare(b.name) ||
          a.teamName.localeCompare(b.teamName) ||
          a.departmentName.localeCompare(b.departmentName)
        );
      });

    setFilteredPositionList(searchOrderList);
  };

  return (
    <Container className="position-list">
      <div className="opening-positions py-3">
        <p>Opening Positions: {totalQuantity}</p>
        <Formik
          initialValues={{
            searchBar: "",
          }}
          onSubmit={handleSearch}
        >
          {({ resetForm, values, handleChange }) => (
            <Form className="h-100">
              <div className="search-wrapper">
                <Field
                  id="searchBar"
                  type="text"
                  name="searchBar"
                  value={values.searchBar}
                  onChange={handleChange}
                  placeholder=""
                  className=" position-search"
                />
                {values.searchBar && (
                  <span className="cancel-search" onClick={resetForm}>
                    <img src={closeIcon} alt="Close" />
                  </span>
                )}
              </div>

              <span className="span-search-button">
                <Button id="search-button" type="submit">
                  Search
                </Button>
              </span>
            </Form>
          )}
        </Formik>
      </div>
      <div>
        {filteredPositionList.map((pos) => {
          return (
            <Row key={pos.id} className="position-item mb-1">
              <Col className="position-col title d-flex flex-column" xs={2}>
                <div className="dept-name fw-bold">{pos.departmentName}</div>
                <div className="position-info">
                  <Link to={`/positions/${btoa(pos.id)}`}>
                    <p className="position-name my fw-bold">{pos.name}</p>
                  </Link>
                  <p className="team-name my "> team {pos.teamName}</p>
                  <p className="quantity my ">Quantity: {pos.quantity}</p>
                </div>
              </Col>
              <Col className="position-col required-skill-list py-3" xs={2}>
                {pos.requiredSkillList.map((skill, index) => {
                  if (index < 4) {
                    return (
                      <p
                        key={skill.id}
                        className="position-list-skill-name pt-0 mb-3"
                      >
                        {index + 1}.&nbsp;{skill.skillName}
                      </p>
                    );
                  } else if (index === 4) {
                    return (
                      <p
                        key={skill.id}
                        className="position-list-skill-name-more"
                      >
                        ...
                      </p>
                    );
                  }
                  return null;
                })}
              </Col>

              <Col
                className="position-col position-description "
                xs={token ? 7 : 8}
              >
                <div className="description-content">{pos.note}</div>
              </Col>
              {token !== null && (
                <Col className="position-col button-group" xs={1}>
                  <div
                    className="btn close-button"
                    onClick={() => handleConfirmClose(pos)}
                  >
                    Close
                  </div>
                  <div
                    className="btn update-button"
                    onClick={() => navigate(`/update-position/${btoa(pos.id)}`)}
                  >
                    Update
                  </div>
                </Col>
              )}
            </Row>
          );
        })}
      </div>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header className="position-modal-header">
          <Modal.Title className="position-modal-title">
            Close Position
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="position-modal-body">
          Are you sure that you want to close{" "}
          <b className="position-text">{selectedPosition?.name}</b> Position in
          Team <b className="position-text">{selectedPosition?.teamName}</b> -
          Department{" "}
          <b className="position-text">{selectedPosition?.departmentName}</b>?
        </Modal.Body>
        <Modal.Footer className="position-detail-modal-footer">
          <Button id="position-cancel" onClick={() => setShowModal(false)}>
            No
          </Button>
          <Button id="position-discard" onClick={handleClosePosition}>
            Yes
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}

export async function getTotalPositions() {
  let totalQuantity = 0;
  let totalPositionList = [];
  const response = await positionService.getPositionList();
  totalPositionList = response.data;
  for (const pos of response.data) {
    totalQuantity += pos.quantity;
  }

  return { totalQuantity, totalPositionList };
}
