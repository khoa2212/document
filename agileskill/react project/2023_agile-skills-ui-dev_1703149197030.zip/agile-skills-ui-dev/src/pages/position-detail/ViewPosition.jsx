import {
  Container,
  Row,
  Modal,
  Button,
  ToastContainer,
  Toast,
} from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import { useCallback, useEffect, useState, useRef } from "react";

import authService from "../../services/authService";
import positionService from "../../services/positionService";
import slugGenerator from "../../services/slugGenerator";
import RequiredSkillDetail from "../../components/view-required-skill-detail/RequiredSkillDetail";

export default function ViewPosition() {
  const [showModal, setShowModal] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const navigate = useNavigate();
  const [token, setToken] = useState(null);
  const [position, setPosition] = useState("");

  const { positionIdBase64 } = useParams();
  const positionId = useRef("");
  const result = useRef(null);

  const getTokenFromLocalStorage = useCallback(() => {
    return authService.getToken();
  }, []);

  useEffect(() => {
    if (getTokenFromLocalStorage !== null) {
      setToken(getTokenFromLocalStorage);
    }
  }, [token, getTokenFromLocalStorage]);

  try {
    positionId.current = atob(positionIdBase64);
  } catch {
    navigate("/not-found");
  }

  useEffect(() => {
    positionService
      .getPositionWithRequiredSkillAndTopic(positionId.current)
      .then((response) => {
        result.current = response.data;
        let str = slugGenerator(result.current.name);
        let newURL =
          window.location.origin + "/positions/" + positionIdBase64 + "/" + str;
        window.history.replaceState(null, "", newURL);
        result.current.status === "CLOSE"
          ? navigate("/not-found")
          : setPosition(response.data);
      })
      .catch(() => {
        navigate("/not-found");
      });
  }, [positionId, positionIdBase64, navigate]);

  const handleConfirmClose = () => {
    setShowModal(true);
  };

  const handleClosePosition = async () => {
    await positionService.closePosition(positionId.current);
    setShowModal(false);
    setShowToast(true);
    setTimeout(() => {
      navigate("/skills-by-position");
    }, 1000);
  };
  return (
    <Container id="position-detail">
      <div>
        <ToastContainer id="toast-container" className="p-3">
          <Toast show={showToast} delay={1000} autohide>
            <Toast.Body className="bg-success">Close successfully!</Toast.Body>
          </Toast>
        </ToastContainer>
      </div>
      <div className="d-flex justify-content-between">
        <div className="d-flex justify-content-start">
          <div className="col-dept-name fw-bold">{position.departmentName}</div>
          <div className="col-team-name">Team: {position.teamName}</div>
        </div>
        {token !== null && (
          <>
            <div
              xs={1}
              className="button-group d-flex justify-content-between me-1"
            >
              <div
                className="btn update-button mx-2"
                onClick={() => navigate(`/update-position/${positionIdBase64}`)}
              >
                Update
              </div>

              <div
                className="btn close-button mx-2"
                onClick={handleConfirmClose}
              >
                Close
              </div>
            </div>
          </>
        )}
      </div>
      <Row>
        <p className="position-name">{position.name}</p>
        <p className="position-quantity">Quantity: {position.quantity}</p>
        <p className="position-note">{position.note}</p>
      </Row>
      {position.requiredSkillList?.length > 0 && (
        <RequiredSkillDetail position={position} setPosition={setPosition} />
      )}

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header className="position-modal-header">
          <Modal.Title className="position-modal-title">
            Close Position
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="position-modal-body">
          {result.current && (
            <div>
              Are you sure that you want to close&nbsp;
              <b className="position-text">{result.current.name}</b> Position in
              Team <b className="position-text">{result.current.teamName}</b> -
              Department&nbsp;
              <b className="position-text">{result.current.departmentName}</b>?
            </div>
          )}
        </Modal.Body>
        <Modal.Footer className="position-detail-modal-footer">
          <Button id="position-cancel" onClick={() => setShowModal(false)}>
            No
          </Button>
          <Button id="position-discard" onClick={handleClosePosition}>
            Yes
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}
