import { useState, useContext } from "react";
import { Modal, Button, Container, Row } from "react-bootstrap";
import React from "react";

import ToastContext from "../../context/ToastContext";
import skillService from "../../services/skillService";
import Template from "./TemplateDownload";

export default function ImportSkill() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [data, setData] = useState([""]);
  const toastContext = useContext(ToastContext);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);

  const [uploadSuccessful, setUploadSuccessful] = useState(false);
  const [fileName, setFileName] = useState(null);

  const fileInputRef = React.createRef();

  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
    setMessage("");
    if (selectedFile) {
      setFileName(selectedFile.name);
    }
  };

  const handleDiscardChanges = () => {
    setFile(null);
    setFileName(null);
    setMessage("");
    setShowConfirmationModal(false);
  };

  const handleSubmit = async () => {
    if (!file) {
      setMessage("Please select a file.");
      return;
    }
    if (
      !(
        file.type === "application/vnd.ms-excel" || // .xls
        file.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      ) // .xlsx
    ) {
      setMessage(
        "Invalid file type. Please select an Excel file (.xls or .xlsx)."
      );
      return;
    }
    try {
      const response = await skillService.importSkillList(file);
      setUploadSuccessful(true);
      setData(response.data);
      toastContext.setToastState({
        actionState: true,
        showToast: true,
        message: "File upload successfully!",
      });
      setShowConfirmationModal(false);
      setFile(null);
      setFileName(null);
    } catch (error) {
      if (error.message === "Network Error") {
        // Handle network connection error
        toastContext.setToastState({
          actionState: false,
          showToast: true,
          message: "Something went wrong. Please try again.",
        });
      } else {
        const errorResponse = error.response?.data;

        if (
          errorResponse?.errorKey ===
          "exception.input.validation.file.template.not.supported"
        ) {
          setMessage("Wrong Template Format!");
        } else if (
          errorResponse?.errorKey ===
          "exception.input.validation.data.not.found"
        ) {
          toastContext.setToastState({
            actionState: false,
            showToast: true,
            message: "Data not found.",
          });
        } else {
          // Handle other exceptions
          toastContext.setToastState({
            actionState: false,
            showToast: true,
            message: "Something went wrong. Please try again.",
          });
        }
      }
    }
  };

  const handleHideModal = () => {
    setFile(null);
    setFileName(null);
    setShowConfirmationModal(false);
  };

  const MAX_LENGTH = 20;
  const renderSkippedSkillList = (skippedSkillList) => {
    let resultArray = [];
    for (const property in skippedSkillList) {
      resultArray.push({
        skillName: property,
        skillDescription: skippedSkillList[property],
      });
    }
    return resultArray.map((e, index) => {
      return (
        <div key={index} className="data-error ">
          {index + 1}.{" "}
          {e.skillName.length > MAX_LENGTH
            ? `${e.skillName.slice(0, MAX_LENGTH)}...`
            : e.skillName}
          : {e.skillDescription}
        </div>
      );
    });
  };

  return (
    <Container>
      <h4>Import Data</h4>
      <Row>
        <button
          onClick={() => setShowConfirmationModal(true)}
          className="file-button-box col-md-3"
          size="lg"
        >
          Upload Skills & Topics
        </button>
        <div className="col-md-2 ">
          <Template />
        </div>
      </Row>
      <Modal
        show={showConfirmationModal}
        onHide={() => {
          handleHideModal();
        }}
      >
        <Modal.Header className="modal-header">
          <Modal.Title className="modal-title">Import File</Modal.Title>
        </Modal.Header>
        <Modal.Body className="modal-file-body">
          <div>
            <button className="custom-file-upload" onClick={handleButtonClick}>
              Choose File
            </button>
            <input
              id="input-file"
              type="file"
              accept=".xls, .xlsx"
              ref={fileInputRef}
              onChange={handleFileChange}
            />

            {fileName === null ? (
              <span> Choose your file</span>
            ) : (
              <span> {fileName}</span>
            )}
          </div>
          <div className="error-message">{message}</div>
        </Modal.Body>
        <Modal.Footer className="modal-footer">
          <Button onClick={handleSubmit} id="skill-upload">
            Upload
          </Button>
          <Button onClick={handleDiscardChanges} id="skill-discard">
            Cancel
          </Button>
        </Modal.Footer>
      </Modal>

      <div className="file-upload-report">
        {uploadSuccessful && data !== null && (
          <div>
            <div className="file-imported">
              {data.importedList.length > 0 && (
                <>
                  <div>{data.importedList.length} Skill(s) were imported</div>
                  {data.importedList.map((item, index) => (
                    <div key={index} className="data-imported">
                      {index + 1}. {item.name}
                    </div>
                  ))}
                  <hr />
                </>
              )}
            </div>

            <div className="file-imported">
              {data.existedSkillList.length > 0 && (
                <div>{data.existedSkillList.length} Skill(s) already exist</div>
              )}
            </div>
            {data.existedSkillList.map((item, index) => (
              <div key={index} className="data-error">
                {index + 1}. {item.name}
              </div>
            ))}
            <div className="file-imported">
              {Object.keys(data.skippedSkillList).length > 0 && (
                <div>
                  {Object.keys(data.skippedSkillList).length} Skill(s) were
                  skipped due to errors
                </div>
              )}
            </div>
            {renderSkippedSkillList(data.skippedSkillList)}
          </div>
        )}
      </div>
    </Container>
  );
}
