import React from 'react';
import { saveAs } from 'file-saver';

function TemplateDownload() {
  const TEMPLATE_FILE_PATH = "/templates/SkillListTemplate.xlsx";
    const downloadTemplate = async () => {
        try {
          // Fetch the template file as a binary array
          const response = await fetch(TEMPLATE_FILE_PATH);
          const templateData = await response.blob();
    
          // Trigger the download using FileSaver.js
          saveAs(templateData, 'template-file.xlsx'); // Replace 'template-file.xlsx' with the desired file name
        } catch (error) {
          console.error('Error downloading template:', error);
        }
      };

  return (
    <div>
      <a href="#" onClick={downloadTemplate} className='template' >Get Template</a>
    </div>
  );
}

export default TemplateDownload;
