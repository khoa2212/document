import axios from "axios";

export const request = axios.create({
  baseURL: process.env.REACT_APP_API_ENDPOINT,
});

request.interceptors.request.use((config) => {
  let token = localStorage.getItem("token");

  if (token) {
    token = JSON.parse(token);
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});
