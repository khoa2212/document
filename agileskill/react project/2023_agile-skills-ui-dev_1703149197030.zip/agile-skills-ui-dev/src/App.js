import {
  RouterProvider,
  createBrowserRouter,
  Navigate,
} from "react-router-dom";
import ThemeProvider from "react-bootstrap/ThemeProvider";

import HomeLayout from "./layout/HomeLayout";
import About from "./pages/about/About";
import SkillsList from "./pages/skills-list/SkillsList";
import ViewSkill from "./pages/view-skill/ViewSkill";
import Home from "./pages/home/Home";
import UnderConstruction from "./pages/under-construction/UnderConstruction";
import NotFound from "./pages/not-found/NotFound";
import AccessDenied from "./pages/access-denied/AccessDenied";
import NewSkill from "./pages/new-skill/NewSkill";
import NewUserPage from "./pages/new-user/NewUserPage";
import Login from "./pages/login/Login";
import SkillDemandReport, {
  getStatisticData,
} from "./pages/skill-demand-report/SkillDemandReport";
import {
  checkAdminLoader,
  checkExpiredToken,
  checkLoggedInLoader,
  checkRegisteredUserLoader,
} from "./utils/authLoader";
import AuthorizationGuard from "./guards/AuthorizationGuard";
import AuthenticationGuard from "./guards/AuthenticationGuard";
import OpenPositions, {
  getTotalPositions,
} from "./pages/open-positions/OpenPositions";
import ViewPosition from "./pages/position-detail/ViewPosition";
import TokenGuard from "./guards/TokenGuard";
import Statistic from "./pages/statistic/Statistic";
import NewPosition, {
  getRequiredDataForPosition,
} from "./pages/new-position/NewPosition";
import UpdatePosition, {
  getRequiredDataForUpdatePosition,
} from "./pages/update-position/UpdatePosition";
import ImportSkill from "./pages/import/ImportSkill";
import ChangePassword from "./pages/change-password/ChangePassword";
import UpdateSkill, {
  getRequiredDataForUpdateSkill,
} from "./pages/update-skill/UpdateSkill";
import { getPositionWithFileList } from "./pages/relation-graph/RelationGraphWithDagreTree";
import RelationGraphContainer from "./pages/relation-graph/RelationGraphContainer";
import RelationGraphDetail from "./pages/relation-graph/RelationGraphDetail";

function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <TokenGuard />,
      loader: checkExpiredToken,
      children: [
        {
          path: "/",
          element: <HomeLayout />,
          children: [
            {
              path: "/",
              element: <Home />,
            },
            {
              path: "/open-positions",
              element: <OpenPositions />,
              loader: getTotalPositions,
            },
            {
              path: "/relation-graphs",
              element: <RelationGraphContainer />,
              loader: getTotalPositions,
            },
            {
              path: "/relation-graphs/:positionIdBase64/*",
              element: <RelationGraphDetail />,
              loader: async ({ params }) =>
                await getPositionWithFileList(params.positionIdBase64),
            },
            {
              path: "/positions/:positionIdBase64/*",
              element: <ViewPosition />,
            },
            {
              path: "/skills-list",
              element: <SkillsList />,
            },
            {
              path: "/skills/:skillIdBase64/*",
              element: <ViewSkill />,
            },
            {
              path: "/about",
              element: <About />,
            },
            {
              path: "/not-found",
              element: <NotFound />,
            },
            {
              path: "/forget-password",
              element: <UnderConstruction />,
            },
            {
              path: "*",
              element: <Navigate to="/not-found" />,
            },
            {
              path: "/access-denied",
              element: <AccessDenied />,
            },

            {
              path: "/",
              element: <AuthorizationGuard />,
              loader: checkRegisteredUserLoader,
              children: [
                {
                  path: "/new-skill",
                  element: <NewSkill />,
                },
                {
                  path: "/update-skill/:skillIdBase64/*",
                  element: <UpdateSkill />,
                  loader: ({ params }) =>
                    getRequiredDataForUpdateSkill(params.skillIdBase64),
                },
                {
                  path: "/new-position",
                  element: <NewPosition />,
                  loader: getRequiredDataForPosition,
                },
                {
                  path: "/update-position/:positionIdBase64/*",
                  element: <UpdatePosition />,
                  loader: ({ params }) =>
                    getRequiredDataForUpdatePosition(params.positionIdBase64),
                },
                {
                  path: "/import-data",
                  element: <ImportSkill />,
                },
                {
                  path: "/department-team",
                  element: <UnderConstruction />,
                },
                {
                  path: "/edit-skill-by-position",
                  element: <UnderConstruction />,
                },
                {
                  path: "/close-skill-by-position",
                  element: <UnderConstruction />,
                },
                {
                  path: "/statistic",
                  element: <Statistic />,
                },
                {
                  path: "/skill-demand-report/:year",
                  element: <SkillDemandReport />,
                  loader: ({ params }) => {
                    return getStatisticData(params.year);
                  },
                },
                {
                  path: "/change-password",
                  element: <ChangePassword />,
                },
                {
                  path: "/",
                  loader: checkAdminLoader,
                  children: [
                    {
                      path: "/new-user",
                      element: <NewUserPage />,
                    },
                    {
                      path: "/manage-user",
                      element: <UnderConstruction />,
                    },
                  ],
                },
              ],
            },
            {
              path: "/",
              element: <AuthenticationGuard />,
              loader: checkLoggedInLoader,
              children: [
                {
                  path: "/log-in",
                  element: <Login />,
                },
              ],
            },
          ],
        },
      ],
    },
  ]);
  return (
    <RouterProvider router={router}>
      <ThemeProvider
        breakpoints={["xxxl", "xxl", "xl", "lg", "md", "sm", "xs", "xxs"]}
        minBreakpoint="xxs"
      ></ThemeProvider>
    </RouterProvider>
  );
}

export default App;
