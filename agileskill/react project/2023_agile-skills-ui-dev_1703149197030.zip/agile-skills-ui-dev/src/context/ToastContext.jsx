import { createContext, useState } from "react";
import { Toast, ToastContainer } from "react-bootstrap";

const DEFAULT_VALUE = {
  actionState: false,
  showToast: false,
  delay: null,
  message: "",
};

const ToastContext = createContext(DEFAULT_VALUE);

export const ToastContextProvider = (props) => {
  const [toastState, setToastState] = useState(DEFAULT_VALUE);

  return (
    <ToastContext.Provider value={{ setToastState }}>
      {toastState.showToast && (
        <ToastContainer id="universe-toast">
          <Toast
            id="toast-container"
            onClose={() =>
              setToastState({
                actionState: false,
                showToast: false,
                message: "",
              })
            }
            show={toastState.showToast}
            delay={toastState.delay ? toastState.delay : 2500}
            autohide
          >
            <Toast.Body
              className={`${
                toastState.actionState ? "bg-success" : "bg-danger"
              } fw-bold universe-toast-body`}
            >
              {toastState.message}
            </Toast.Body>
          </Toast>
        </ToastContainer>
      )}
      {props.children}
    </ToastContext.Provider>
  );
};

export default ToastContext;
