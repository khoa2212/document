UPDATE "position"
SET opened_date  = created_date
WHERE opened_date  IS NULL;