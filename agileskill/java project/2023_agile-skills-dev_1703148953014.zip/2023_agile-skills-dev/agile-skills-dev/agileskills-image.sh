#! /bin/sh

if [ ! -x "$0" ]; then
   echo "The script is not executable. Use 'chmod +x $0' to allow it to run."
   exit 1
fi

echo "Step 1: Building the Agile Skills project..."
mvn clean package -DskipTests

# Check if the agile-skills build was successful
if [ $? -ne 0 ]; then
  echo "Maven build failed. Aborting Docker image creation."
  exit 1
fi

echo "Step 2: Building the Docker image..."
sudo docker build -f Dockerfile -t agileskills-api .

# Check if the Docker build was successful
if [ $? -ne 0 ]; then
  echo "Docker image build failed."
  exit 1
fi

echo "Docker image successfully built and tagged as agileskills-api."

echo "Step 3: Redeploy the kubernetes pod..."
sudo kubectl get pods -n agileskills | grep -i 'agileskills-api-' | awk '{print $1}' | xargs sudo kubectl delete pod -n agileskills

# ** kubectl set image deployment/agileskills-api *=agileskills-api:latest **

# if old and new image have different tag, can use this cmd to update pods without delete. You can edit in agileskills-image.sh.

if [ $? -ne 0 ]; then
  echo "Redeploy the kubernetes pod failed."
  exit 1
fi

echo "Redeploy the kubernetes pod successfully built "
