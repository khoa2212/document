package com.axonactive.agileskills.base.entity;

public enum StatusEnum {
    ACTIVE,
    INACTIVE
}
