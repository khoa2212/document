package com.axonactive.agileskills.email;

import com.axonactive.agileskills.base.config.EmailConfig;
import com.axonactive.agileskills.base.exception.AgileSkillsException;
import com.axonactive.agileskills.base.exception.ErrorMessage;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.skill.topic.attachment.service.AttachmentService;
import com.axonactive.agileskills.skill.topic.attachment.service.model.FileInfo;

import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.List;
import java.util.Properties;

@Stateless
public class EmailService {
    public static final String DATABASE = "DATABASE";
    public static final String STORAGE = "STORAGE";
    private final Properties properties = new Properties();
    private final String HOST_NAME = EmailConfig.getHostName();

    private final int SSL_PORT = EmailConfig.GetSSLPort(); // Port for SSL

    private final int TLS_PORT = EmailConfig.getTLSPort(); // Port for TLS/STARTTLS

    private final String APP_EMAIL = EmailConfig.getAppEmail(); // your email

    private final String APP_PASSWORD = EmailConfig.getAppPassword(); // your password

    private final String RECEIVE_EMAIL = EmailConfig.getReceiveEmail(); // your email
    @Inject
    private AttachmentService attachmentService;

    @Schedule(hour = "6")
    public void sendDailyEmail() throws AgileSkillsException, ResourceNotFoundException {
        // Get properties object
        setUpMailConfig();

        // get Session
        Session session = getSession();

        List<FileInfo> inconsistentData = attachmentService.getAllInconsistentData();
        boolean hasNoData = inconsistentData.isEmpty();

        // compose message
        try {
            if (!hasNoData) {

                MimeMessage message = new MimeMessage(session);
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(RECEIVE_EMAIL));
                message.setSubject("Daily Inconsistent Data Report in AgileSkills");

                StringBuilder messageContent = new StringBuilder();

                boolean hasStorageData = inconsistentData.stream().anyMatch(data -> STORAGE.equals(data.getPlace()));
                boolean hasDatabaseData = inconsistentData.stream().anyMatch(data -> DATABASE.equals(data.getPlace()));

                if (hasStorageData) {
                    messageContent.append("List of files appear in storage but missing in database:\n");
                    for (FileInfo data : inconsistentData) {
                        if (data.getPlace().equals(STORAGE)) {
                            messageContent.append(String.format("Skill name: %s , Skill id: %s , Topic name: %s , Topic id: %s , File name: %s\n",
                                    data.getSkillName(),
                                    data.getSkillId(),
                                    data.getTopicName(),
                                    data.getTopicId(),
                                    data.getFileName()));
                        }

                    }
                }
                if (hasDatabaseData) {
                    messageContent.append("\nList of files appear in database but missing in storage:\n");
                    for (FileInfo data : inconsistentData) {
                        if (data.getPlace().equals(DATABASE)) {
                            messageContent.append(String.format("Skill name: %s , Skill id: %s , Topic name: %s , Topic id: %s , File name: %s\n",
                                    data.getSkillName(),
                                    data.getSkillId(),
                                    data.getTopicName(),
                                    data.getTopicId(),
                                    data.getFileName()));
                        }

                    }
                }
                messageContent.append("\n Best Regards,\n Mocha Team");
                message.setText(messageContent.toString());

                // send message
                Transport.send(message);
            }
        } catch (MessagingException e) {
            throw new AgileSkillsException(ErrorMessage.KEY_EMAIL_SEND_FAILED, ErrorMessage.EMAIL_SEND_FAILED);
        }
    }

    private void setUpMailConfig() {
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.host", HOST_NAME);
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.port", TLS_PORT);
    }

    private Session getSession() {
        return Session.getInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(APP_EMAIL, APP_PASSWORD);
            }
        });
    }
}
