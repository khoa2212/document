package com.axonactive.agileskills.position.rest;

import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.base.security.utility.JwtUtils;
import com.axonactive.agileskills.position.entity.PositionEntity;
import com.axonactive.agileskills.position.service.PositionService;
import com.axonactive.agileskills.position.service.mapper.PositionMapper;
import com.axonactive.agileskills.position.service.model.Position;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;

import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_NULL_SEARCH_WORD;
import static com.axonactive.agileskills.position.entity.PositionStatusEnum.OPEN;

@Path("/positions")
@Api(tags = {"Position"})
public class PositionResource {

    @Inject
    private PositionService positionService;

    @Inject
    private JwtUtils jwtUtils;

    @Inject
    private PositionMapper positionMapper;

    @GET
    @Path("/{id}/updating")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get position for updating")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get position by successfully", response = Position.class),
            @ApiResponse(code = 404, message = "Position not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getPositionForUpdating(@PathParam("id") Long id) throws ResourceNotFoundException {
        PositionEntity positionEntity = positionService.getPositionForUpdating(id, OPEN);
        return Response.ok(positionMapper.toDTO(positionEntity)).build();
    }

    @GET
    @Path("/{id}/filtered")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get filtered open position by id")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get filtered open position by id successfully", response = Position.class),
            @ApiResponse(code = 404, message = "Position not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response displayPositionWithRequiredSkillAndRequiredTopic(@PathParam("id") Long id) throws ResourceNotFoundException {
        PositionEntity displayedPositionEntity = positionService.displayPositionWithRequiredSkillAndRequiredTopic(id);
        return Response.ok(positionMapper.toDTO(displayedPositionEntity)).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get open position list by status open")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get open position list by status open successfully", response = Position.class, responseContainer = "List"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems")
    })
    public Response getOpenList() {
        return Response.ok(positionService.getByStatus(OPEN)).build();
    }

    @DELETE
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @ApiOperation(value = "Close a position", authorizations = {
            @Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 200, message = "Position closed", response = Position.class),
            @ApiResponse(code = 401, message = "Sign-in required"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 404, message = "Position not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response close(@ApiParam(value = "Id of position to be closed", required = true, name = "id")
                          @PathParam("id") Long id) throws ResourceNotFoundException {
        positionService.close(id);
        return Response.noContent().build();
    }

    @GET
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get open position by id")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get open position by id successfully", response = Position.class),
            @ApiResponse(code = 404, message = "Position not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getOpenPositionById(@PathParam("id") Long id) throws ResourceNotFoundException {
        return Response.ok(positionService.getByIdAndStatus(id, OPEN)).build();
    }

    @GET
    @Path("/years")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get open position years", authorizations = {@Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get open position years successfully", response = Position.class),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getByYear() {
        return Response.ok(positionService.getYears()).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @ApiOperation(value = "Create new position with required skill and required topic", authorizations = {@Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 201, message = "Create position successfully", response = Position.class),
            @ApiResponse(code = 400, message = "Request sent to the server is invalid or corrupted"),
            @ApiResponse(code = 401, message = "Sign-in required"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 404, message = "Team not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response createPositionWithRequiredSkill(@ApiParam(value = "Position to be created", required = true, name = "New position's info") Position position)
            throws ResourceNotFoundException, InputValidationException {
        Position newPosition = positionService.createPositionWithRequiredSkill(position);
        return Response.created(URI.create("/positions" + newPosition.getId())).entity(newPosition).build();
    }

    @GET
    @Path("/search")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Search open position by words")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Search open position by words successfully", response = Position.class),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response searchStatusOpenByWords(@QueryParam("word") @NotNull(message = KEY_NULL_SEARCH_WORD) String word) {
        return Response.ok(positionService.searchOpenPositionsByWord(word)).build();
    }

    @PUT
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @ApiOperation(value = "Update position with required skill and required topic", authorizations = {@Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 201, message = "Update position successfully", response = Position.class),
            @ApiResponse(code = 400, message = "Request sent to the server is invalid or corrupted"),
            @ApiResponse(code = 401, message = "Sign-in required"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 404, message = "Position/Team not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response update(@PathParam("id") Long id, Position position) throws InputValidationException, ResourceNotFoundException {
        PositionEntity updatePositionEntity = positionService.update(id, position);
        Position updatePosition = positionMapper.toDTO(updatePositionEntity);
        return Response.ok(updatePosition).build();
    }
}
