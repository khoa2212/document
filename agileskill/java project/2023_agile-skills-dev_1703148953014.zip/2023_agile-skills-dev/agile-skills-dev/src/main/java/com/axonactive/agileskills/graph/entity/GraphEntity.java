package com.axonactive.agileskills.graph.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import static com.axonactive.agileskills.base.exception.ErrorMessage.MAX_LENGTH_GRAPH_VALUE;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "graph")
public class GraphEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "position_value", nullable = false, length = MAX_LENGTH_GRAPH_VALUE)
    private String graphValue;

    @Column(name = "position_id", nullable = false)
    private Long positionId;
}
