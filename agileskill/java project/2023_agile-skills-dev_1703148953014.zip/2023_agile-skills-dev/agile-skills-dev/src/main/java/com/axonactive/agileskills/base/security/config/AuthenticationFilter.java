package com.axonactive.agileskills.base.security.config;

import com.axonactive.agileskills.base.exception.AuthorizationException;
import com.axonactive.agileskills.base.security.utility.JwtUtils;
import com.axonactive.agileskills.user.entity.RoleEnum;
import org.apache.logging.log4j.ThreadContext;

import javax.annotation.Priority;
import javax.inject.Inject;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;
import java.util.UUID;

@Provider
@Priority(Priorities.AUTHENTICATION)
public class AuthenticationFilter implements ContainerRequestFilter {
    @Context
    private ResourceInfo info;

    @Inject
    private JwtUtils jwtUtils;

    @Override
    public void filter(ContainerRequestContext request) {

        String authHeader = request.getHeaderString("Authorization");
        if (isNotValidJwt(authHeader)) {
            SecurityContext sc = new RequestSecurityContext(new UserPrincipal());
            request.setSecurityContext(sc);
            return;
        }

        RoleEnum role = jwtUtils.getRoleFromToken(authHeader);
        String email = jwtUtils.getEmailFromToken(authHeader);
        SecurityContext sc = new RequestSecurityContext(new UserPrincipal(email, role));

        String[] localPart = email.split("@");
        ThreadContext.put("mail", localPart[0] + ":" + UUID.randomUUID().toString().replace("-", "").substring(0, 8));

        request.setSecurityContext(sc);
    }

    private boolean isNotValidJwt(String header) {
        if (header == null) {
            return true;
        }

        try {
            jwtUtils.validateJwtToken(header);
        } catch (AuthorizationException e) {
            return true;
        }

        return !header.startsWith("Bearer ");
    }
}
