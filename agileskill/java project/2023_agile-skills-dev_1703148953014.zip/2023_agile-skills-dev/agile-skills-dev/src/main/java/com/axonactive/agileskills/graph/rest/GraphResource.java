package com.axonactive.agileskills.graph.rest;

import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.graph.service.GraphService;
import com.axonactive.agileskills.graph.service.mapper.GraphMapper;
import com.axonactive.agileskills.graph.service.model.Graph;

import javax.inject.Inject;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/graphs")
public class GraphResource {
    @Inject
    private GraphService graphService;

    @Inject
    private GraphMapper graphMapper;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getPositionGraphByPositionId(@QueryParam("positionId") Long positionId) throws ResourceNotFoundException {
        return Response.ok(graphService.getByPositionId(positionId)).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    public Response save(Graph graph) throws ResourceNotFoundException {
        return Response.ok(graphService.save(graph)).build();
    }

    @DELETE
    @Path("/{positionId}")
    public Response delete(@PathParam("positionId") Long positionId) throws ResourceNotFoundException {
        graphService.delete(positionId);
        return Response.noContent().build();
    }
}
