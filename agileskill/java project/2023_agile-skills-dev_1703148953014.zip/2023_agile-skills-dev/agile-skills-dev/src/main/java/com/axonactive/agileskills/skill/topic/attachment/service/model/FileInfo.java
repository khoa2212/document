package com.axonactive.agileskills.skill.topic.attachment.service.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FileInfo {

    private String skillName;

    private Long skillId;

    private String topicName;

    private Long topicId;

    private String place;

    private String fileName;
}
