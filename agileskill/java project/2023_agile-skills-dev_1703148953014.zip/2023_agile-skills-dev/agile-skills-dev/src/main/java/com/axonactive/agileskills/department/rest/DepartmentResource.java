package com.axonactive.agileskills.department.rest;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.department.service.DepartmentService;
import com.axonactive.agileskills.department.service.model.Department;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/departments")
@Api(tags = {"Departments"})
public class DepartmentResource {

    @Inject
    private DepartmentService departmentService;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get active department list")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get active department list successfully", response = Department.class, responseContainer = "List"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getActiveList() {
        return Response.ok(departmentService.getByStatus(StatusEnum.ACTIVE)).build();
    }
}