package com.axonactive.agileskills.base.config;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.ResourceBundle;

@NoArgsConstructor(access = AccessLevel.PRIVATE)

public class EmailConfig {
    private static final ResourceBundle rb = ResourceBundle.getBundle("email");
    private static final Integer SSL_PORT = Integer.valueOf(rb.getString("SSL_PORT"));
    private static final Integer TLS_PORT = Integer.valueOf(rb.getString("TLS_PORT"));

    public static String getHostName() {
        return rb.getString("HOST_NAME");
    }

    public static String getAppEmail() {
        return rb.getString("APP_EMAIL");
    }

    public static String getAppPassword() {
        return rb.getString("APP_PASSWORD");
    }

    public static String getReceiveEmail() {
        return rb.getString("RECEIVE_EMAIL");
    }

    public static Integer GetSSLPort() {
        return SSL_PORT;
    }

    public static Integer getTLSPort() {
        return TLS_PORT;
    }

}
