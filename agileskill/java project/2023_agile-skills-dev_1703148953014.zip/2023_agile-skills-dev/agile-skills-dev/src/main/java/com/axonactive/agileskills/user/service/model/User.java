package com.axonactive.agileskills.user.service.model;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.user.entity.RoleEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import static com.axonactive.agileskills.base.exception.ErrorMessage.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class User {

    private Long id;

    @Size(max = MAX_SIZE_NAME, message = KEY_USER_NAME_LENGTH_CONSTRAINT)
    private String name;

    @NotBlank(message = KEY_EMAIL_BLANK_OR_NULL)
    @Email(message = KEY_EMAIL_WRONG_FORMAT)
    private String email;

    @ApiModelProperty(example = "encrypted string")
    @NotBlank(message = KEY_PASSWORD_BLANK_OR_NULL)
    private String password;

    @ApiModelProperty(hidden = true)
    private StatusEnum status;

    @ApiModelProperty(example = "ROLE_USER")
    private RoleEnum role;
}
