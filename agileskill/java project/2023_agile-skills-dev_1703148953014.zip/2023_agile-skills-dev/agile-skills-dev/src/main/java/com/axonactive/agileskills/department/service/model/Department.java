package com.axonactive.agileskills.department.service.model;

import com.axonactive.agileskills.base.entity.StatusEnum;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import static com.axonactive.agileskills.base.exception.ErrorMessage.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Department {


    private Long id;

    @NotBlank(message = KEY_DEPARTMENT_NAME_NULL_OR_BLANK)
    @Size(max = MAX_SIZE_NAME, message = KEY_DEPARTMENT_NAME_LENGTH_CONSTRAINT)
    private String name;

    private StatusEnum status;
}
