package com.axonactive.agileskills.skill.service;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.base.exception.ErrorMessage;
import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.base.model.PaginationData;
import com.axonactive.agileskills.base.utility.ExcelUtils;
import com.axonactive.agileskills.skill.dao.SkillDAO;
import com.axonactive.agileskills.skill.entity.SkillEntity;
import com.axonactive.agileskills.skill.service.mapper.SkillMapper;
import com.axonactive.agileskills.skill.service.model.ImportResult;
import com.axonactive.agileskills.skill.service.model.Skill;
import com.axonactive.agileskills.skill.topic.dao.TopicDAO;
import com.axonactive.agileskills.skill.topic.entity.TopicEntity;
import com.axonactive.agileskills.skill.topic.service.TopicService;
import com.axonactive.agileskills.skill.topic.service.mapper.TopicMapper;
import com.axonactive.agileskills.skill.topic.service.model.Topic;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.validator.messageinterpolation.ParameterMessageInterpolator;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static com.axonactive.agileskills.base.entity.StatusEnum.ACTIVE;
import static com.axonactive.agileskills.base.exception.ErrorMessage.DATA_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.DUPLICATED_SKILL_MESSAGE;
import static com.axonactive.agileskills.base.exception.ErrorMessage.DUPLICATED_TOPIC_MESSAGE;
import static com.axonactive.agileskills.base.exception.ErrorMessage.INVALID_SKILL_MESSAGE;
import static com.axonactive.agileskills.base.exception.ErrorMessage.INVALID_TOPIC_MESSAGE;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_DATA_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_SKILL_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_TOPIC_IN_SKILL;
import static com.axonactive.agileskills.base.exception.ErrorMessage.SKILL_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.TOPIC_IN_SKILL;

@Stateless
public class SkillService {

    private static final Validator validator = Validation.byDefaultProvider()
            .configure()
            .messageInterpolator(new ParameterMessageInterpolator())
            .buildValidatorFactory()
            .getValidator();

    public static final String BLANK_SKILL_NAME = "Blank Skill Name";

    @Inject
    private SkillDAO skillDAO;

    @Inject
    private TopicDAO topicDAO;

    @Inject
    private SkillMapper skillMapper;

    @Inject
    private TopicMapper topicMapper;

    @Inject
    private TopicService topicService;

    @Inject
    private SkillListCache skillListCache;

    @Inject
    private ExcelUtils excelUtils;

    @Transactional
    public Skill update(Skill skill, Long id) throws ResourceNotFoundException, InputValidationException {
        SkillEntity skillEntity = getSkillEntityById(id);
        verifySkillForUpdate(skill, skillEntity);
        if (CollectionUtils.isNotEmpty(skill.getTopicList())) {
            verifyTopicListId(skill, id);
            verifyTopicList(skill.getTopicList());
        }
        updateSkillEntity(skill, skillEntity);
        SkillEntity updatedSkillEntity = skillDAO.update(skillEntity);
        List<TopicEntity> topicEntityList = topicService.updateTopicEntityList(updatedSkillEntity.getId(), skill.getTopicList());
        Skill responsedSkill = skillMapper.toDTO(updatedSkillEntity);
        List<Topic> responsedTopicList = topicMapper.toDTOList(topicEntityList);
        responsedSkill.setTopicList(responsedTopicList);
        invalidateCache();

        return responsedSkill;
    }

    public List<SkillEntity> getByStatus(StatusEnum status) {
        List<SkillEntity> cachedResult = skillListCache.getCache().getIfPresent(status.name());

        if (cachedResult != null) {
            return cachedResult;
        }

        List<SkillEntity> skillEntityList = skillDAO.findByStatus(status);

        skillListCache.getCache().put(status.name(), skillEntityList);

        return skillEntityList;
    }

    public Skill getByIdAndStatus(Long id, StatusEnum status) throws ResourceNotFoundException {
        SkillEntity skillEntity = skillDAO.findByIdAndStatus(id, status)
                .orElseThrow(()
                        -> new ResourceNotFoundException(KEY_SKILL_NOT_FOUND, SKILL_NOT_FOUND));
        return skillMapper.toDTO(skillEntity);
    }

    @Transactional
    public Skill create(Skill skill) throws InputValidationException {

        verifySkill(skill);

        if (CollectionUtils.isNotEmpty(skill.getTopicList())) {
            verifyTopicList(skill.getTopicList());
        }

        SkillEntity skillEntity = SkillEntity.builder()
                .name(skill.getName().trim())
                .description(skill.getDescription() == null ? null : skill.getDescription().trim())
                .status(ACTIVE)
                .build();

        SkillEntity referencedSkill = skillDAO.create(skillEntity);

        List<TopicEntity> topicEntityList = createTopicEntityList(skill.getTopicList(), referencedSkill);

        Skill returnSkill = skillMapper.toDTO(referencedSkill);

        if (CollectionUtils.isNotEmpty(topicEntityList)) {
            returnSkill.setTopicList(topicMapper.toDTOList(topicEntityList));
        } else {
            returnSkill.setTopicList(new ArrayList<>());
        }

        invalidateCache();

        return returnSkill;
    }

    public List<Skill> getSkillListIncludingTopicList() throws ResourceNotFoundException {

        List<SkillEntity> skillEntityList = skillDAO.findByStatus(ACTIVE);

        List<Skill> skillList = skillMapper.toDTOList(skillEntityList);

        for (Skill skill : skillList) {
            List<Topic> topicList = topicService.getBySkillIdAndStatus(skill.getId(), ACTIVE);
            skill.setTopicList(topicList);
        }
        return skillList;
    }

    public Skill softDelete(Long id) throws ResourceNotFoundException {
        SkillEntity deletedSkill = skillDAO.softDelete(id);
        if (deletedSkill == null) {
            throw new ResourceNotFoundException(KEY_SKILL_NOT_FOUND, SKILL_NOT_FOUND);
        }
        invalidateCache();
        return skillMapper.toDTO(deletedSkill);
    }

    public List<SkillEntity> getPagedByStatus(Integer page, Integer size, StatusEnum status) throws ResourceNotFoundException, InputValidationException {
        List<SkillEntity> skillEntityList = getByStatus(status);
        if (page < 1 || size < 1) {
            throw new InputValidationException(ErrorMessage.KEY_PAGE_RANGE_NONPOSITIVE, ErrorMessage.PAGE_RANGE_NONPOSITIVE);
        } else if ((page - 1) * size >= skillEntityList.size()) {
            throw new ResourceNotFoundException(ErrorMessage.KEY_PAGE_OUT_OF_RANGE, ErrorMessage.PAGE_OUT_OF_RANGE);
        }
        int toIndex = page * size;
        if (toIndex > skillEntityList.size()) {
            toIndex = skillEntityList.size();
        }
        return skillEntityList.subList((page - 1) * size, toIndex);
    }

    public PaginationData getPaginationData(Integer page, Integer size, StatusEnum status) throws ResourceNotFoundException, InputValidationException {
        int totalRecords = Math.toIntExact(skillDAO.getTotalRecord(status));
        if (page < 1 || size < 1) {
            throw new InputValidationException(ErrorMessage.KEY_PAGE_RANGE_NONPOSITIVE, ErrorMessage.PAGE_RANGE_NONPOSITIVE);
        } else if ((page - 1) * size > totalRecords) {
            throw new ResourceNotFoundException(ErrorMessage.KEY_PAGE_OUT_OF_RANGE, ErrorMessage.PAGE_OUT_OF_RANGE);
        }

        Integer totalPages = (int) Math.ceil(totalRecords / (double) size);

        return PaginationData.builder()
                .totalRecords(totalRecords)
                .currentPage(page)
                .pageSize(size)
                .totalPages(totalPages)
                .build();
    }

    public ImportResult createImportResult(File excelFile) throws InputValidationException {
        List<Skill> skillListFromExcelFile = excelUtils.getSkillListFromExcelFile(excelFile);

        if (CollectionUtils.isEmpty(skillListFromExcelFile)) {
            throw new InputValidationException(KEY_DATA_NOT_FOUND, DATA_NOT_FOUND);
        }

        ImportResult importResult = new ImportResult();

        List<Skill> skippedSkillList = getSkippedSkillList(skillListFromExcelFile, importResult);

        skillListFromExcelFile.removeAll(skippedSkillList);

        List<Skill> existedSkillListFromDatabase = getExistedSkillListFromDatabase(skillListFromExcelFile);

        if (CollectionUtils.isNotEmpty(existedSkillListFromDatabase)) {
            importResult.setExistedSkillList(existedSkillListFromDatabase);
            skillListFromExcelFile.removeAll(existedSkillListFromDatabase);
        }

        List<Skill> createdSkillList = createSkillListFromExcelFile(skillListFromExcelFile);

        importResult.setImportedList(createdSkillList);
        invalidateCache();
        return importResult;
    }

    private void verifyTopicListId(Skill skill, Long id) throws InputValidationException {
        List<Long> topicEntityIdList = topicDAO.findBySkillIdAndStatus(id, ACTIVE)
                .stream()
                .map(TopicEntity::getId)
                .collect(Collectors.toList());

        List<Long> topicIdList = skill.getTopicList()
                .stream()
                .map(Topic::getId)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        List<Long> invalidIdList = topicIdList.stream()
                .filter(topicId -> !topicEntityIdList.contains(topicId))
                .collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(topicIdList) && CollectionUtils.isNotEmpty(invalidIdList)) {
            throw new InputValidationException(KEY_TOPIC_IN_SKILL, TOPIC_IN_SKILL);
        }
    }

    private void updateSkillEntity(Skill skill, SkillEntity skillEntity) {
        skillEntity.setName(skill.getName().trim());
        skillEntity.setDescription(skill.getDescription() == null ? null : skill.getDescription().trim());
    }

    private SkillEntity getSkillEntityById(Long id) throws ResourceNotFoundException {
        return skillDAO.findByIdAndStatus(id, ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException(KEY_SKILL_NOT_FOUND, SKILL_NOT_FOUND));
    }

    private List<TopicEntity> createTopicEntityList(List<Topic> topicList, SkillEntity skill) {
        List<TopicEntity> topicEntityList = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(topicList)) {
            for (Topic topic : topicList) {
                TopicEntity createdTopicEntity = TopicEntity.builder()
                        .name(topic.getName().trim())
                        .description(topic.getDescription() == null ? null : topic.getDescription().trim())
                        .status(ACTIVE)
                        .skill(skill)
                        .build();
                topicEntityList.add(topicDAO.create(createdTopicEntity));
            }
        }
        return topicEntityList;
    }

    private void verifySkillForUpdate(Skill skill, SkillEntity skillEntity) throws InputValidationException {
        verifySkillViolations(skill);
        if (skill.getName() != null && !skill.getName().equalsIgnoreCase(skillEntity.getName())) {
            verifySkillNameDuplicate(skill);
        }
    }

    private void verifySkill(Skill skill) throws InputValidationException {
        verifySkillViolations(skill);
        verifySkillNameDuplicate(skill);
    }

    private void verifySkillNameDuplicate(Skill skill) throws InputValidationException {
        if (skillDAO.findByName(skill.getName().trim().toLowerCase()).isPresent()) {
            throw new InputValidationException(ErrorMessage.KEY_SKILL_ALREADY_EXISTED,
                    ErrorMessage.SKILL_ALREADY_EXISTED);
        }
    }

    private void verifySkillViolations(Skill skill) {
        Set<ConstraintViolation<Skill>> violations = validator.validate(skill);
        if (CollectionUtils.isNotEmpty(violations)) {
            throw new ConstraintViolationException(violations);
        }
    }

    private void verifyTopicList(List<Topic> topicList) throws InputValidationException {
        checkAllTopicsAreValid(topicList);
        checkDuplicatedTopicList(topicList);
    }

    private void checkAllTopicsAreValid(List<Topic> topicList) {
        for (Topic topic : topicList) {
            if (topic.getName() != null) {
                topic.setName(topic.getName().trim());
            }
            Set<ConstraintViolation<Topic>> violations = validator.validate(topic);
            if (CollectionUtils.isNotEmpty(violations)) {
                throw new ConstraintViolationException(violations);
            }
        }
    }

    private void checkDuplicatedTopicList(List<Topic> topicList) throws InputValidationException {
        List<String> topicNameList = topicList.stream()
                .filter(Objects::nonNull)
                .map(topic -> topic.getName().trim().toLowerCase())
                .collect(Collectors.toList());
        Set<String> topicNameSet = new HashSet<>(topicNameList);
        if (topicNameList.size() != topicNameSet.size())
            throw new InputValidationException(ErrorMessage.KEY_DUPLICATED_TOPIC_NAME, ErrorMessage.DUPLICATED_TOPIC_NAME);
    }

    private void invalidateCache() {
        skillListCache.getCache().invalidateAll();
    }

    private List<Skill> createSkillListFromExcelFile(List<Skill> validSkillList) {
        List<Skill> createdSkillList = new ArrayList<>();
        validSkillList.forEach(skill -> {
            SkillEntity skillEntity = SkillEntity.builder()
                    .name(skill.getName())
                    .description(skill.getDescription())
                    .status(StatusEnum.ACTIVE)
                    .build();

            SkillEntity referencedSkill = skillDAO.create(skillEntity);

            List<TopicEntity> topicEntityList = createTopicEntityList(skill.getTopicList(), referencedSkill);

            Skill returnSkill = skillMapper.toDTO(referencedSkill);

            if (CollectionUtils.isNotEmpty(topicEntityList)) {
                returnSkill.setTopicList(topicMapper.toDTOList(topicEntityList));
            } else if (CollectionUtils.isEmpty(topicEntityList)) {
                returnSkill.setTopicList(new ArrayList<>());
            }

            createdSkillList.add(returnSkill);
        });
        return createdSkillList;
    }

    private List<Skill> getExistedSkillListFromDatabase(List<Skill> skillList) {
        return skillList.stream()
                .filter(skill -> skillDAO.findByName(skill.getName().trim().toLowerCase()).isPresent())
                .collect(Collectors.toList());
    }

    private List<Skill> getDuplicatedSkillListInFile(List<Skill> tempSkillList) {
        Map<String, Skill> mapToCheckDuplicatedSkill = new HashMap<>();
        List<Skill> duplicatedSkillList = new ArrayList<>();

        for (Skill skill : tempSkillList) {
            if (mapToCheckDuplicatedSkill.containsKey(skill.getName())) {
                duplicatedSkillList.add(skill);
                duplicatedSkillList.add(mapToCheckDuplicatedSkill.get(skill.getName()));
            } else {
                mapToCheckDuplicatedSkill.put(skill.getName(), skill);
            }
        }
        return duplicatedSkillList;
    }

    private List<Skill> getSkippedSkillList(List<Skill> skillList, ImportResult importResult) {
        List<Skill> skippedSkillList = new ArrayList<>();
        Map<String, String> skippedSkillMap = new HashMap<>();
        for (Skill skill : skillList) {
            Set<ConstraintViolation<Skill>> violationsOfSkill = validator.validate(skill);

            if (CollectionUtils.isNotEmpty(violationsOfSkill)) {
                skippedSkillList.add(skill);
                skippedSkillMap.put(skill.getName().trim().isEmpty() ? BLANK_SKILL_NAME : skill.getName().trim(), INVALID_SKILL_MESSAGE);
            }

            if (CollectionUtils.isEmpty(violationsOfSkill) && CollectionUtils.isNotEmpty(skill.getTopicList())) {
                if (containDuplicatedTopic(skill.getTopicList())) {
                    skippedSkillList.add(skill);
                    skippedSkillMap.put(skill.getName(), DUPLICATED_TOPIC_MESSAGE);

                }
                if (isTopicListNotValid(skill.getTopicList())) {
                    skippedSkillList.add(skill);
                    skippedSkillMap.put(skill.getName(), INVALID_TOPIC_MESSAGE);
                }
            }
        }
        skillList.removeAll(skippedSkillList);

        List<Skill> duplicatedSkillList = getDuplicatedSkillListInFile(skillList);

        duplicatedSkillList.forEach(skill -> skippedSkillMap.put(skill.getName(), DUPLICATED_SKILL_MESSAGE));

        importResult.setSkippedSkillList(skippedSkillMap);

        skippedSkillList.addAll(duplicatedSkillList);

        return skippedSkillList;
    }

    private boolean containDuplicatedTopic(List<Topic> topicList) {
        List<String> topicNameList = topicList.stream()
                .filter(Objects::nonNull)
                .map(topic -> topic.getName().trim().toLowerCase())
                .collect(Collectors.toList());
        Set<String> topicNameSet = new HashSet<>(topicNameList);
        return topicNameList.size() != topicNameSet.size();
    }

    private boolean isTopicListNotValid(List<Topic> topicList) {
        for (Topic topic : topicList) {
            Set<ConstraintViolation<Topic>> violations = validator.validate(topic);
            if (CollectionUtils.isNotEmpty(violations)) {
                return true;
            }
        }
        return false;
    }
}