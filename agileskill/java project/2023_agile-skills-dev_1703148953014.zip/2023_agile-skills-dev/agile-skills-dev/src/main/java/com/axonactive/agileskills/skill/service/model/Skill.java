package com.axonactive.agileskills.skill.service.model;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.skill.topic.service.model.Topic;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.*;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

import static com.axonactive.agileskills.base.exception.ErrorMessage.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Skill {
    private Long id;

    @NotBlank(message = KEY_SKILL_NAME_NULL_OR_BLANK)
    @Size(max = MAX_SIZE_NAME, message = KEY_SKILL_NAME_LENGTH_CONSTRAINT)
    private String name;

    @Size(max = MAX_SIZE_DESCRIPTION, message = KEY_SKILL_DESCRIPTION_LENGTH_CONSTRAINT)

    private String description;

    @Enumerated(EnumType.STRING)
    private StatusEnum status;

    private List<Topic> topicList;
}
