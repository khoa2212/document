package com.axonactive.agileskills.base.utility;

import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.skill.service.model.Skill;
import com.axonactive.agileskills.skill.topic.service.model.Topic;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import javax.enterprise.context.RequestScoped;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static com.axonactive.agileskills.base.exception.ErrorMessage.FILE_TEMPLATE_NOT_SUPPORTED;
import static com.axonactive.agileskills.base.exception.ErrorMessage.FILE_WRONG_FORMAT_EXCEPTION;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_FILE_TEMPLATE_NOT_SUPPORTED;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_FILE_WRONG_FORMAT_EXCEPTION;

@RequestScoped
public class ExcelUtils {
    public static final String SKILL_NAME = "skill name";
    public static final String SKILL_DESCRIPTION = "skill description";
    public static final String TOPIC_NAME = "topic name";
    public static final String TOPIC_DESCRIPTION = "topic description";
    public static final int FIRST_SHEET = 0;
    public static final int CELL_SKILL_NAME = 0;
    public static final int CELL_SKILL_DESCRIPTION = 1;
    public static final int CELL_TOPIC_NAME = 2;
    public static final int CELL_TOPIC_DESCRIPTION = 3;
    public static final int FIRST_ROW = 0;

    public List<Skill> getSkillListFromExcelFile(File excelFile) throws InputValidationException {
        Workbook workbook = getWorkbook(excelFile);
        Sheet sheet = workbook.getSheetAt(FIRST_SHEET);
        checkTemplateFile(sheet);
        return createSkillList(sheet);
    }

    private List<Skill> createSkillList(Sheet sheet) {
        List<Skill> skillListFromExcelFile = new ArrayList<>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            if (sheet.getRow(i) != null) {
                String skillName = getCellValue(sheet.getRow(i).getCell(CELL_SKILL_NAME)).trim();
                String skillDescription = getCellValue(sheet.getRow(i).getCell(CELL_SKILL_DESCRIPTION)).trim();

                if (!isSkillRowBlank(sheet.getRow(i))) {
                    Skill skill = Skill.builder()
                            .name(skillName)
                            .description(skillDescription.isBlank() ? null : skillDescription)
                            .build();

                    addTopicList(sheet, i, skill);
                    skillListFromExcelFile.add(skill);
                }
            }
        }
        return skillListFromExcelFile;
    }

    private void checkTemplateFile(Sheet sheet) throws InputValidationException {
        if (!isTemplateValid(sheet)) {
            throw new InputValidationException(KEY_FILE_TEMPLATE_NOT_SUPPORTED, FILE_TEMPLATE_NOT_SUPPORTED);
        }
    }

    private String getCellValue(Cell cell) {
        if (cell == null) return "";
        CellType cellType = cell.getCellType();
        switch (cellType) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case _NONE:
            case BLANK:
            case ERROR:
            default:
                break;
        }
        return "";
    }

    private boolean isSkillRowBlank(Row row) {
        String skillName = getCellValue(row.getCell(CELL_SKILL_NAME)).trim();
        String skillDescription = getCellValue(row.getCell(CELL_SKILL_DESCRIPTION)).trim();
        return skillName.isBlank() && skillDescription.isBlank();
    }

    private void addTopicList(Sheet sheet, int i, Skill skill) {
        List<Topic> topicList = new ArrayList<>();
        String topicName = getCellValue(sheet.getRow(i).getCell(CELL_TOPIC_NAME)).trim();
        String topicDescription = getCellValue(sheet.getRow(i).getCell(CELL_TOPIC_DESCRIPTION)).trim();

        if (!topicName.isBlank() || !topicDescription.isBlank()) {
            Topic topic = Topic.builder()
                    .name(topicName)
                    .description(topicDescription.isBlank() ? null : topicDescription)
                    .build();
            topicList.add(topic);
        }

        for (int k = i + 1; sheet.getRow(k) != null && isSkillRowBlank(sheet.getRow(k)); k++) {
            topicName = getCellValue(sheet.getRow(k).getCell(CELL_TOPIC_NAME));
            topicDescription = getCellValue(sheet.getRow(k).getCell(CELL_TOPIC_DESCRIPTION));

            if (!topicName.isBlank() || !topicDescription.isBlank()) {
                Topic topic = Topic.builder()
                        .name(topicName)
                        .description(topicDescription.isBlank() ? null : topicDescription)
                        .build();
                topicList.add(topic);
            }
        }
        skill.setTopicList(topicList);
    }

    private Workbook getWorkbook(File excelFile) throws InputValidationException {
        try (InputStream inputStream = new BufferedInputStream(new FileInputStream(excelFile))) {
            Workbook workbook = WorkbookFactory.create(inputStream);
            workbook.close();
            return workbook;
        } catch (Exception e) {
            throw new InputValidationException(KEY_FILE_WRONG_FORMAT_EXCEPTION, FILE_WRONG_FORMAT_EXCEPTION);
        }
    }

    private boolean isTemplateValid(Sheet sheet) {
        Row firstRow = sheet.getRow(FIRST_ROW);
        return SKILL_NAME.equalsIgnoreCase(getCellValue(firstRow.getCell(CELL_SKILL_NAME)).trim()) &&
                SKILL_DESCRIPTION.equalsIgnoreCase(getCellValue(firstRow.getCell(CELL_SKILL_DESCRIPTION)).trim()) &&
                TOPIC_NAME.equalsIgnoreCase(getCellValue(firstRow.getCell(CELL_TOPIC_NAME)).trim()) &&
                TOPIC_DESCRIPTION.equalsIgnoreCase(getCellValue(firstRow.getCell(CELL_TOPIC_DESCRIPTION)).trim());
    }
}
