package com.axonactive.agileskills.skill.topic.service;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.skill.dao.SkillDAO;
import com.axonactive.agileskills.skill.entity.SkillEntity;
import com.axonactive.agileskills.skill.topic.dao.TopicDAO;
import com.axonactive.agileskills.skill.topic.entity.TopicEntity;
import com.axonactive.agileskills.skill.topic.service.mapper.TopicMapper;
import com.axonactive.agileskills.skill.topic.service.model.Topic;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.validator.messageinterpolation.ParameterMessageInterpolator;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.axonactive.agileskills.base.entity.StatusEnum.ACTIVE;
import static com.axonactive.agileskills.base.exception.ErrorMessage.DUPLICATED_TOPIC_NAME;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_DUPLICATED_TOPIC_NAME;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_SKILL_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_TOPIC_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.SKILL_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.TOPIC_NOT_FOUND;

@Stateless
public class TopicService {

    private static final Validator validator = Validation.byDefaultProvider()
            .configure()
            .messageInterpolator(new ParameterMessageInterpolator())
            .buildValidatorFactory()
            .getValidator();

    @Inject
    private TopicDAO topicDAO;

    @Inject
    private TopicMapper topicMapper;

    @Inject
    private SkillDAO skillDAO;

    public List<TopicEntity> updateTopicEntityList(Long skillId, List<Topic> topicList) throws ResourceNotFoundException {
        SkillEntity skill = getSkillEntityByIdAndStatus(skillId);
        List<TopicEntity> topicEntityList = topicDAO.findBySkillIdAndStatus(skill.getId(), ACTIVE);

        return updateTopicEntityListBaseOnRequest(topicList, topicEntityList, skill);
    }

    public List<Topic> getBySkillIdAndStatus(Long skillId, StatusEnum status) throws ResourceNotFoundException {
        SkillEntity skill = getSkillEntityByIdAndStatus(skillId);
        return topicMapper.toDTOList(topicDAO.findBySkillIdAndStatus(skill.getId(), status));
    }

    public Topic create(Topic topic, Long skillId) throws ResourceNotFoundException, InputValidationException {
        verifyTopic(topic, skillId);
        TopicEntity createdTopic = TopicEntity.builder()
                .name(topic.getName().trim())
                .description(topic.getDescription() == null ? null : topic.getDescription().trim())
                .status(ACTIVE)
                .skill(getSkillEntityByIdAndStatus(skillId))
                .build();

        return topicMapper.toDTO(topicDAO.create(createdTopic));

    }

    public Topic softDelete(Long id) throws ResourceNotFoundException {
        TopicEntity deletedTopic = topicDAO.softDelete(id);
        if (deletedTopic == null) {
            throw new ResourceNotFoundException(KEY_TOPIC_NOT_FOUND, TOPIC_NOT_FOUND);
        }
        return topicMapper.toDTO(deletedTopic);
    }

    private List<TopicEntity> updateTopicEntityListBaseOnRequest(List<Topic> topicList, List<TopicEntity> topicEntityList, SkillEntity skill) {
        List<TopicEntity> updatedTopicEntityList = new ArrayList<>();
        updateExistedTopics(topicList, topicEntityList, updatedTopicEntityList);
        addNewTopicsIfNotExisted(topicList, topicEntityList, skill, updatedTopicEntityList);
        deleteTopics(topicList, topicEntityList);
        return updatedTopicEntityList;
    }

    private void deleteTopics(List<Topic> topicList, List<TopicEntity> topicEntityList) {
        List<TopicEntity> deletedTopicEntityList = topicEntityList.stream()
                .filter(topicEntity -> !topicList.stream()
                        .map(Topic::getId)
                        .collect(Collectors.toList())
                        .contains(topicEntity.getId()))
                .collect(Collectors.toList());

        deleteTopic(deletedTopicEntityList);
    }

    private void deleteTopic(List<TopicEntity> deletedTopicEntityList) {
        deletedTopicEntityList.forEach(topicEntity ->
                topicDAO.softDelete(topicEntity.getId()));
    }

    private void addNewTopicsIfNotExisted(List<Topic> topicList, List<TopicEntity> topicEntityList, SkillEntity skill, List<TopicEntity> updatedTopicEntityList) {
        List<Topic> addedTopicList = topicList.stream()
                .filter(topic -> !topicEntityList.stream()
                        .map(TopicEntity::getId)
                        .collect(Collectors.toList())
                        .contains(topic.getId()))
                .collect(Collectors.toList());

        createAndAddTopics(skill, updatedTopicEntityList, addedTopicList);
    }

    private void createAndAddTopics(SkillEntity skill, List<TopicEntity> updatedTopicEntityList, List<Topic> addedTopicList) {
        addedTopicList.forEach(topic -> {
            TopicEntity topicEntity = TopicEntity.builder()
                    .name(topic.getName())
                    .description(topic.getDescription())
                    .status(ACTIVE)
                    .skill(skill)
                    .build();
            TopicEntity createdTopic = topicDAO.create(topicEntity);
            updatedTopicEntityList.add(createdTopic);
        });
    }

    private void updateExistedTopics(List<Topic> topicList, List<TopicEntity> topicEntityList, List<TopicEntity> updatedTopicEntityList) {
        for (TopicEntity topicEntity : topicEntityList) {
            for (Topic topic : topicList) {
                if (topic.getId() != null && topic.getId().equals(topicEntity.getId())) {
                    topicEntity.setName(topic.getName());
                    topicEntity.setDescription(topic.getDescription());

                    TopicEntity updatedTopic = topicDAO.update(topicEntity);
                    updatedTopicEntityList.add(updatedTopic);
                }
            }
        }
    }

    private SkillEntity getSkillEntityByIdAndStatus(Long skillId) throws ResourceNotFoundException {
        return skillDAO.findByIdAndStatus(skillId, ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException(KEY_SKILL_NOT_FOUND, SKILL_NOT_FOUND));
    }

    private void verifyTopic(Topic topic, Long skillId) throws ResourceNotFoundException, InputValidationException {
        if (topic.getName() != null) {
            topic.setName(topic.getName().trim());
        }
        Set<ConstraintViolation<Topic>> violations = validator.validate(topic);
        if (CollectionUtils.isNotEmpty(violations)) {
            throw new ConstraintViolationException(violations);
        }
        if (isSkillNotExist(skillId)) {
            throw new ResourceNotFoundException(KEY_SKILL_NOT_FOUND, SKILL_NOT_FOUND);
        }
        if (isNameDuplicated(topic, skillId)) {
            throw new InputValidationException(KEY_DUPLICATED_TOPIC_NAME, DUPLICATED_TOPIC_NAME);
        }
    }

    private boolean isNameDuplicated(Topic topic, Long skillId) {
        return topicDAO.findBySkillIdAndStatus(skillId, ACTIVE).stream()
                .anyMatch(topicEntity -> topicEntity.getName().equalsIgnoreCase(topic.getName().trim()));
    }

    private boolean isSkillNotExist(Long skillId) {
        return skillDAO.findByIdAndStatus(skillId, ACTIVE).isEmpty();
    }
}
