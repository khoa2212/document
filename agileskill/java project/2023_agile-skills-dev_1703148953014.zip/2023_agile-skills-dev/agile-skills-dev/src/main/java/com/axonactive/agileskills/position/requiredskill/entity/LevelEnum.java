package com.axonactive.agileskills.position.requiredskill.entity;

public enum LevelEnum {
    MASTER, USED, LEARNED
}
