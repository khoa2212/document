package com.axonactive.agileskills.graph.service.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import static com.axonactive.agileskills.base.exception.ErrorMessage.*;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Graph {
    private Long id;

    @NotBlank(message = KEY_GRAPH_VALUE_NULL_OR_BLANK)
    @Size(max = MAX_LENGTH_GRAPH_VALUE, message = KEY_GRAPH_VALUE_LENGTH_CONSTRAINT)
    private String graphValue;

    private Long positionId;
}
