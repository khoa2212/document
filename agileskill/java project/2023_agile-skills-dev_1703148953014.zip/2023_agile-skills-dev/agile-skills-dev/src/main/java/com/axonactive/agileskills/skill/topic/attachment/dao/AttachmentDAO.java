package com.axonactive.agileskills.skill.topic.attachment.dao;

import com.axonactive.agileskills.base.dao.BaseDAO;
import com.axonactive.agileskills.skill.topic.attachment.entity.AttachmentEntity;

import javax.ejb.Stateless;
import java.util.List;
import java.util.Optional;

@Stateless
public class AttachmentDAO extends BaseDAO<AttachmentEntity> {

    public AttachmentDAO() {
        super(AttachmentEntity.class);
    }

    public List<AttachmentEntity> findByTopicId(Long topicId) {
        return em.createQuery("SELECT a FROM AttachmentEntity a WHERE a.topic.id = :topicId ORDER BY a.name", AttachmentEntity.class)
                .setParameter("topicId", topicId)
                .getResultList();
    }

    public Optional<AttachmentEntity> findByNameAndTopicId(Long topicId, String name) {
        List<AttachmentEntity> attachmentList = em.createQuery("SELECT a FROM AttachmentEntity a WHERE a.topic.id = :topicId AND a.name = :name", AttachmentEntity.class)
                .setParameter("topicId", topicId)
                .setParameter("name", name)
                .getResultList();
        return attachmentList.isEmpty() ? Optional.empty() : Optional.of(attachmentList.get(0));
    }
}
