package com.axonactive.agileskills.position.requiredskill.dao;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Stateless
public class RequiredTopicDAO {

    @PersistenceContext(name = "agileskills")
    private EntityManager em;

    public void deleteInList(List<Long> idList) {
        Query query = em.createQuery("DELETE FROM RequiredTopicEntity rt WHERE rt.id IN :idList")
                .setParameter("idList", idList);
        query.executeUpdate();
    }
}

