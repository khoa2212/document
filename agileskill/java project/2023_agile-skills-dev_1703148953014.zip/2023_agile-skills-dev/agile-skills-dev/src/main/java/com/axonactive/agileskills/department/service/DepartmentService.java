package com.axonactive.agileskills.department.service;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.department.dao.DepartmentDAO;
import com.axonactive.agileskills.department.entity.DepartmentEntity;
import com.axonactive.agileskills.department.service.mapper.DepartmentMapper;
import com.axonactive.agileskills.department.service.model.Department;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.List;

@Stateless
public class DepartmentService {

    @Inject
    private DepartmentDAO departmentDAO;

    @Inject
    private DepartmentMapper departmentMapper;

    public List<Department> getByStatus(StatusEnum status) {
        List<DepartmentEntity> departmentEntityList = departmentDAO.findByStatus(status);
        return departmentMapper.toDTOList(departmentEntityList);
    }
}

