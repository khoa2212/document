package com.axonactive.agileskills.graph.service;

import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.graph.dao.GraphDAO;
import com.axonactive.agileskills.graph.entity.GraphEntity;
import com.axonactive.agileskills.graph.service.mapper.GraphMapper;
import com.axonactive.agileskills.graph.service.model.Graph;
import com.axonactive.agileskills.position.dao.PositionDAO;
import com.axonactive.agileskills.position.service.mapper.PositionMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.validator.messageinterpolation.ParameterMessageInterpolator;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.Set;

import static com.axonactive.agileskills.base.exception.ErrorMessage.*;
import static com.axonactive.agileskills.position.entity.PositionStatusEnum.OPEN;

@Stateless
public class GraphService {
    private static final Validator validator = Validation.byDefaultProvider()
            .configure()
            .messageInterpolator(new ParameterMessageInterpolator())
            .buildValidatorFactory()
            .getValidator();
    @Inject
    private GraphDAO graphDAO;

    @Inject
    private GraphMapper graphMapper;

    @Inject
    private PositionDAO positionDAO;

    @Inject
    private PositionMapper positionMapper;

    public Graph getByPositionId(Long positionId) throws ResourceNotFoundException {
        checkOpenPositionExisted(positionId);
        return graphMapper.toDTO(graphDAO.findByPositionId(positionId).orElse(null));
    }

    public Graph save(Graph graph) throws ResourceNotFoundException {
        checkValidGraph(graph);

        GraphEntity graphEntity = GraphEntity.builder()
                .graphValue(graph.getGraphValue())
                .positionId(graph.getPositionId())
                .build();

        GraphEntity existedGraphEntity = graphDAO.findByPositionId(graph.getPositionId()).orElse(null);

        if (existedGraphEntity != null) {
            existedGraphEntity.setGraphValue(graph.getGraphValue());
            return graphMapper.toDTO(graphDAO.update(existedGraphEntity));
        } else {
            return graphMapper.toDTO(graphDAO.create(graphEntity));
        }
    }

    public void delete(Long positionId) throws ResourceNotFoundException {
        checkOpenPositionExisted(positionId);
        GraphEntity existedGraphEntity = graphDAO.findByPositionId(positionId).orElse(null);

        if (existedGraphEntity != null) {
            graphDAO.remove(existedGraphEntity);
        }
    }

    private void checkOpenPositionExisted(Long id) throws ResourceNotFoundException {
        if (positionDAO.findByIdAndStatus(id, OPEN).isEmpty()) {
            throw new ResourceNotFoundException(KEY_POSITION_NOT_FOUND, POSITION_NOT_FOUND);
        }
    }

    private void validateGraphConstraints(Graph graph) throws ConstraintViolationException {
        Set<ConstraintViolation<Graph>> graphViolationSet = validator.validate(graph);
        if (CollectionUtils.isNotEmpty(graphViolationSet)) {
            throw new ConstraintViolationException(graphViolationSet);
        }
    }

    private void checkValidGraph(Graph graph) throws ResourceNotFoundException {
        validateGraphConstraints(graph);
        checkOpenPositionExisted(graph.getPositionId());
    }
}
