package com.axonactive.agileskills.position.service;

import com.axonactive.agileskills.base.utility.BaseCache;
import com.axonactive.agileskills.position.entity.PositionEntity;

import javax.ejb.Singleton;

@Singleton
public class SearchPositionCache extends BaseCache<PositionEntity> {
    public SearchPositionCache() {
        super();
    }
}
