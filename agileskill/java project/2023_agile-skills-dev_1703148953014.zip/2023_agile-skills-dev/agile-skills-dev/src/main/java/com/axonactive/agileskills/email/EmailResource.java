package com.axonactive.agileskills.email;


import com.axonactive.agileskills.base.exception.AgileSkillsException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;

import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Singleton
@Startup
@Path("/emails")
public class EmailResource {
    @Inject
    private EmailService emailService;

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response sendDailyEmail() throws AgileSkillsException, ResourceNotFoundException {
        emailService.sendDailyEmail();
        return Response.ok().build();
    }
}
