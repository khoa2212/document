package com.axonactive.agileskills.graph.dao;

import com.axonactive.agileskills.base.dao.BaseDAO;
import com.axonactive.agileskills.graph.entity.GraphEntity;

import javax.ejb.Stateless;
import java.util.List;
import java.util.Optional;

@Stateless
public class GraphDAO extends BaseDAO<GraphEntity> {

    public GraphDAO() {
        super(GraphEntity.class);
    }

    public Optional<GraphEntity> findByPositionId(Long positionId) {
        List<GraphEntity> graphEntityList = em.createQuery("SELECT g FROM GraphEntity g " +
                        "WHERE g.positionId = :positionId", GraphEntity.class)
                .setParameter("positionId", positionId)
                .getResultList();

        return graphEntityList.isEmpty() ? Optional.empty() : Optional.of(graphEntityList.get(0));
    }
}
