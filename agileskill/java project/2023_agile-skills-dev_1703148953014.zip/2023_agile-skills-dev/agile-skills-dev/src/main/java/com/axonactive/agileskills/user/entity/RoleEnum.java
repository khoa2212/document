package com.axonactive.agileskills.user.entity;


public enum RoleEnum {
    ROLE_ADMIN,
    ROLE_USER
}
