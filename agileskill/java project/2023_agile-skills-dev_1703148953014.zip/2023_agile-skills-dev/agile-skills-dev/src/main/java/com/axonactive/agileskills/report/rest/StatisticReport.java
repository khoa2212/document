package com.axonactive.agileskills.report.rest;

import com.axonactive.agileskills.report.service.StatisticService;
import com.axonactive.agileskills.report.service.model.YearlyStatistics;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/statistics")
public class StatisticReport {
    @Inject
    private StatisticService statisticService;

    @GET
    @Path("/{year}")
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get open statistic by year", authorizations = {@Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get open statistic by year successfully", response = YearlyStatistics.class),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getStatisticByYear(@PathParam("year") Integer year) {
        return Response.ok(statisticService.getStatisticByYear(year)).build();
    }
}
