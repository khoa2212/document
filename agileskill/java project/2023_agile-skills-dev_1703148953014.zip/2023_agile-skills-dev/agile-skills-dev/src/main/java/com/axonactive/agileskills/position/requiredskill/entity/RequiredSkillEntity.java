package com.axonactive.agileskills.position.requiredskill.entity;

import com.axonactive.agileskills.position.entity.PositionEntity;
import com.axonactive.agileskills.skill.entity.SkillEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "required_skill")
public class RequiredSkillEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "skill_id", nullable = false)
    private SkillEntity skill;

    @ManyToOne
    @JoinColumn(name = "position_id", nullable = false)
    private PositionEntity position;

    @OneToMany(mappedBy = "requiredSkill", cascade = CascadeType.ALL)
    private List<RequiredTopicEntity> requiredTopicList;

    @Enumerated(EnumType.STRING)
    private RequireEnum require;

    @Enumerated(EnumType.STRING)
    private LevelEnum level;

    @Column(name = "required_skill_note", length = 2000)
    private String note;
}
