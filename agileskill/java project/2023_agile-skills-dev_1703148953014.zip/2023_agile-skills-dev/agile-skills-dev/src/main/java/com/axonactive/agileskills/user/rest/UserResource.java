package com.axonactive.agileskills.user.rest;

import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.base.security.utility.JwtUtils;
import com.axonactive.agileskills.skill.service.model.Skill;
import com.axonactive.agileskills.user.entity.UserEntity;
import com.axonactive.agileskills.user.service.UserService;
import com.axonactive.agileskills.user.service.mapper.UserMapper;
import com.axonactive.agileskills.user.service.model.ChangePasswordRequest;
import com.axonactive.agileskills.user.service.model.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;

@Path("/users")
@Api(tags = {"Users"})

public class UserResource {

    @Inject
    private UserService userService;

    @Inject
    private JwtUtils jwtUtils;

    @Inject
    private UserMapper userMapper;

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN"})
    @ApiOperation(value = "Create a user", authorizations = {@Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 201, message = "Create a user successfully", response = Skill.class),
            @ApiResponse(code = 400, message = "Request sent to the server is invalid or corrupted"),
            @ApiResponse(code = 401, message = "Sign-in required"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response create(@ApiParam(value = "User to be created", required = true, name = "New user's info") User user) throws InputValidationException {
        User createdUser = userService.create(user);
        return Response.created(URI.create("users/" + createdUser.getId())).entity(createdUser).status(Response.Status.CREATED).build();
    }

    @PUT
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @Path("/change-password")
    @ApiOperation(value = "Change password", authorizations = {@Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 200, message = "Change password successfully", response = User.class),
            @ApiResponse(code = 400, message = "Request sent to the server is invalid or corrupted"),
            @ApiResponse(code = 401, message = "Sign-in required"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response changePassword(@HeaderParam("Authorization") String authorization, ChangePasswordRequest changePasswordRequest) throws InputValidationException, ResourceNotFoundException {
        String email = jwtUtils.getEmailFromToken(authorization);
        UserEntity updatedUserEntity = userService.changePassword(email, changePasswordRequest);
        User updatedUser = userMapper.toDTO(updatedUserEntity);
        return Response.ok(updatedUser).build();
    }
}
