package com.axonactive.agileskills.base.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.io.IOException;

import static com.axonactive.agileskills.base.exception.ErrorMessage.FILE_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_FILE_NOT_FOUND;

@Provider
public class IOExceptionMapper implements ExceptionMapper<IOException> {
    private static final Logger logger = LogManager.getLogger(IOException.class);

    @Override
    public Response toResponse(IOException e) {
        ResponseBody responseBody = new ResponseBody(Response.Status.BAD_REQUEST, KEY_FILE_NOT_FOUND, FILE_NOT_FOUND);

        StackTraceElement[] stackTraceArray = e.getStackTrace();
        String logMessage = String.format("%s:%d - %s",
                stackTraceArray[0].getClassName(),
                stackTraceArray[0].getLineNumber(),
                responseBody.getErrorMessage());

        logger.info(logMessage);

        return Response.status(Response.Status.BAD_REQUEST)
                .entity(responseBody)
                .build();
    }
}
