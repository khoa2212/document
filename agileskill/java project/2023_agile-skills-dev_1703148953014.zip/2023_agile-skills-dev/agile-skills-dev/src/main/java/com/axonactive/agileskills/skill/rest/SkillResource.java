package com.axonactive.agileskills.skill.rest;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.base.model.PagedDataResponse;
import com.axonactive.agileskills.base.model.PaginationData;
import com.axonactive.agileskills.base.security.utility.JwtUtils;
import com.axonactive.agileskills.base.utility.FormDataExcel;
import com.axonactive.agileskills.skill.entity.SkillEntity;
import com.axonactive.agileskills.skill.service.SkillService;
import com.axonactive.agileskills.skill.service.mapper.SkillMapper;
import com.axonactive.agileskills.skill.service.model.ImportResult;
import com.axonactive.agileskills.skill.service.model.Skill;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import org.jboss.resteasy.annotations.providers.multipart.MultipartForm;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.List;

@Path("/skills")
@Api(tags = {"Skill"})
public class SkillResource {

    @Inject
    private SkillService skillService;

    @Inject
    private JwtUtils jwtUtils;

    @Inject
    private SkillMapper skillMapper;

    @PUT
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @ApiOperation(value = "Update a skill", authorizations = {@Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 200, message = "Update skill successfully", response = Skill.class),
            @ApiResponse(code = 400, message = "Request sent to the server is invalid or corrupted"),
            @ApiResponse(code = 401, message = "Sign-in required"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response update(@ApiParam(value = "Skill to be updated", required = true, name = "Update skill's info") Skill skill,
                           @PathParam("id") Long id) throws ResourceNotFoundException, InputValidationException {
        Skill response = skillService.update(skill, id);
        return Response.ok().entity(response).build();
    }

    @GET
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get active skill by id")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get active skill by id successfully", response = Skill.class),
            @ApiResponse(code = 404, message = "Skill not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getActiveById(@PathParam("id") Long skillId) throws ResourceNotFoundException {
        return Response.ok(skillService.getByIdAndStatus(skillId, StatusEnum.ACTIVE)).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get active skill list, paged")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get active skill list successfully", response = PagedDataResponse.class, responseContainer = "List"),
            @ApiResponse(code = 400, message = "Parameters invalid - page or size less than one"),
            @ApiResponse(code = 404, message = "Page out of range"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getActiveList(@ApiParam(value = "Page number", required = true, name = "page") @QueryParam("page") int page,
                                  @ApiParam(value = "Page size", required = true, name = "size") @QueryParam("size") int size) throws ResourceNotFoundException, InputValidationException {

        PaginationData paginationData = skillService.getPaginationData(page, size, StatusEnum.ACTIVE);
        List<SkillEntity> skillEntityList = skillService.getPagedByStatus(page, size, StatusEnum.ACTIVE);
        List<Skill> skillList = skillMapper.toDTOList(skillEntityList);
        PagedDataResponse pagedSkillList = PagedDataResponse.builder().listData(skillList).paginationData(paginationData).build();
        return Response.ok(pagedSkillList).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @ApiOperation(value = "Create a skill", authorizations = {
            @Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 201, message = "Create skill successfully", response = Skill.class),
            @ApiResponse(code = 400, message = "Request sent to the server is invalid or corrupted"),
            @ApiResponse(code = 401, message = "Sign-in required"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response create(@ApiParam(value = "Agile skill to be created",
            required = true, name = "New skill's info") Skill skill) throws InputValidationException {
        Skill createdSkill = skillService.create(skill);
        return Response.created(URI.create("skills/" + createdSkill.getId())).entity(createdSkill).status(Response.Status.CREATED).build();
    }

    @DELETE
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @ApiOperation(value = "Soft delete a skill", authorizations = {
            @Authorization(HttpHeaders.AUTHORIZATION)})
    @ApiResponses({
            @ApiResponse(code = 204, message = "Soft delete a skill"),
            @ApiResponse(code = 401, message = "Sign-in required"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 404, message = "Skill not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response softDelete(@ApiParam(value = "Agile skill to be soft deleted", required = true)
                               @PathParam("id") Long id) throws ResourceNotFoundException {
        skillService.softDelete(id);
        return Response.noContent().build();
    }

    @GET
    @Path("/skills-with-topics")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get all skills including topics")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get all skills including topics", response = Skill.class),
            @ApiResponse(code = 404, message = "Resource not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getSkillListIncludingTopicList() throws ResourceNotFoundException {
        return Response.ok(skillService.getSkillListIncludingTopicList()).build();
    }

    @POST
    @Path("/upload-file")
    @Consumes({MediaType.MULTIPART_FORM_DATA})
    @Produces({MediaType.APPLICATION_JSON})
    @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"})
    @ApiOperation(value = "Import skill list and topic list from excel file", response = ImportResult.class)
    @ApiResponses({
            @ApiResponse(code = 200, message = "Import successfully", response = Skill.class),
            @ApiResponse(code = 400, message = "File not supported"),
            @ApiResponse(code = 400, message = "Data not found"),
            @ApiResponse(code = 400, message = "File template not supported"),
            @ApiResponse(code = 404, message = "Resource not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response createSkillListFromExcelFile(@MultipartForm FormDataExcel excelFile) throws InputValidationException {
        return Response.ok(skillService.createImportResult(excelFile.getFile())).build();
    }
}
