package com.axonactive.agileskills.position.entity;

public enum PositionStatusEnum {
    OPEN,
    CLOSE
}
