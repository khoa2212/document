package com.axonactive.agileskills.position.requiredskill.entity;

public enum RequireEnum {
    MUST_HAVE, NICE_TO_HAVE
}
