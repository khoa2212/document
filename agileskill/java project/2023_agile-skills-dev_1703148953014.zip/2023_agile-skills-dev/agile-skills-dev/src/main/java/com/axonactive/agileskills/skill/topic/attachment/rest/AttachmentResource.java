package com.axonactive.agileskills.skill.topic.attachment.rest;

import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.skill.topic.attachment.service.AttachmentService;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.activation.MimetypesFileTypeMap;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.IOException;


@Path("/skills")
public class AttachmentResource {

    @Inject
    private AttachmentService attachmentService;

    @POST
    @Path("/{skill-id}/topics/{topic-id}/upload")
    @Consumes("multipart/form-data")
    public Response uploadFile(MultipartFormDataInput input, @PathParam("skill-id") Long skillId, @PathParam("topic-id") Long topicId) throws IOException, ResourceNotFoundException, InputValidationException {
        attachmentService.uploadFiles(input, skillId, topicId);
        return Response.ok("Successfully Uploaded").build();
    }

    @GET
    @Path("/{skill-id}/topics/{topic-id}/download/{file-name}")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response getFileByName(@PathParam("file-name") String fileName, @PathParam("skill-id") Long skillId, @PathParam("topic-id") Long topicId) throws IOException, ResourceNotFoundException, InputValidationException {
        File returnFile = attachmentService.getConsistentFileByNameAndTopicId(topicId, fileName);
        String mimeType = new MimetypesFileTypeMap().getContentType(returnFile);
        return Response.ok(returnFile, mimeType).header("Content-Disposition", "attachment; filename=\"" + fileName + "\"").build();
    }

    @GET
    @Path("/{skill-id}/topics/{topic-id}/attachments")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getFilesByTopicId(@PathParam("skill-id") Long skillId, @PathParam("topic-id") Long topicId) throws ResourceNotFoundException, InputValidationException {
        return Response.ok(attachmentService.getConsistentData(skillId,topicId)).build();
    }

    @DELETE
    @Path("/{skill-id}/topics/{topic-id}/delete-file/{file-name}")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    public Response deleteFile(@PathParam("file-name") String fileName, @PathParam("skill-id") Long skillId, @PathParam("topic-id") Long topicId) throws ResourceNotFoundException, InputValidationException {
        attachmentService.deleteFiles(fileName, skillId, topicId);
        return Response.noContent().build();
    }


}
