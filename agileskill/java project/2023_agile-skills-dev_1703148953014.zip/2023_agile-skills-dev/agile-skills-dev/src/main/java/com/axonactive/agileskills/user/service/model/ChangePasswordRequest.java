package com.axonactive.agileskills.user.service.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_NEW_PASSWORD_BLANK_OR_NULL;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_PASSWORD_BLANK_OR_NULL;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ChangePasswordRequest {
    @ApiModelProperty(example = "encrypted string")
    @NotBlank(message = KEY_PASSWORD_BLANK_OR_NULL)
    private String oldPassword;

    @ApiModelProperty(example = "encrypted string")
    @NotBlank(message = KEY_NEW_PASSWORD_BLANK_OR_NULL)
    private String newPassword;
}
