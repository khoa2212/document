package com.axonactive.agileskills.position.entity;

import com.axonactive.agileskills.department.team.entity.TeamEntity;
import com.axonactive.agileskills.position.requiredskill.entity.RequiredSkillEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.List;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "position")
public class PositionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "position", cascade = CascadeType.ALL)
    private List<RequiredSkillEntity> requiredSkillList;

    @Column(name = "position_name", nullable = false)
    private String name;

    @Column(length = 2000)
    private String note;

    @Column(name = "status", nullable = false)
    @Enumerated(EnumType.STRING)
    private PositionStatusEnum status;

    @Column(nullable = false)
    private Integer quantity;

    @ManyToOne
    @JoinColumn(name = "team_id", nullable = false)
    private TeamEntity team;

    private LocalDateTime openedDate;
    private LocalDateTime createdDate;
    private LocalDateTime closedDate;
}
