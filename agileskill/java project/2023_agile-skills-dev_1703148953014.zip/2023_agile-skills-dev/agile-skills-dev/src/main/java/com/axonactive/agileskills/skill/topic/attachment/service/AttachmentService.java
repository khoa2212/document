package com.axonactive.agileskills.skill.topic.attachment.service;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.skill.dao.SkillDAO;
import com.axonactive.agileskills.skill.entity.SkillEntity;
import com.axonactive.agileskills.skill.topic.attachment.dao.AttachmentDAO;
import com.axonactive.agileskills.skill.topic.attachment.entity.AttachmentEntity;
import com.axonactive.agileskills.skill.topic.attachment.service.model.FileInfo;
import com.axonactive.agileskills.skill.topic.dao.TopicDAO;
import com.axonactive.agileskills.skill.topic.entity.TopicEntity;
import com.axonactive.agileskills.skill.topic.service.TopicService;
import com.axonactive.agileskills.skill.topic.service.model.Topic;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.hibernate.validator.messageinterpolation.ParameterMessageInterpolator;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.ws.rs.core.MultivaluedMap;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static com.axonactive.agileskills.base.exception.ErrorMessage.ATTACHMENT_NAME_LENGTH_CONSTRAINT;
import static com.axonactive.agileskills.base.exception.ErrorMessage.ATTACHMENT_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.FILE_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.FILE_SIZE_EXCEEDS_MAX_ALLOWED;
import static com.axonactive.agileskills.base.exception.ErrorMessage.INVALID_DIRECTORY;
import static com.axonactive.agileskills.base.exception.ErrorMessage.INVALID_FORM;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_ATTACHMENT_NAME_LENGTH_CONSTRAINT;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_ATTACHMENT_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_DIRECTORY_PATH;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_FILE_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_FILE_SIZE_EXCEEDS_MAX_ALLOWED;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_INVALID_FORM;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_SKILL_DIRECTORY_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_SKILL_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_TOPIC_DIRECTORY_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_TOPIC_DOES_NOT_BELONG_TO_THIS_SKILL;
import static com.axonactive.agileskills.base.exception.ErrorMessage.KEY_TOPIC_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.MAX_ATTACHMENT_NAME_LENGTH;
import static com.axonactive.agileskills.base.exception.ErrorMessage.MAX_FILE_SIZE;
import static com.axonactive.agileskills.base.exception.ErrorMessage.SKILL_DIRECTORY_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.SKILL_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.TOPIC_DIRECTORY_NOT_FOUND;
import static com.axonactive.agileskills.base.exception.ErrorMessage.TOPIC_DOES_NOT_BELONG_TO_THIS_SKILL;
import static com.axonactive.agileskills.base.exception.ErrorMessage.TOPIC_NOT_FOUND;

@Stateless
public class AttachmentService {

    public static final String DATABASE = "DATABASE";
    public static final String STORAGE = "STORAGE";
    private static final Validator validator = Validation.byDefaultProvider()
            .configure()
            .messageInterpolator(new ParameterMessageInterpolator())
            .buildValidatorFactory()
            .getValidator();
    private final String UPLOADED_FILE_PATH = "/opt/jboss/wildfly/storage/skills";

    @Inject
    private SkillDAO skillDAO;

    @Inject
    private TopicDAO topicDAO;

    @Inject
    private TopicService topicService;

    @Inject
    private AttachmentDAO attachmentDAO;


    public void uploadFiles(MultipartFormDataInput input, Long skillId, Long topicId) throws ResourceNotFoundException, InputValidationException, IOException {
        SkillEntity skillEntity = skillDAO.findByIdAndStatus(skillId, StatusEnum.ACTIVE)
                .orElseThrow(()
                        -> new ResourceNotFoundException(KEY_SKILL_NOT_FOUND, SKILL_NOT_FOUND));

        List<Long> topicIdList = topicService.getBySkillIdAndStatus(skillId, StatusEnum.ACTIVE).stream().map(Topic::getId).collect(Collectors.toList());

        checkTopicId(topicIdList, topicId);
        checkValidForm(input);

        Map<String, List<InputPart>> uploadForm = input.getFormDataMap();
        List<InputPart> inputParts = uploadForm.get("attachment");

        for (InputPart inputPart : inputParts) {
            try {
                String fileName = getOriginalFileName(inputPart);
                String savedFileName = getSavedFileName(fileName);
                InputStream inputStream = inputPart.getBody(InputStream.class, null);

                byte[] bytes = IOUtils.toByteArray(inputStream);

                if (!fileName.isBlank()) {
                    writeFile(bytes, savedFileName, skillEntity.getId(), topicId);
                }
            } catch (IOException e) {
                throw new IOException();
            }
        }
    }

    private void checkFormDataInputKey(MultipartFormDataInput input) throws InputValidationException {
        Set<String> keys = input.getFormDataMap().keySet();
        if (keys.isEmpty() || keys.stream().allMatch(k -> "".toLowerCase().equalsIgnoreCase(k.trim())) || keys.stream().allMatch(Objects::isNull)) {
            throw new InputValidationException(KEY_INVALID_FORM, INVALID_FORM);
        }
    }

    private void checkFormDataInputValue(List<InputPart> inputParts) throws InputValidationException {
        if (inputParts == null || inputParts.isEmpty()) {
            throw new InputValidationException(KEY_ATTACHMENT_NOT_FOUND, ATTACHMENT_NOT_FOUND);
        } else if (inputParts.size() == 1) {
            String fileName = getOriginalFileName(inputParts.get(0));
            if (fileName.trim().isEmpty() || fileName.isBlank()) {
                throw new InputValidationException(KEY_ATTACHMENT_NOT_FOUND, ATTACHMENT_NOT_FOUND);
            }
        } else if (inputParts.stream().map(this::getOriginalFileName).allMatch(String::isBlank)) {
            throw new InputValidationException(KEY_ATTACHMENT_NOT_FOUND, ATTACHMENT_NOT_FOUND);
        }
    }

    private void checkValidForm(MultipartFormDataInput input) throws InputValidationException {
        checkFormDataInputKey(input);

        Map<String, List<InputPart>> uploadForm = input.getFormDataMap();
        List<InputPart> inputParts = uploadForm.get("attachment");

        checkFormDataInputValue(inputParts);
    }

    private String getOriginalFileName(InputPart inputPart) {
        MultivaluedMap<String, String> header = inputPart.getHeaders();


        String[] contentDisposition = header.getFirst("Content-Disposition").split(";");
        for (String filename : contentDisposition) {
            if ((filename.trim().startsWith("filename"))) {
                String[] name = filename.split("=");
                return name[1].trim().replaceAll("\"", "");
            }
        }
        return "unknown";
    }

    private String getSavedFileName(String originalFileName) {
        long currentTimestamp = System.currentTimeMillis();

        String baseName = FilenameUtils.getBaseName(originalFileName);
        String ext = FilenameUtils.getExtension(originalFileName);
        return baseName + "_" + currentTimestamp + "." + ext;
    }

    private void checkFileSize(byte[] content) throws InputValidationException {
        if (content.length > MAX_FILE_SIZE) {
            throw new InputValidationException(KEY_FILE_SIZE_EXCEEDS_MAX_ALLOWED, FILE_SIZE_EXCEEDS_MAX_ALLOWED);
        }
    }

    private void checkTopicId(List<Long> topicIdList, Long topicId) throws ResourceNotFoundException {
        if (topicIdList.isEmpty() || !topicIdList.contains(topicId)) {
            throw new ResourceNotFoundException(KEY_TOPIC_NOT_FOUND, TOPIC_NOT_FOUND);
        }
    }

    private void writeFile(byte[] content, String filename, Long skillEntityId, Long topicEntityId) throws IOException, InputValidationException, ResourceNotFoundException {
        checkFileSize(content);

        List<String> paths = Arrays.asList(UPLOADED_FILE_PATH, skillEntityId.toString(), topicEntityId.toString(), filename);
        File file = createDirectoryForAttachment(paths);

        if (!file.exists()) {
            file.createNewFile();
        }

        createAttachmentEntity(filename, topicEntityId, paths);

        FileOutputStream fop = new FileOutputStream(file);

        fop.write(content);
        fop.flush();
        fop.close();
    }

    private File createDirectoryForAttachment(List<String> paths) throws InputValidationException {
        checkValidPath(paths);

        StringBuilder directoryPath = createDirectoryOnServer(paths);

        String finalDir = directoryPath + "/" + paths.get(paths.size() - 1);
        return new File(finalDir);
    }

    private StringBuilder createDirectoryOnServer(List<String> paths) {
        int count = 0;
        StringBuilder directoryPath = new StringBuilder();
        do {
            directoryPath.append("/").append(paths.get(count));
            makeDir(directoryPath.toString());
            count++;
        } while (count < paths.size() - 1);

        directoryPath.deleteCharAt(0);
        return directoryPath;
    }

    private void checkValidPath(List<String> paths) throws InputValidationException {
        List<String> specialCharList = Arrays.asList("\\", "/", ":", "*", "?", "<", ">");
        for (int i = 1; i < paths.size(); i++) {
            boolean isNotValidPath = specialCharList.stream().anyMatch(paths.get(i)::contains);
            if (isNotValidPath) {
                throw new InputValidationException(KEY_DIRECTORY_PATH, INVALID_DIRECTORY);
            }
        }
        if (paths.isEmpty()) {
            throw new InputValidationException(KEY_DIRECTORY_PATH, INVALID_DIRECTORY);
        }
    }

    private void makeDir(String path) {
        File tempDir = new File(path);
        if (!tempDir.isDirectory()) {
            tempDir.mkdir();
        }
    }

    public File getConsistentFileByNameAndTopicId(Long topicId, String fileName) throws ResourceNotFoundException {
        File file = new File(createPathFromTopicId(topicId) + "/" + fileName);
        validateDirectory(file);
        isExistedInDB(topicId, fileName);
        return file;
    }

    public List<String> getConsistentData(Long skillId, Long topicId) throws ResourceNotFoundException, InputValidationException {

        SkillEntity skillEntity = skillDAO.findByIdAndStatus(skillId, StatusEnum.ACTIVE)
                .orElseThrow(()
                        -> new ResourceNotFoundException(KEY_SKILL_NOT_FOUND, SKILL_NOT_FOUND));

        TopicEntity topicEntity = topicDAO.findByIdAndStatus(topicId, StatusEnum.ACTIVE)
                .orElseThrow(()
                        -> new ResourceNotFoundException(KEY_TOPIC_NOT_FOUND, TOPIC_NOT_FOUND));

        checkSkillTopicConstraint(skillEntity, topicEntity);

        List<String> attachmentNameList = getAttachmentNamesByTopicId(topicId);
        List<String> fileNameList = getFileNamesByTopicId(topicId);
        List<String> consistentDetails = new ArrayList<>();
        List<String> consistentAttachmentNames = attachmentNameList.stream()
                .filter(fileNameList::contains)
                .collect(Collectors.toList());

        consistentDetails.addAll(consistentAttachmentNames);

        return consistentDetails;
    }

    public boolean checkSynchronizationByTopicId(Long topicId) throws ResourceNotFoundException {
        List<String> attachmentNameList = getAttachmentNamesByTopicId(topicId);
        List<String> fileNameList = getFileNamesByTopicId(topicId);
        return CollectionUtils.isEqualCollection(attachmentNameList, fileNameList);
    }

    public List<FileInfo> getAllInconsistentData() throws ResourceNotFoundException {
        List<SkillEntity> skillEntityList = skillDAO.findAll();

        List<FileInfo> inconsistentDetails = new ArrayList<>();

        for (SkillEntity skillEntity : skillEntityList) {
            List<TopicEntity> topicEntityList = topicDAO.findBySkillId(skillEntity.getId());

            List<FileInfo> inconsistentData = new ArrayList<>();

            for (TopicEntity topicEntity : topicEntityList) {
                inconsistentData.addAll(getAttachmentsNotInDatabase(topicEntity.getId(), topicEntity));
                inconsistentData.addAll(getAttachmentsNotInStorage(topicEntity.getId(), topicEntity));
            }
            inconsistentDetails.addAll(inconsistentData);
        }

        return inconsistentDetails;
    }

    private List<FileInfo> getAttachmentsNotInDatabase(Long topicId, TopicEntity topic) throws ResourceNotFoundException {
        List<String> attachmentNameList = getAttachmentNameList(topicId);
        List<String> fileNameList = getFileNamesByTopicId(topicId);

        return fileNameList.stream()
                .filter(fileName -> !attachmentNameList.contains(fileName))
                .map(fileName -> createFileInfo(topic, topicId, fileName, STORAGE))
                .collect(Collectors.toList());
    }

    private List<FileInfo> getAttachmentsNotInStorage(Long topicId, TopicEntity topic) throws ResourceNotFoundException {
        List<String> attachmentNameList = getAttachmentNameList(topicId);
        List<String> fileNameList = getFileNamesByTopicId(topicId);
        return attachmentNameList.stream()
                .filter(attachmentName -> !fileNameList.contains(attachmentName))
                .map(attachmentName -> createFileInfo(topic, topicId, attachmentName, DATABASE))
                .collect(Collectors.toList());
    }

    private List<String> getAttachmentNameList(Long topicId) {
        return attachmentDAO.findByTopicId(topicId).stream()
                .map(AttachmentEntity::getName)
                .sorted()
                .collect(Collectors.toList());
    }

    private FileInfo createFileInfo(TopicEntity topic, Long topicId, String fileName, String place) {
        return FileInfo.builder()
                .skillName(topic.getSkill().getName())
                .skillId(topic.getSkill().getId())
                .topicName(topic.getName())
                .topicId(topicId)
                .place(place)
                .fileName(fileName)
                .build();
    }

    private void createAttachmentEntity(String fileName, Long topicId, List<String> directories) throws ResourceNotFoundException, InputValidationException {
        TopicEntity topic = topicDAO.findById(topicId).orElseThrow(
                () -> new ResourceNotFoundException(KEY_TOPIC_NOT_FOUND, TOPIC_NOT_FOUND));

        if (fileName.trim().length() > MAX_ATTACHMENT_NAME_LENGTH) {
            throw new InputValidationException(KEY_ATTACHMENT_NAME_LENGTH_CONSTRAINT, ATTACHMENT_NAME_LENGTH_CONSTRAINT);
        }

        AttachmentEntity attachmentEntity = AttachmentEntity.builder()
                .topic(topic)
                .name(fileName)
                .directory(createDirectoryOnServer(directories).toString())
                .build();

        attachmentDAO.create(attachmentEntity);
    }

    private void deleteAttachmentEntity(Long topicId, String fileName) throws ResourceNotFoundException {
        AttachmentEntity attachment = attachmentDAO.findByNameAndTopicId(topicId, fileName).orElseThrow(() -> new ResourceNotFoundException(KEY_ATTACHMENT_NOT_FOUND, ATTACHMENT_NOT_FOUND));
        attachmentDAO.remove(attachment);
    }

    public List<String> getAttachmentNamesByTopicId(Long topicId) {
        return attachmentDAO.findByTopicId(topicId).stream().sorted(Comparator.comparing(AttachmentEntity::getCreatedDateTime)).map(AttachmentEntity::getName).collect(Collectors.toList());
    }

    public List<String> getFileNamesByTopicId(Long topicId) throws ResourceNotFoundException {
        TopicEntity topic = topicDAO.findById(topicId).orElseThrow(() -> new ResourceNotFoundException(KEY_TOPIC_NOT_FOUND, TOPIC_NOT_FOUND));
        SkillEntity skill = topic.getSkill();
        File file = new File(UPLOADED_FILE_PATH + "/" + skill.getId() + "/" + topicId);
        List<String> fileNameList = new ArrayList<>();
        if (file.exists() && file.listFiles().length != 0) {
            fileNameList = Arrays.asList(file.listFiles()).stream().map(File::getName).collect(Collectors.toList());
        }
        return fileNameList;
    }

    private String createPathFromTopicId(Long topicId) throws ResourceNotFoundException {
        TopicEntity topic = topicDAO.findById(topicId).orElseThrow(() -> new ResourceNotFoundException(KEY_TOPIC_NOT_FOUND, TOPIC_NOT_FOUND));
        SkillEntity skill = topic.getSkill();
        return UPLOADED_FILE_PATH + "/" + skill.getId() + "/" + topic.getId() + "/";
    }

    private void validateDirectory(File file) throws ResourceNotFoundException {
        if (!file.exists()) throw new ResourceNotFoundException(KEY_FILE_NOT_FOUND, FILE_NOT_FOUND);
    }

    public void deleteFiles(String filename, Long skillId, Long topicId) throws InputValidationException, ResourceNotFoundException {
        File topicFiles = getTopicDirectory(skillId, topicId);
        File[] files = topicFiles.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.getName().equals(filename)) {
                    if (file.delete()) {
                        deleteAttachmentEntity(topicId, filename);
                        return;
                    }
                }
            }
        }
        throw new ResourceNotFoundException(KEY_FILE_NOT_FOUND, FILE_NOT_FOUND);
    }

    private void checkSkillTopicConstraint(SkillEntity skillEntity, TopicEntity topicEntity) throws InputValidationException {
        if (!topicEntity.getSkill().getId().equals(skillEntity.getId())) {
            throw new InputValidationException(KEY_TOPIC_DOES_NOT_BELONG_TO_THIS_SKILL, TOPIC_DOES_NOT_BELONG_TO_THIS_SKILL);
        }
    }

    private File getTopicDirectory(Long skillId, Long topicId) throws ResourceNotFoundException, InputValidationException {

        SkillEntity skillEntity = skillDAO.findByIdAndStatus(skillId, StatusEnum.ACTIVE)
                .orElseThrow(()
                        -> new ResourceNotFoundException(KEY_SKILL_NOT_FOUND, SKILL_NOT_FOUND));

        TopicEntity topicEntity = topicDAO.findByIdAndStatus(topicId, StatusEnum.ACTIVE)
                .orElseThrow(()
                        -> new ResourceNotFoundException(KEY_TOPIC_NOT_FOUND, TOPIC_NOT_FOUND));

        checkSkillTopicConstraint(skillEntity, topicEntity);

        File[] topicFiles = checkTopicDirectoryValid(skillEntity);

        boolean topicFound = false;

        File eachFile = null;

        for (File topicFile : topicFiles) {
            if (topicFile.getName().equals(String.valueOf(topicEntity.getId()))) {
                topicFound = true;
                eachFile = new File(topicFile, "");
                break;
            }
        }
        if (!topicFound) {
            throw new ResourceNotFoundException(KEY_TOPIC_DIRECTORY_NOT_FOUND, TOPIC_DIRECTORY_NOT_FOUND);
        }
        return eachFile;
    }

    private File[] checkTopicDirectoryValid(SkillEntity skillEntity) throws ResourceNotFoundException {
        File skillDirectory = new File(UPLOADED_FILE_PATH + "/" + skillEntity.getId());

        if (!skillDirectory.exists()) {
            throw new ResourceNotFoundException(KEY_SKILL_DIRECTORY_NOT_FOUND, SKILL_DIRECTORY_NOT_FOUND);
        }
        File[] topicFiles = skillDirectory.listFiles();
        if (topicFiles == null) {
            throw new ResourceNotFoundException(KEY_TOPIC_DIRECTORY_NOT_FOUND, TOPIC_DIRECTORY_NOT_FOUND);
        }
        return topicFiles;
    }

    private void isExistedInDB(Long topicId, String fileName) throws ResourceNotFoundException {
        List<String> attachmentNameList = attachmentDAO.findByTopicId(topicId).stream().map(AttachmentEntity::getName).collect(Collectors.toList());
        boolean isExisted = attachmentNameList.stream().anyMatch(s -> s.equals(fileName));
        if (!isExisted) throw new ResourceNotFoundException(KEY_ATTACHMENT_NOT_FOUND, ATTACHMENT_NOT_FOUND);
    }

}
