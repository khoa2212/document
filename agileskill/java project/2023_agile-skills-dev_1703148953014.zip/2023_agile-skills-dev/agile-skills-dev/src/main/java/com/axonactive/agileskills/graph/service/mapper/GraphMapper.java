package com.axonactive.agileskills.graph.service.mapper;

import com.axonactive.agileskills.base.mapper.BaseMapper;
import com.axonactive.agileskills.graph.entity.GraphEntity;
import com.axonactive.agileskills.graph.service.model.Graph;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "cdi", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface GraphMapper extends BaseMapper<GraphEntity, Graph> {
}
