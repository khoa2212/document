package com.axonactive.agileskills.base.utility;

import lombok.Getter;
import lombok.Setter;

import javax.ws.rs.FormParam;
import java.io.File;

@Getter
@Setter
public class FormDataExcel {
    @FormParam("file")
    private File file;
}
