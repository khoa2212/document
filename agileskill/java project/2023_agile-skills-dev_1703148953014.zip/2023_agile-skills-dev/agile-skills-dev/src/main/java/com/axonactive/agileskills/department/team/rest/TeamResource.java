package com.axonactive.agileskills.department.team.rest;

import com.axonactive.agileskills.base.entity.StatusEnum;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.department.team.service.TeamService;
import com.axonactive.agileskills.department.team.service.model.Team;
import com.axonactive.agileskills.skill.service.model.Skill;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/departments")
@Api(tags = {"Teams"})
public class TeamResource {

    @Inject
    private TeamService teamService;

    @GET
    @Path("/{department-id}/teams")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get active team list by department id")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get active team list by department id successfully", response = Skill.class, responseContainer = "List"),
            @ApiResponse(code = 404, message = "Department not found"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getActiveListByDepartmentId(@ApiParam(required = true, name = "department-id") @PathParam("department-id") Long departmentId) throws ResourceNotFoundException {
        return Response.ok(teamService.getByDepartmentIdAndStatus(departmentId, StatusEnum.ACTIVE)).build();
    }

    @GET
    @Path("/teams")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get active team list")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Get active team list successfully", response = Team.class, responseContainer = "List"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getActiveList() {
        return Response.ok(teamService.getByStatus(StatusEnum.ACTIVE)).build();
    }
}
