package com.axonactive.agileskills.skill.topic.attachment.service;

import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.skill.dao.SkillDAO;
import com.axonactive.agileskills.skill.entity.SkillEntity;
import com.axonactive.agileskills.skill.topic.attachment.dao.AttachmentDAO;
import com.axonactive.agileskills.skill.topic.attachment.entity.AttachmentEntity;
import com.axonactive.agileskills.skill.topic.attachment.service.model.FileInfo;
import com.axonactive.agileskills.skill.topic.dao.TopicDAO;
import com.axonactive.agileskills.skill.topic.entity.TopicEntity;
import com.axonactive.agileskills.skill.topic.service.TopicService;
import com.axonactive.agileskills.skill.topic.service.model.Topic;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.CleanupMode;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.core.MultivaluedMap;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.axonactive.agileskills.base.entity.StatusEnum.ACTIVE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class})
class UploadAndDownloadFileTest {
    @TempDir(cleanup = CleanupMode.ALWAYS)
    static Path tempDir;
    @TempDir(cleanup = CleanupMode.ALWAYS)
    static Path tempFile;
    private final String UPLOADED_FILE_PATH = "/opt/jboss/wildfly/storage/skills";
    @Mock
    private TopicDAO topicDAO;
    @Mock
    private AttachmentDAO attachmentDAO;
    @Mock
    private SkillDAO skillDAO;
    @InjectMocks
    private AttachmentService attachmentService;
    @Mock
    private TopicService topicService;

    @BeforeEach
    void setUp() throws IOException {
        String skillId = "1";
        String topicId = "1";
        tempDir = Paths.get(UPLOADED_FILE_PATH, skillId, topicId);
        Files.createDirectories(tempDir);
        String filename = "testFile.txt";
        tempFile = Files.createFile(tempDir.resolve(filename));
    }

    @AfterEach
    void tearDown() throws IOException {
        File file = new File(tempDir.toString());
        File[] fileList = file.listFiles();
        for (File item : fileList
        ) {
            Files.deleteIfExists(item.toPath());
        }
        Files.deleteIfExists(tempDir);
    }

    @Test
    void getAllInconsistentAttachment_returnList() throws ResourceNotFoundException {
        SkillEntity skill = getSkillEntity();
        when(skillDAO.findAll()).thenReturn(Arrays.asList(skill));
        TopicEntity topicEntity = getTopic1Entity(skill);

        when(topicDAO.findBySkillId(1L)).thenReturn(Arrays.asList(topicEntity));
        when(topicDAO.findById(1L)).thenReturn(Optional.of(topicEntity));
        when(attachmentDAO.findByTopicId(1L)).thenReturn(List.of(getAttachmentEntity(1L, "testFileAFail.txt", getTopicEntity(1L, "OOP", getSkillEntity()))));

        List<FileInfo> result = attachmentService.getAllInconsistentData();

        assertEquals(2, result.size());
    }


    private SkillEntity getSkillEntity() {
        return SkillEntity.builder()
                .id(1L)
                .name("Java")
                .description("Java is fun")
                .status(ACTIVE)
                .build();
    }

    @Test
    void uploadFiles_ValidFiles_OperationSuccessfully() throws ResourceNotFoundException, InputValidationException, IOException {
        MultipartFormDataInput inputForm = mock(MultipartFormDataInput.class);
        InputPart attachment = mock(InputPart.class);
        MultivaluedMap<String, String> header = mock(MultivaluedMap.class);
        Map<String, List<InputPart>> uploadMap = new HashMap<>();
        uploadMap.put("attachment", Collections.singletonList(attachment));

        SkillEntity javaSkill = getSkillEntity();
        TopicEntity topicEntity = getTopicEntity(1L, "OOP", javaSkill);
        Topic topic1 = getTopic("OOP");
        List<Topic> topicListOfJavaSkill = List.of(topic1);
        File file = new File("src\\test\\resources\\testDB.sql");
        byte[] data = new byte[(int) Files.size(file.toPath())];
        Arrays.fill(data, (byte) 0);
        InputStream inputStream = new ByteArrayInputStream(data);

        when(skillDAO.findByIdAndStatus(1L, ACTIVE)).thenReturn(Optional.of(javaSkill));
        when(topicService.getBySkillIdAndStatus(1L, ACTIVE)).thenReturn(topicListOfJavaSkill);
        when(topicDAO.findById(1L)).thenReturn(Optional.of(topicEntity));

        when(attachment.getHeaders()).thenReturn(header);
        when(header.getFirst("Content-Disposition")).thenReturn("form-data;name=attachment; filename=testDB.sql");

        when(inputForm.getFormDataMap()).thenReturn(uploadMap);
        when(attachment.getBody(InputStream.class, null)).thenReturn(inputStream);

        attachmentService.uploadFiles(inputForm, javaSkill.getId(), topic1.getId());

        assertTrue(Files.exists(file.toPath()), "File is existed");
    }

    @Test
    void uploadFiles_FileSizeOver5M_ThrowInputValidationException() throws ResourceNotFoundException, InputValidationException, IOException {
        MultipartFormDataInput inputForm = mock(MultipartFormDataInput.class);
        InputPart attachment = mock(InputPart.class);
        MultivaluedMap<String, String> header = mock(MultivaluedMap.class);
        Map<String, List<InputPart>> uploadMap = new HashMap<>();
        uploadMap.put("attachment", Collections.singletonList(attachment));

        SkillEntity javaSkill = getSkillEntity();
        Topic topic1 = getTopic("OOP");
        List<Topic> topicListOfJavaSkill = List.of(topic1);
        File file = new File("src\\test\\resources\\INVALID_FILE_SIZE.zip");
        byte[] data = new byte[(int) Files.size(file.toPath())];
        Arrays.fill(data, (byte) 0);
        InputStream inputStream = new ByteArrayInputStream(data);

        when(skillDAO.findByIdAndStatus(1L, ACTIVE)).thenReturn(Optional.of(javaSkill));
        when(topicService.getBySkillIdAndStatus(1L, ACTIVE)).thenReturn(topicListOfJavaSkill);

        when(attachment.getHeaders()).thenReturn(header);
        when(header.getFirst("Content-Disposition")).thenReturn("form-data;name=attachment; filename=INVALID_FILE_SIZE.zip");

        when(inputForm.getFormDataMap()).thenReturn(uploadMap);
        when(attachment.getBody(InputStream.class, null)).thenReturn(inputStream);

        assertThrows(InputValidationException.class, () -> {
            attachmentService.uploadFiles(inputForm, javaSkill.getId(), topic1.getId());
        });
    }

    @Test
    void uploadFiles_SkillIdNotFound_ThrowResourceNotFoundException() {
        MultipartFormDataInput inputForm = mock(MultipartFormDataInput.class);

        assertThrows(ResourceNotFoundException.class, () -> {
            attachmentService.uploadFiles(inputForm, 99L, 99L);
        });
    }

    @Test
    void uploadFiles_TopicIdNotFound_ThrowResourceNotFoundException() throws ResourceNotFoundException {
        MultipartFormDataInput inputForm = mock(MultipartFormDataInput.class);
        SkillEntity javaSkill = getSkillEntity();

        assertThrows(ResourceNotFoundException.class, () -> {
            attachmentService.uploadFiles(inputForm, javaSkill.getId(), 99L);
        });
    }

    @Test
    void getConsistentFileByNameAndTopicId_AttachmentLost_ReturnException() {
        SkillEntity skill = getSkillEntity();
        when(topicDAO.findById(1L)).thenReturn(Optional.ofNullable(getTopicEntity(1L, "OOP", skill)));
        assertThrows(ResourceNotFoundException.class, () -> attachmentService.getConsistentFileByNameAndTopicId(1L, "testFile.txt"));
    }

    @Test
    void getFileNamesByTopicId_WrongName_ThrowResourceNotFoundException() {
        SkillEntity skill = getSkillEntity();
        when(topicDAO.findById(1L)).thenReturn(Optional.ofNullable(getTopicEntity(1L, "OOP", skill)));
        assertThrows(ResourceNotFoundException.class, () -> attachmentService.getConsistentFileByNameAndTopicId(1L, "test1File.txt"));
    }

    @Test
    void checkSynchronizationByTopicId_Synchronized_ReturnTrue() throws InputValidationException, ResourceNotFoundException {
        SkillEntity skill = getSkillEntity();
        AttachmentEntity attachmentEntity = getAttachmentEntity(1L, "testFile.txt", getTopicEntity(1L, "OOP", getSkillEntity()));
        List<AttachmentEntity> attachmentEntityList = Arrays.asList(attachmentEntity);
        when(attachmentDAO.findByTopicId(1L)).thenReturn(attachmentEntityList);
        when(topicDAO.findById(1L)).thenReturn(Optional.ofNullable(getTopicEntity(1L, "OOP", skill)));
        assertTrue(attachmentService.checkSynchronizationByTopicId(1L));
    }

    @Test
    void getAttachmentNamesByTopicId_Synchronized_returnNameList() throws InputValidationException, ResourceNotFoundException {
        SkillEntity skill = getSkillEntity();
        AttachmentEntity attachmentEntity = getAttachmentEntity(1L, "testFile.txt", getTopicEntity(1L, "OOP", getSkillEntity()));
        List<AttachmentEntity> attachmentEntityList = Arrays.asList(attachmentEntity);
        when(attachmentDAO.findByTopicId(1L)).thenReturn(attachmentEntityList);
        List<String> attachmentNameList = Arrays.asList("testFile.txt");
        assertEquals(attachmentNameList, attachmentService.getAttachmentNamesByTopicId(1L));
    }

    private Topic getTopic(String topicName) {
        Topic topic1 = Topic.builder()
                .id(1L)
                .name(topicName)
                .description("Topic description")
                .status(ACTIVE)
                .build();
        return topic1;
    }

    private TopicEntity getTopicEntity(Long id, String name, SkillEntity skillEntity) {
        TopicEntity topicEntity1 = TopicEntity.builder()
                .id(id)
                .name(name)
                .description("Topic description")
                .status(ACTIVE)
                .skill(skillEntity)
                .build();
        return topicEntity1;
    }

    private AttachmentEntity getAttachmentEntity(Long id, String name, TopicEntity topicEntity) {

        AttachmentEntity attachmentEntity = AttachmentEntity.builder()
                .id(id)
                .name(name)
                .directory(UPLOADED_FILE_PATH + "/" + "skills" + "/" + topicEntity.getSkill().getId().toString() + "/" + topicEntity.getId().toString())
                .topic(topicEntity)
                .createdDateTime(LocalDateTime.now())
                .build();
        return attachmentEntity;
    }

    private TopicEntity getTopic1Entity(SkillEntity skill) {
        return TopicEntity.builder()
                .id(1L)
                .name("Java 8")
                .description("Java 8 is fun")
                .status(ACTIVE)
                .skill(skill)
                .build();
    }

}
