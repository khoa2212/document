package com.axonactive.agileskills.skill.topic.attachment.service;

import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.skill.dao.SkillDAO;
import com.axonactive.agileskills.skill.entity.SkillEntity;
import com.axonactive.agileskills.skill.topic.attachment.dao.AttachmentDAO;
import com.axonactive.agileskills.skill.topic.attachment.entity.AttachmentEntity;
import com.axonactive.agileskills.skill.topic.dao.TopicDAO;
import com.axonactive.agileskills.skill.topic.entity.TopicEntity;
import com.axonactive.agileskills.skill.topic.service.model.Topic;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.CleanupMode;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import static com.axonactive.agileskills.base.entity.StatusEnum.ACTIVE;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class})
class AttachmentServiceTest {
    @TempDir(cleanup = CleanupMode.ALWAYS)
    static Path tempDir;
    @TempDir(cleanup = CleanupMode.ALWAYS)
    static Path tempFile;
    private final String UPLOADED_FILE_PATH = "/opt/jboss/wildfly/storage/skills";
    @Mock
    private TopicDAO topicDAO;
    @Mock
    private AttachmentDAO attachmentDAO;
    @Mock
    private SkillDAO skillDAO;
    @InjectMocks
    private AttachmentService attachmentService;


    @BeforeEach
    void setUp() throws IOException {
        String skillId = "1";
        String topicId = "1";
        tempDir = Paths.get(UPLOADED_FILE_PATH, skillId, topicId);
        Files.createDirectories(tempDir);
        String filename = "testFile.txt";
        tempFile = Files.createFile(tempDir.resolve(filename));
    }

    @AfterEach
    void tearDown() throws IOException {
        Files.deleteIfExists(tempFile);
        Files.deleteIfExists(tempDir);
    }

    @Test
    void deleteTopicAttachment_FileFound_ReturnVoid() throws InputValidationException, ResourceNotFoundException {
        SkillEntity skill = getSkillEntity();
        when(skillDAO.findByIdAndStatus(1L, ACTIVE)).thenReturn(Optional.of(skill));
        TopicEntity topicEntity = getTopic1Entity(skill);
        when(topicDAO.findByIdAndStatus(1L, ACTIVE)).thenReturn(Optional.of(topicEntity));

        String filename = "testFile.txt";

        File file = new File(tempFile.toString());

        AttachmentEntity attachment = AttachmentEntity.builder()
                .id(1L)
                .name(filename)
                .directory(tempDir.toString())
                .topic(topicEntity)
                .build();

        when(attachmentDAO.findByNameAndTopicId(topicEntity.getId(), file.getName())).thenReturn(Optional.ofNullable(attachment));

        attachmentService.deleteFiles(file.getName(), skill.getId(), topicEntity.getId());


        assertFalse(Files.exists(tempFile), "File was not deleted");
    }

    @Test
    void deleteTopicAttachment_FileNotFound_ReturnException() {
        SkillEntity skill = getSkillEntity();
        when(skillDAO.findByIdAndStatus(1L, ACTIVE)).thenReturn(Optional.of(skill));
        TopicEntity topic = getTopic1Entity(skill);
        when(topicDAO.findByIdAndStatus(1L, ACTIVE)).thenReturn(Optional.of(topic));

        String fileNotFound = "umbala.txt";

        assertThrows(ResourceNotFoundException.class, () -> attachmentService.deleteFiles(fileNotFound, skill.getId(), topic.getId()));
    }

    @Test
    void deleteTopicAttachment_TopicDirectoryNotFound_ReturnException() {

        SkillEntity skill = getSkillEntity();
        when(skillDAO.findByIdAndStatus(1L, ACTIVE)).thenReturn(Optional.of(skill));
        TopicEntity topic = getTopic2Entity(skill);
        when(topicDAO.findByIdAndStatus(2L, ACTIVE)).thenReturn(Optional.of(topic));

        String fileNotFound = "umbala.txt";

        assertThrows(ResourceNotFoundException.class, () -> attachmentService.deleteFiles(fileNotFound, skill.getId(), topic.getId()));
    }

    @Test
    void deleteTopicAttachment_SkillDirectoryNotFound_ReturnException() {

        SkillEntity skill = getSkillEntity1();
        when(skillDAO.findByIdAndStatus(2L, ACTIVE)).thenReturn(Optional.of(skill));
        TopicEntity topic = getTopic2Entity(skill);
        when(topicDAO.findByIdAndStatus(2L, ACTIVE)).thenReturn(Optional.of(topic));

        String fileNotFound = "umbala.txt";

        assertThrows(ResourceNotFoundException.class, () -> attachmentService.deleteFiles(fileNotFound, skill.getId(), topic.getId()));
    }

    @Test
    void deleteTopicAttachment_SkillNotFound_ReturnException() {

        SkillEntity skill = getSkillEntity1();
        when(skillDAO.findByIdAndStatus(2L, ACTIVE)).thenReturn(Optional.empty());
        TopicEntity topic = getTopic2Entity(skill);

        String fileNotFound = "umbala.txt";

        assertThrows(ResourceNotFoundException.class, () -> attachmentService.deleteFiles(fileNotFound, skill.getId(), topic.getId()));
    }

    @Test
    void deleteTopicAttachment_TopicNotFound_ReturnException() {

        SkillEntity skill = getSkillEntity1();
        when(skillDAO.findByIdAndStatus(2L, ACTIVE)).thenReturn(Optional.of(skill));
        TopicEntity topic = getTopic2Entity(skill);
        when(topicDAO.findByIdAndStatus(2L, ACTIVE)).thenReturn(Optional.empty());

        String fileNotFound = "umbala.txt";

        assertThrows(ResourceNotFoundException.class, () -> attachmentService.deleteFiles(fileNotFound, skill.getId(), topic.getId()));
    }

    private SkillEntity getSkillEntity() {
        return SkillEntity.builder()
                .id(1L)
                .name("Java")
                .description("Java is fun")
                .status(ACTIVE)
                .build();
    }

    private SkillEntity getSkillEntity1() {
        return SkillEntity.builder()
                .id(2L)
                .name("C#")
                .description("C# is fun")
                .status(ACTIVE)
                .build();
    }

    private TopicEntity getTopic2Entity(SkillEntity skill) {
        return TopicEntity.builder()
                .id(2L)
                .name("Java 9")
                .description("Java 9 is fun")
                .status(ACTIVE)
                .skill(skill)
                .build();
    }

    private TopicEntity getTopic1Entity(SkillEntity skill) {
        return TopicEntity.builder()
                .id(1L)
                .name("Java 8")
                .description("Java 8 is fun")
                .status(ACTIVE)
                .skill(skill)
                .build();
    }

    private Topic getTopic1() {
        return Topic.builder()
                .id(1L)
                .name("Updated topic name 1")
                .description("Updated topic description 1")
                .build();
    }

    private Topic getTopic(String topicName) {
        Topic topic1 = Topic.builder()
                .id(1L)
                .name(topicName)
                .description("Topic description")
                .status(ACTIVE)
                .build();
        return topic1;
    }

    private TopicEntity getTopicEntity(Long id, String name, SkillEntity skillEntity) {
        TopicEntity topicEntity1 = TopicEntity.builder()
                .id(id)
                .name(name)
                .description("Topic description")
                .status(ACTIVE)
                .skill(skillEntity)
                .build();
        return topicEntity1;
    }
}
