package com.axonactive.agileskills.utility;

import com.axonactive.agileskills.base.exception.InputValidationException;
import com.axonactive.agileskills.base.utility.ExcelUtils;
import com.axonactive.agileskills.skill.service.model.Skill;
import com.axonactive.agileskills.skill.topic.service.model.Topic;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import static com.axonactive.agileskills.base.entity.StatusEnum.ACTIVE;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith({MockitoExtension.class})
class ExcelUtilsTest {
    public static final String VALID_PATH_FILE = "./src/test/resources/VALID_EXCEL_FILE.xls";
    public static final String INVALID_PATH_FILE = "./src/test/resources/INVALID_FILE.txt";
    public static final String NOT_FOUND_PATH_FILE = "./src/test/resources/NOT_FOUND_FILE.txt";
    public static final String INVALID_TEMPLATE_PATH_FILE = "./src/test/resources/INVALID_TEMPLATE_FILE.txt";
    @InjectMocks
    private ExcelUtils excelUtils;

    @Mock
    private Workbook workbook;

    @Test
    void getSkillListFromExcelFile_ValidDataInExcelFile_ReturnListOfSkill() throws InputValidationException, IOException {
        List<Skill> expectedSkillList = getSkillList();

        ExcelUtils excelUtils = new ExcelUtils();
        File excelFile = new File(VALID_PATH_FILE);

        try (InputStream inputStream = new BufferedInputStream(new FileInputStream(excelFile))) {
            workbook = WorkbookFactory.create(inputStream);
            workbook.close();
        }

        List<Skill> actualSkillList = excelUtils.getSkillListFromExcelFile(excelFile);
        assertEquals(expectedSkillList.get(0).getName(), actualSkillList.get(0).getName());

        expectedSkillList.forEach(expectedSkill -> {
            assertEquals(expectedSkill.getName(), actualSkillList.get(0).getName());
            assertEquals(expectedSkill.getDescription(), actualSkillList.get(0).getDescription());
        });
    }

    @Test
    void getSkillListFromExcelFile_FileIsNotSupported_ThrowException() {
        File invalidFile = new File(INVALID_PATH_FILE);
        assertThrows(InputValidationException.class, () -> excelUtils.getSkillListFromExcelFile(invalidFile));
    }

    @Test
    void getSkillListFromExcelFile_FileIsNotFound_ThrowException() {
        File notFoundFile = new File(NOT_FOUND_PATH_FILE);
        assertThrows(InputValidationException.class, () -> excelUtils.getSkillListFromExcelFile(notFoundFile));
    }

    @Test
    void getSkillListFromExcelFile_TemplateNotSupported_ThrowException() {
        File invalidTemplateFile = new File(INVALID_TEMPLATE_PATH_FILE);
        assertThrows(InputValidationException.class, () -> excelUtils.getSkillListFromExcelFile(invalidTemplateFile));
    }

    private List<Skill> getSkillList() {
        Skill javaSkill = getSkill(getTopic("OOP"), getTopic("Hibernate"));
        Skill dockerSkill = getSkill(getTopic("Dockerfile"), getTopic("Dockercompose"));
        return Arrays.asList(javaSkill, dockerSkill);
    }

    private Skill getSkill(Topic topic1, Topic topic2) {
        return Skill.builder()
                .name("Java")
                .description("Java programming language description")
                .status(ACTIVE)
                .topicList(Arrays.asList(
                        topic1,
                        topic2
                ))
                .build();
    }

    private Topic getTopic(String topicName) {
        return Topic.builder()
                .name(topicName)
                .description("Topic description")
                .build();
    }
}