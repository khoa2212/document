package com.axonactive.agileskills.graph.service;

import com.axonactive.agileskills.base.exception.ResourceNotFoundException;
import com.axonactive.agileskills.department.entity.DepartmentEntity;
import com.axonactive.agileskills.department.team.entity.TeamEntity;
import com.axonactive.agileskills.graph.dao.GraphDAO;
import com.axonactive.agileskills.graph.entity.GraphEntity;
import com.axonactive.agileskills.graph.service.mapper.GraphMapper;
import com.axonactive.agileskills.graph.service.model.Graph;
import com.axonactive.agileskills.position.dao.PositionDAO;
import com.axonactive.agileskills.position.entity.PositionEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.validation.ConstraintViolationException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

import static com.axonactive.agileskills.base.entity.StatusEnum.ACTIVE;
import static com.axonactive.agileskills.position.entity.PositionStatusEnum.OPEN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith({MockitoExtension.class})
class GraphServiceTest {
    @InjectMocks
    private GraphService graphService;

    @Mock
    private GraphDAO graphDAO;

    @Mock
    private GraphMapper graphMapper;

    @Mock
    private PositionDAO positionDAO;

    @Test
    void getGraphByPositionId_OpenPositionExisted_ReturnModelGraph() throws ResourceNotFoundException {
        GraphEntity graphEntity = getGraphEntity();
        PositionEntity positionEntity = getOpenPositionEntity();

        Graph graphDTO = Graph.builder()
                .graphValue(graphEntity.getGraphValue())
                .positionId(graphEntity.getPositionId())
                .build();

        when(positionDAO.findByIdAndStatus(1L, OPEN)).thenReturn(Optional.of(positionEntity));
        when(graphDAO.findByPositionId(1L)).thenReturn(Optional.of(graphEntity));
        when(graphMapper.toDTO(graphEntity)).thenReturn(graphDTO);

        Graph actualGraph = graphService.getByPositionId(1L);

        assertEquals(graphDTO.getId(), actualGraph.getId());
        assertEquals(graphDTO.getGraphValue(), actualGraph.getGraphValue());
        assertEquals(graphDTO.getPositionId(), actualGraph.getPositionId());
    }

    @Test
    void getGraphByPositionId_OpenPositionNotExisted_ThrowResourceNotFoundException() throws ResourceNotFoundException {
        when(positionDAO.findByIdAndStatus(1L, OPEN)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> graphService.getByPositionId(1L));
    }

    @Test
    void saveGraph_GraphValueIsInvalid_ThrowConstrainException() {
        Graph nullGraphValueGraph = getGraphWithValue(null);
        Graph blankGraphValueGraph = getGraphWithValue(" ");
        Graph emptyGraphValueGraph = getGraphWithValue("");
        Graph moreThan100000CharGraph = getGraphWithValue("A".repeat(100001));

        Arrays.asList(nullGraphValueGraph, blankGraphValueGraph, emptyGraphValueGraph, moreThan100000CharGraph)
                .forEach(graph -> assertThrows(ConstraintViolationException.class, () -> graphService.save(graph)));
    }

    @Test
    void saveGraph_NullPositionId_ThrowResourceNotFoundException() {
        Graph nullPositionGraph = getGraphWithPositionId(null);

        assertThrows(ResourceNotFoundException.class, () -> graphService.save(nullPositionGraph));
    }

    @Test
    void saveGraph_PositionNotExisted_ThrowResourceNotFoundException() {
        Graph notExistedPositionGraph = getGraphWithPositionId(100L);

        when(positionDAO.findByIdAndStatus(100L, OPEN)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> graphService.save(notExistedPositionGraph));
    }

    @Test
    void saveGraph_ValidGraph_GraphEntityNotExisted_CreateNewGraph() throws ResourceNotFoundException {
        GraphEntity graphEntity = getGraphEntity();
        PositionEntity positionEntity = getOpenPositionEntity();
        Graph graphDTO = getGraphDTO();

        when(positionDAO.findByIdAndStatus(1L, OPEN)).thenReturn(Optional.of(positionEntity));
        when(graphDAO.findByPositionId(1L)).thenReturn(Optional.empty());
        when(graphDAO.create(any())).thenReturn(graphEntity);
        when(graphMapper.toDTO(graphEntity)).thenReturn(graphDTO);

        Graph resultedGraph = graphService.save(graphDTO);

        verify(graphDAO).create(any());

        assertEquals(resultedGraph.getId(), graphEntity.getId());
        assertEquals(resultedGraph.getGraphValue(), graphEntity.getGraphValue());
        assertEquals(resultedGraph.getPositionId(), graphEntity.getPositionId());
    }

    @Test
    void saveGraph_ValidGraph_GraphEntityExisted_UpdateGraph() throws ResourceNotFoundException {
        GraphEntity graphEntity = getGraphEntity();
        GraphEntity graphEntity1 = getGraphEntity1();
        PositionEntity positionEntity = getOpenPositionEntity();
        Graph graphDTO1 = getGraphDTO1();

        when(positionDAO.findByIdAndStatus(1L, OPEN)).thenReturn(Optional.of(positionEntity));
        when(graphDAO.findByPositionId(1L)).thenReturn(Optional.of(graphEntity));
        when(graphDAO.update(any())).thenReturn(graphEntity1);
        when(graphMapper.toDTO(graphEntity1)).thenReturn(graphDTO1);

        Graph resultedGraph = graphService.save(graphDTO1);

        verify(graphDAO).update(any());

        assertEquals(resultedGraph.getId(), graphEntity.getId());
        assertEquals(resultedGraph.getGraphValue(), graphEntity.getGraphValue());
        assertEquals(resultedGraph.getPositionId(), graphEntity.getPositionId());
    }

    @Test
    void deleteGraph_PositionIdNull_ThrowResourceNotFoundException() {
        assertThrows(ResourceNotFoundException.class, () -> graphService.delete(null));
    }

    @Test
    void deleteGraph_PositionIdNotExisted_ThrowResourceNotFoundException() {
        when(positionDAO.findByIdAndStatus(100L, OPEN)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> graphService.delete(100L));
    }

    @Test
    void deleteGraph_PositionGraphEntityExisted_DeletePositionGraphEntity() throws ResourceNotFoundException {
        GraphEntity graphEntity = getGraphEntity();
        PositionEntity positionEntity = getOpenPositionEntity();

        when(positionDAO.findByIdAndStatus(1L, OPEN)).thenReturn(Optional.of(positionEntity));
        when(graphDAO.findByPositionId(1L)).thenReturn(Optional.of(graphEntity));

        graphService.delete(1L);

        verify(graphDAO).remove(graphEntity);
    }

    @Test
    void deleteGraph_PositionGraphEntityNotFound_NoInteraction() throws ResourceNotFoundException {
        PositionEntity positionEntity = getOpenPositionEntity();

        when(positionDAO.findByIdAndStatus(1L, OPEN)).thenReturn(Optional.of(positionEntity));
        when(graphDAO.findByPositionId(1L)).thenReturn(Optional.empty());

        graphService.delete(1L);

        verify(graphDAO, never()).remove(any());
    }


    private Graph getGraphDTO() {
        return Graph.builder()
                .id(1L)
                .graphValue("{\"nodes\":[{\"width\":256,\"height\":48,\"id\":\"42\",\"position\":{\"x\":-601.3771507523245,\"y\":-953.6302041690619},\"type\":\"positionNode\",\"data\":{\"label\":\"Junior Java Developer 333\"},\"targetPosition\":\"top\",\"sourcePosition\":\"bottom\",\"selected\":false,\"positionAbsolute\":{\"x\":-601.3771507523245,\"y\":-953.6302041690619},\"dragging\":false},{\"width\":256,\"height\":40,\"id\":\"70\",\"type\":\"requiredSkillNote\",\"position\":{\"x\":-420.4528281487743,\"y\":-1116.583915627642},\"data\":{\"label\":\"Java\",\"skillId\":1,\"hidden\":false},\"targetPosition\":\"top\",\"sourcePosition\":\"bottom\",\"positionAbsolute\":{\"x\":-420.4528281487743,\"y\":-1116.583915627642},\"selected\":true,\"dragging\":false}],\"edges\":[{\"id\":\"e42-70\",\"source\":\"42\",\"target\":\"70\",\"type\":\"smoothstep\"}],\"viewport\":{\"x\":1215.0227574447808,\"y\":2356.2323915819998,\"zoom\":1.9495783085326006}}")
                .positionId(1L)
                .build();
    }

    private Graph getGraphDTO1() {
        return Graph.builder()
                .id(1L)
                .graphValue("abc")
                .positionId(1L)
                .build();
    }


    private Graph getGraphWithValue(String value) {
        return Graph.builder()
                .graphValue(value)
                .positionId(1L)
                .build();
    }

    private Graph getGraphWithPositionId(Long positionId) {
        return Graph.builder()
                .graphValue("value")
                .positionId(positionId)
                .build();
    }

    private GraphEntity getGraphEntity() {
        return GraphEntity.builder()
                .id(1L)
                .graphValue("{\"nodes\":[{\"width\":256,\"height\":48,\"id\":\"42\",\"position\":{\"x\":-601.3771507523245,\"y\":-953.6302041690619},\"type\":\"positionNode\",\"data\":{\"label\":\"Junior Java Developer 333\"},\"targetPosition\":\"top\",\"sourcePosition\":\"bottom\",\"selected\":false,\"positionAbsolute\":{\"x\":-601.3771507523245,\"y\":-953.6302041690619},\"dragging\":false},{\"width\":256,\"height\":40,\"id\":\"70\",\"type\":\"requiredSkillNote\",\"position\":{\"x\":-420.4528281487743,\"y\":-1116.583915627642},\"data\":{\"label\":\"Java\",\"skillId\":1,\"hidden\":false},\"targetPosition\":\"top\",\"sourcePosition\":\"bottom\",\"positionAbsolute\":{\"x\":-420.4528281487743,\"y\":-1116.583915627642},\"selected\":true,\"dragging\":false}],\"edges\":[{\"id\":\"e42-70\",\"source\":\"42\",\"target\":\"70\",\"type\":\"smoothstep\"}],\"viewport\":{\"x\":1215.0227574447808,\"y\":2356.2323915819998,\"zoom\":1.9495783085326006}}")
                .positionId(1L)
                .build();
    }

    private GraphEntity getGraphEntity1() {
        return GraphEntity.builder()
                .id(1L)
                .graphValue("abc")
                .positionId(1L)
                .build();
    }


    private PositionEntity getOpenPositionEntity() {
        return PositionEntity.builder()
                .id(1L)
                .name("Sample position 1")
                .note("A sample position 1")
                .quantity(8)
                .status(OPEN)
                .openedDate(LocalDateTime.now())
                .team(getActiveTeam())
                .createdDate(LocalDateTime.now())
                .build();
    }

    private TeamEntity getActiveTeam() {
        return TeamEntity.builder()
                .id(1L)
                .name("Sample team")
                .status(ACTIVE)
                .department(getDepartment())
                .build();
    }

    private DepartmentEntity getDepartment() {
        return DepartmentEntity.builder()
                .id(1L)
                .name("Sample department")
                .status(ACTIVE)
                .build();
    }
}