## AgileSkills Project

This project was created with Java EE 8 , a framework for building enterprise applications.
If you want to learn more about Java EE 8, please visit this website: https://javadoc.io/doc/javax/javaee-web-api


## Setting up

   Create [JBOSS_HOME] environment variable for your computer that points to your WildFly folder.

## Packaging and running the application

1. The application can be packaged using: 

   mvn clean package
  
   It produces the agileskills.war file in the /target directory.

2. Create datasource in `persistence.xml`: java:/agileskillsDS  under src/main/resources/META-INF.

3. Deploy the target's `agileskills.war` file to the Wildfly application server.

   The application is now runnable using target/agileskills.war 

   Access the application by visiting http://localhost:8080/agileskills/api in your web browser



## Dependencies

`Java JDK`: 11.0.18

`Apache Maven`: 3.8.8

`WildFly`: 26.1.3