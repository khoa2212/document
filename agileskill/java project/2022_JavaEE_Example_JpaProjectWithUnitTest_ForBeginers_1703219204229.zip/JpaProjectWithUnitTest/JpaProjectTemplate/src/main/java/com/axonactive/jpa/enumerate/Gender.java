package com.axonactive.jpa.enumerate;

public enum Gender {
    MALE, FEMALE, UNDEFINED
}
