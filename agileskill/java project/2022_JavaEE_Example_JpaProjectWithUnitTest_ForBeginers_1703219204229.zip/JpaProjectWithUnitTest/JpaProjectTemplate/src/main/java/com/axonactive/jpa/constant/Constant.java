package com.axonactive.jpa.constant;

public class Constant {
    private Constant(){

    }
    public static final String EMPLOYEE_ID_PARAMETER_NAME_SQL = "employeeId";

}
