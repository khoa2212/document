package com.axonactive.agileterm.exception;

public class SecurityException extends RuntimeException{

    public SecurityException (String message){
        super(message);
    }

}
