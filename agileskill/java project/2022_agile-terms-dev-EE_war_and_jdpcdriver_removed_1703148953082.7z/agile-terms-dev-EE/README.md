# Agile terms

## Description:

This is an online dictionary about Agile for Axon Active members who want to learn about Agile.
Learners can search everything Agile-related and proper description of them will be displayed.
Terms and description are contributed by Agile experts and can be voted by learners.

## Features:

User can do the following features:
<ul>
<li>Sign up for a new account</li>
<li>Search for a specific term </li>
<li>Contribute to an existing term</li>
<li>Create a new term</li>
<li>Upload file with terms and descriptions for those terms</li>
</ul>
<b>Login as Admin role</b><br />
<b>User name: </b> admin <br />
<b>Password: </b> Aavn123!@# <br />

## Environment
- JRE: Eclipse Temurin version 11.0.16
- Maven: Apache Maven 3.8.6
- Wildfly version 26.1.2
- JBDC: postgresql-42.4.1

## Clone the project

```
$ git clone --single-branch --branch dev-EE https://gitsource.axonactive.com/hcmc-itclass/agile-terms.git
```

## Build local database:

```
$ docker run --name agile-term-ee --restart unless-stopped -e TZ=Asia/Ho_Chi_Minh -e POSTGRES_DB=agile-term-ee -e POSTGRES_USER=admin -e POSTGRES_PASSWORD=1234 -d -p 5467:5432 postgres:14.4
```

## Deploy the application:

- Install and configure Flyway on your IntelliJ
- Set up JDBC in Flyway management
- Instruction on how to deploy AgileTerm application can be
  found [HERE](https://drive.google.com/file/d/1W2-dfbdaeVDhfON00YUo8HoY7fB7zOky/view?usp=sharing)
- After configuring, deploy the application

## Swagger:

- URL for Swagger of dev server: <b>192.168.70.67:8080/agileterm/docs</b>

- URL for Swagger of test server: <b>192.168.70.67:8081/agileterm/docs</b>

## Deploy with Jenkins

- Go to http://192.168.70.67:8088/ <br />
  <b>User name:</b> hcmc-it <br />
  <b>Password:</b> aavn123 <br />
- Build and deploy on dev server:  Go to jenkins_be_dev_EE & click Build Now to build Dev Server
- Build and deploy on test server:    Go to jenkins_be_test_EE & click Build Now to build Test Server

## Release Note:

- Version: v0.1.0