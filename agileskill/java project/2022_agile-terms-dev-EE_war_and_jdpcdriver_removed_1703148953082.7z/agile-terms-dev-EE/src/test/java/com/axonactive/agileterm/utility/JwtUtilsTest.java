package com.axonactive.agileterm.utility;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.axonactive.agileterm.config.AppConfigService;
import com.axonactive.agileterm.entity.Role;
import com.axonactive.agileterm.entity.UserEntity;
import com.axonactive.agileterm.entity.UserRoleAssignmentEntity;
import com.axonactive.agileterm.exception.ErrorMessage;
import com.axonactive.agileterm.exception.SecurityException;
import com.axonactive.agileterm.rest.client.model.JwtRequest;
import com.axonactive.agileterm.rest.model.JwtResponse;
import com.axonactive.agileterm.service.AuthenticationService;
import com.axonactive.agileterm.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class})
class JwtUtilsTest {

    @InjectMocks
    JwtUtils jwtUtils;

    @Mock
    UserService userService;

    @Mock
    AuthenticationService authenticationService;

    @Test
    void testGenerateToken_shouldReturnToken_whenCheckAuthenticationOK() {
        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();
        when(authenticationService.checkAuthentication(noobJwtRequest.getUsername(),
                noobJwtRequest.getPassword())).thenReturn(Boolean.TRUE);

        assertNotNull(jwtUtils.generateToken(noobJwtRequest));
    }

    @Test
    void testGenerateToken_ErrorMessage_whenAuthenticationFailed() {
        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();
        try {
            jwtUtils.generateToken(noobJwtRequest);
        }catch (Exception e){
            assertEquals(ErrorMessage.UNAUTHORIZED_ACCESS, e.getMessage());
        }
    }

    @Test
    void testValidateJwtToken_shouldReturnErrorMessage_whenAutorizationParameterIsNull() {
        try{
            jwtUtils.validateJwtToken(null);
        }catch (Exception e){
            assertEquals(ErrorMessage.UNAUTHORIZED_ACCESS, e.getMessage());
        }
    }

    @Test
    void testValidateJwtToken_shouldVerifyToken_whenGivenAnAuthenticatedToken() {
        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();
        when(authenticationService.checkAuthentication(noobJwtRequest.getUsername(),
                noobJwtRequest.getPassword())).thenReturn(Boolean.TRUE);
        String token = jwtUtils.generateToken(noobJwtRequest);

        try{
            jwtUtils.validateJwtToken(token);
        }catch (Exception e){
            assertEquals(ErrorMessage.UNAUTHORIZED_ACCESS, e.getMessage());
        }
    }



    @Test
    void testGetRoleFromToken_shouldReturnListContainingRoleOfUSER_whenGetRoleFromATokenCreatedFromAUserWithRoleUser() {
        UserEntity user = new UserEntity();

        UserRoleAssignmentEntity userRoleAssignmentEntity = new UserRoleAssignmentEntity();
        userRoleAssignmentEntity.setRole(Role.ROLE_USER);
        userRoleAssignmentEntity.setUserEntity(user);

        List<UserRoleAssignmentEntity> userRoleAssignmentEntityList = new ArrayList<>();
        userRoleAssignmentEntityList.add(userRoleAssignmentEntity);


        user.setUsername("noob");
        user.setPassword("Tonging244");
        user.setRoles(userRoleAssignmentEntityList);

        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();
        when(authenticationService.checkAuthentication(noobJwtRequest.getUsername(),
                noobJwtRequest.getPassword())).thenReturn(Boolean.TRUE);
        String token = jwtUtils.generateToken(noobJwtRequest);

        String authorization = "Bearer " + token;

        when(userService.validateUser("noob")).thenReturn(user);

        List<Role> expectedList = new ArrayList<>();
        expectedList.add(Role.ROLE_USER);

        assertEquals(expectedList, jwtUtils.getRoleFromToken(authorization));
    }



    @Test
    void testValidateUserIsAdmin_shouldPassTest_whenUserIsAdmin() {

        UserEntity user = new UserEntity();

        UserRoleAssignmentEntity userRoleAssignmentEntity = new UserRoleAssignmentEntity();
        userRoleAssignmentEntity.setRole(Role.ROLE_ADMIN);
        userRoleAssignmentEntity.setUserEntity(user);

        List<UserRoleAssignmentEntity> userRoleAssignmentEntityList = new ArrayList<>();
        userRoleAssignmentEntityList.add(userRoleAssignmentEntity);


        user.setUsername("noob");
        user.setPassword("Tonging244");
        user.setRoles(userRoleAssignmentEntityList);

        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();
        when(authenticationService.checkAuthentication(noobJwtRequest.getUsername(),
                noobJwtRequest.getPassword())).thenReturn(Boolean.TRUE);
        String token = jwtUtils.generateToken(noobJwtRequest);

        String authorization = "Bearer " + token;

        lenient().when(userService.validateUser("noob")).thenReturn(user);

        jwtUtils.validateUserIsAdmin(authorization);
    }

    @Test
    void testValidateUserIsAdmin_shouldThrowExceptionWithProperMessage_whenUserIsNotAdmin(){
        UserEntity user = new UserEntity();

        UserRoleAssignmentEntity userRoleAssignmentEntity = new UserRoleAssignmentEntity();
        userRoleAssignmentEntity.setRole(Role.ROLE_USER);
        userRoleAssignmentEntity.setUserEntity(user);

        List<UserRoleAssignmentEntity> userRoleAssignmentEntityList = new ArrayList<>();
        userRoleAssignmentEntityList.add(userRoleAssignmentEntity);

        user.setUsername("noob");
        user.setPassword("Tonging244");
        user.setRoles(userRoleAssignmentEntityList);

        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();
        when(authenticationService.checkAuthentication(noobJwtRequest.getUsername(),
                noobJwtRequest.getPassword())).thenReturn(Boolean.TRUE);
        String token = jwtUtils.generateToken(noobJwtRequest);

        String authorization = "Bearer " + token;

        lenient().when(userService.validateUser("noob")).thenReturn(user);

        try{
            jwtUtils.validateUserIsAdmin(authorization);
        }
        catch (SecurityException e){
            assertEquals(ErrorMessage.UNAUTHORIZED_ACCESS, e.getMessage());
        }

    }


    @Test
    void testGenerateJwtResponse_shouldCreateNewJwtResponse_whenInputAJwtRequest() {
        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();

        UserEntity noobUser = UserEntity.builder()
                .id(1)
                .username("noob")
                .email("noob@faw.com")
                .activated(false)
                .build();
        UserRoleAssignmentEntity noobRole = new UserRoleAssignmentEntity(1, Role.ROLE_USER, noobUser);
        noobUser.setRoles(List.of(noobRole));

        when(authenticationService.checkAuthentication(noobJwtRequest.getUsername(),
                noobJwtRequest.getPassword())).thenReturn(Boolean.TRUE);

        when(userService.validateUser(noobJwtRequest.getUsername()))
                .thenReturn(noobUser);

        JwtResponse newJwtResponse = jwtUtils.generateJwtResponse(noobJwtRequest);
        assertNotNull(newJwtResponse.getToken());
        assertEquals(noobJwtRequest.getUsername(), newJwtResponse.getUsername());
        assertEquals(List.of(String.valueOf(Role.ROLE_USER)), newJwtResponse.getRoles());
        assertFalse(newJwtResponse.getIsActive());
    }

    @Test
    void testIsUserActivated_shouldReturnAFalse_whenUserClaimFromTokenHasInActiveStatus() {
        UserEntity user = new UserEntity();
        user.setUsername("user");
        user.setPassword("1234");
        user.setActivated(false);

        JwtRequest userRequest = new JwtRequest();
        userRequest.setUsername("user");
        userRequest.setPassword("1234");


        when(userService.validateUser("user")).thenReturn(user);
        when(authenticationService.checkAuthentication(userRequest.getUsername(),userRequest.getPassword())).thenReturn(true);

        String token = jwtUtils.generateToken(userRequest);
        String authorization = "Bearer " + token;

        assertFalse(jwtUtils.isUserActivated(authorization));
    }

    @Test
    void testValidateAccountIsActive_shouldNotThrowException_whenIsActiveIsTrue() {
        UserEntity user = new UserEntity();

        UserRoleAssignmentEntity userRoleAssignmentEntity = new UserRoleAssignmentEntity();
        userRoleAssignmentEntity.setRole(Role.ROLE_ADMIN);
        userRoleAssignmentEntity.setUserEntity(user);

        List<UserRoleAssignmentEntity> userRoleAssignmentEntityList = new ArrayList<>();
        userRoleAssignmentEntityList.add(userRoleAssignmentEntity);


        user.setUsername("noob");
        user.setPassword("Tonging244");
        user.setRoles(userRoleAssignmentEntityList);
        user.setActivated(Boolean.TRUE);

        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();
        when(authenticationService.checkAuthentication(noobJwtRequest.getUsername(),
                noobJwtRequest.getPassword())).thenReturn(Boolean.TRUE);
        String token = jwtUtils.generateToken(noobJwtRequest);

        String authorization = "Bearer " + token;

        lenient().when(userService.validateUser("noob")).thenReturn(user);

        jwtUtils.validateAccountIsActive(authorization);
    }

    @Test
    void testValidateAccountIsActive_shouldThrowException_whenIsActiveIsFalse() {
        UserEntity user = new UserEntity();

        UserRoleAssignmentEntity userRoleAssignmentEntity = new UserRoleAssignmentEntity();
        userRoleAssignmentEntity.setRole(Role.ROLE_USER);
        userRoleAssignmentEntity.setUserEntity(user);

        List<UserRoleAssignmentEntity> userRoleAssignmentEntityList = new ArrayList<>();
        userRoleAssignmentEntityList.add(userRoleAssignmentEntity);


        user.setUsername("noob");
        user.setPassword("Tonging244");
        user.setRoles(userRoleAssignmentEntityList);
        user.setActivated(Boolean.FALSE);

        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();
        when(authenticationService.checkAuthentication(noobJwtRequest.getUsername(),
                noobJwtRequest.getPassword())).thenReturn(Boolean.TRUE);
        String token = jwtUtils.generateToken(noobJwtRequest);

        String authorization = "Bearer " + token;

        lenient().when(userService.validateUser("noob")).thenReturn(user);

        try{
            jwtUtils.validateAccountIsActive(authorization);
        }
        catch (SecurityException e){
            assertEquals(ErrorMessage.UNAUTHORIZED_ACCESS, e.getMessage());
        }

    }

    @Test
    void testIsSessionExpired_shouldThrowException_whenTokenTimeToLiveIsBeforeNow(){
        UserEntity user = new UserEntity();

        UserRoleAssignmentEntity userRoleAssignmentEntity = new UserRoleAssignmentEntity();
        userRoleAssignmentEntity.setRole(Role.ROLE_USER);
        userRoleAssignmentEntity.setUserEntity(user);

        List<UserRoleAssignmentEntity> userRoleAssignmentEntityList = new ArrayList<>();
        userRoleAssignmentEntityList.add(userRoleAssignmentEntity);


        user.setUsername("noob");
        user.setPassword("Tonging244");
        user.setRoles(userRoleAssignmentEntityList);
        user.setActivated(Boolean.FALSE);

        JwtRequest noobJwtRequest = JwtRequest.builder()
                .username("noob")
                .password("Tonging244")
                .build();

        Algorithm algorithm = Algorithm.HMAC512(AppConfigService.getSecretKey());
        String token = JWT.create()
                .withIssuer(AppConfigService.getIssuer())
                .withIssuedAt(new Date())
                .withJWTId(UUID.randomUUID().toString())
                .withClaim("username", noobJwtRequest.getUsername())
                .withExpiresAt(new Date(System.currentTimeMillis()))
                .sign(algorithm);
    try{
        jwtUtils.isTokenExpired("Bearer " + token);

    }catch (SecurityException e) {
        assertEquals(ErrorMessage.SESSION_TIMED_OUT, e.getMessage());
    }
    }
    @Test
    void test_shouldThrowException_whenTokenTimeToLiveIsBeforeNow(){
        String authorization = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJ0ZWFtdWFyIiwiZXhwIjoxNjY0OTQzNDc4LCJpYXQiOjE2NjQ5NDM0NzQsImp0aSI6ImY3ODhlY2E0LTM3M2YtNDUyMS1iMGE5LWUxMTlhYzI0ODA0YiIsInVzZXJuYW1lIjoidXNlciJ9.aEuM8x8WQbNS5eoralVJLMkT_XRGf-itYEtN2_c_eM6cMrq0sMq1alO9jLPurzfTG4KkNqvY9_hEJ0D32vEfVA";
        assertEquals("Wed Oct 05 11:17:58 ICT 2022",jwtUtils.getTimeToLiveFromToken(authorization).toString());
    }
}
