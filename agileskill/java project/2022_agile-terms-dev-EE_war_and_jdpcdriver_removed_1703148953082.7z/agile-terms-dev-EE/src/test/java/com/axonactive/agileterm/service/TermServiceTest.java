package com.axonactive.agileterm.service;

import com.axonactive.agileterm.dao.DescriptionDAO;
import com.axonactive.agileterm.dao.TermDAO;
import com.axonactive.agileterm.dao.TermTopicDAO;
import com.axonactive.agileterm.dao.UserDAO;
import com.axonactive.agileterm.entity.*;
import com.axonactive.agileterm.exception.ErrorMessage;
import com.axonactive.agileterm.exception.ResourceNotFoundException;
import com.axonactive.agileterm.exception.SystemException;
import com.axonactive.agileterm.rest.client.model.Description;
import com.axonactive.agileterm.rest.client.model.Term;
import com.axonactive.agileterm.rest.client.model.Topic;
import com.axonactive.agileterm.rest.model.TermDto;
import com.axonactive.agileterm.rest.model.TopicDto;
import com.axonactive.agileterm.service.dto.RowResultDto;
import com.axonactive.agileterm.service.dto.TermImportDto;
import com.axonactive.agileterm.service.mapper.TermMapper;
import com.axonactive.agileterm.service.mapper.TopicMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class})
class TermServiceTest {
    @InjectMocks
    private TermService termService;

    @Mock
    private TermDAO termDAO;

    @Mock
    private TermMapper termMapper;

    @Mock
    private TopicMapper topicMapper;

    @Mock
    private DescriptionService descriptionService;

    @Mock
    private DescriptionDAO descriptionDAO;

    @Mock
    private UserService userService;

    @Mock
    private UserDAO userDAO;

    @Mock
    private TermTopicDAO termTopicDAO;

    @Mock
    private TermTopicService termTopicService;

    List<UserEntity> users = new ArrayList<>();
    List<Topic> topics = new ArrayList<>();
    List<TermEntity> terms = new ArrayList<>();
    List<TopicEntity> topicEntityList = new ArrayList<>();

    @BeforeEach
    void setUp() {
        UserEntity userEntity1 = new UserEntity();
        userEntity1.setUsername("Huy");
        userEntity1.setEmail("admin@axonactive.com.vn");
        userEntity1.setPassword("Aavn123!@#");

        UserEntity userEntity2 = new UserEntity();
        userEntity2.setUsername("Quang");
        userEntity2.setEmail("admn@axonactive.com.vn");
        userEntity2.setPassword("Aavn123!@#");

        users.add(userEntity1);
        users.add(userEntity2);


        Topic agileTopic = Topic.builder()
                .name("agile")
                .build();

        Topic programmingTopic = Topic.builder()
                .name("programing")
                .build();

        topics.add(agileTopic);
        topics.add(programmingTopic);


        TermEntity termDod = TermEntity.builder()
                .id(1)
                .name("Dod")
                .descriptionEntityList(new ArrayList<>())
                .build();

        TermEntity termScrum = TermEntity.builder()
                .id(2)
                .name("Scrum")
                .descriptionEntityList(new ArrayList<>())
                .build();

        terms.add(termDod);
        terms.add(termScrum);

        TopicEntity topicComputer = TopicEntity.builder()
                .id(1)
                .name("computer")
                .color("#000000")
                .build();
        TopicEntity topicScrum = TopicEntity.builder()
                .id(2)
                .name("scrum team")
                .color("#ffffff")
                .build();

        topicEntityList.add(topicComputer);
        topicEntityList.add(topicScrum);

    }


    TermEntity dodTerm = new TermEntity(1, "Dod", new ArrayList<>());

    UserEntity admin = new UserEntity();
    DescriptionEntity dodDescription = new DescriptionEntity(1, "This is Dod description", LocalDate.now(), dodTerm, new UserEntity(), 0);

    @Test
    void testGetListOfValidInputTopicId_shouldReturnAListWithTheFirstValueIs3_whenPutInATermEntityThatHasATopicWithId3() {
        List<Integer> resultTopicList = new ArrayList<>();
        resultTopicList.add(3);

        Term term = new Term();
        term.setName("Agile");
        term.setTopicIdList(resultTopicList);

        TermEntity termAgile = TermEntity.builder()
                .id(3)
                .name("Agile")
                .descriptionEntityList(new ArrayList<>())
                .build();


        TopicEntity topicAgile = TopicEntity.builder()
                .id(3)
                .name("Agile")
                .color("#000000")
                .build();

        TermTopicEntity termTopicEntity = new TermTopicEntity();
        termTopicEntity.setId(1);
        termTopicEntity.setTerm(termAgile);
        termTopicEntity.setTopic(topicAgile);

        List<TopicEntity> topicEntities = new ArrayList<>();
        topicEntities.add(topicAgile);

        List<Integer> topicIdList = new ArrayList<>();
        topicIdList.add(3);

        lenient().when(termTopicDAO.findListOfTopicByTermId(3)).thenReturn(topicEntities);

        List<Integer> actualTermList = termService.getListOfValidInputTopicId(termAgile, term);


        assertEquals(topicIdList, actualTermList);

    }

    @Test

    void testValidateListOfDescription_shouldReturnProperResult_whenGiveDodTermAndProperTermRequestAsVariables() {
        dodTerm.getDescriptionEntityList().add(dodDescription);

        Term newTermRequest = Term.builder()
                .descriptionList(new ArrayList<>())
                .build();
        Description newDescriptionRequest = new Description("This is Dod description", "Mquang102");
        newTermRequest.getDescriptionList().add(newDescriptionRequest);

        Term anotherTermRequest = Term.builder()
                .descriptionList(new ArrayList<>())
                .build();
        Description anotherDescriptionRequest = new Description("This is Another Dod description", "Mquang102");
        anotherTermRequest.getDescriptionList().add(anotherDescriptionRequest);

        try {
            termService.validateListOfDescription(dodTerm, newTermRequest);
        } catch (SystemException e) {
            assertEquals(ErrorMessage.DESCRIPTION_ALREADY_EXISTED, e.getMessage());
        }

        assertEquals(termService.validateListOfDescription(dodTerm, anotherTermRequest).get(0), anotherTermRequest.getDescriptionList().get(0));

    }

    @Test
    void testGetListOfDescriptionInTerm_shouldReturnListOfDescription_whenInputTerm() {
        DescriptionEntity newDodDescription = new DescriptionEntity(2, "Another Dod description", LocalDate.now(), dodTerm, new UserEntity(), 0);
        dodTerm.getDescriptionEntityList().add(dodDescription);
        dodTerm.getDescriptionEntityList().add(newDodDescription);
        assertEquals(2, termService.getListOfDescriptionInTerm(dodTerm).size());
    }

    @Test
        void saveNewDescriptionWithExistedTermByUser_shouldReturnNewDescription_whenInputExistedTermWithTheNewDescription() {


        List<Description> descriptions = new ArrayList<>();
        Description description = Description.builder()
                .userName("Huy")
                .content("aaaaaa")
                .build();
        DescriptionEntity descriptionEntity = DescriptionEntity.builder()
                .content(description.getContent())
                .userEntity(users.get(0))
                .build();
        descriptions.add(description);

        when(termDAO.findTermByTermName("Dod")).thenReturn(terms.get(0));
        when(descriptionService.saveAll(any(List.class))).thenReturn(Arrays.asList(descriptionEntity));

        assertEquals("aaaaaa", termService.saveNewDescriptionWithExistedTermByUser("Dod", descriptions).get(0).getContent());

    }





    @ParameterizedTest
    @ValueSource(strings = {"a", "", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"})
    void testIsTermStringLengthInvalid_shouldReturnTrue_whenInputInvalidString(String testString) {
        assertTrue(termService.isTermStringLengthInvalid(testString));
    }

    @Test
    void getAll_shouldReturnTopicsSize_whenFound() {
        when(termDAO.getAll()).thenReturn(terms);

        assertEquals(terms.size(), termService.getAll().size());
    }

    @Test
    void getDecodedId_shouldThrowInPutValidationException_whenEncodedIdLengthLessThan2() {
        assertThrows(ResourceNotFoundException.class, () -> {
            termService.getDecodedId("a");
        });
    }

    @Test
    void getDecodedId_shouldReturnAnId_whenTheGivenIdIsDecoded() {
        TermEntity termFake = TermEntity.builder()
                .id(4)
                .name("fake")
                .descriptionEntityList(new ArrayList<>())
                .build();

        String encodedId = Base64.getEncoder().encodeToString((termFake.getName() + "_" + termFake.getId()).getBytes());
        assertEquals(termFake.getId(), termService.getDecodedId(encodedId));
    }

    @Test
    void testIsStringEmpty_shouldReturnTrue_whenInputEmptyString() {
        String testString = "";
        assertTrue(termService.isStringEmpty(testString));
    }

    @Test
    void testIsStringEmpty_shouldReturnFalse_whenInputCharacters() {
        String testString = "abc";
        assertFalse(termService.isStringEmpty(testString));
    }

    @Test
    void testIsDescriptionLengthInvalid_shouldReturnFalse_whenInputCharacters() {
        String testString = "abc";
        assertFalse(termService.isDescriptionLengthInvalid(testString));
    }

    @Test
    void testIsDescriptionLengthInvalid_shouldReturnTrue_whenInputOver1000Characters() {
        String testString = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        assertTrue(termService.isDescriptionLengthInvalid(testString));
    }

    @Test
    void testIsTermNotExistedInDatabase_shouldReturnTrue_whenInputNonExistedTerm() {
        assertTrue(termService.isTermNotExistedInDatabase("rum"));
    }

    @Test
    void testIsTermNotExistedInDatabase_shouldReturnFalse_whenInputExistedTerm() {
        Term newTermScrum = Term.builder()
                .name("rum")
                .build();
        TermEntity actualEntity = new TermEntity();
        actualEntity.setName("rum");
        TermEntity expctedEntity = new TermEntity();
        expctedEntity.setName("run");
        expctedEntity.setId(1);

        when(termDAO.save(any(TermEntity.class))).thenReturn(expctedEntity);
        termService.save(newTermScrum);
        assertTrue(termService.isTermNotExistedInDatabase("Scrum"));
    }

    @Test
    void testIsDescriptionExistedInDataBase_shouldReturnTrue_whenInputExistedDescription() {
        when(descriptionService.findDescriptionByTermNameAndDescriptionString(dodTerm.getName(), dodDescription.getContent()))
                .thenReturn(Arrays.asList(dodDescription));

        assertTrue(termService.isDescriptionExistedInDataBase("Dod", "This is Dod description"));
    }

    @Test
    void testIsDescriptionExistedInDataBase_shouldReturnFalse_whenInputNotExistedDescription() {
        when(descriptionService.findDescriptionByTermNameAndDescriptionString(dodTerm.getName(), "This Dod description does not exist"))
                .thenReturn(List.of());

        assertFalse(termService.isDescriptionExistedInDataBase("Dod", "This Dod description does not exist"));
        assertTrue(termService.isDescriptionExistedInDataBase("Dod", ""));
    }


    @Test
    void testHandleTermLengthInvalid_shouldReturn1_whenUse() {
        RowResultDto rowResultDto = new RowResultDto();
        termService.handleTermLengthInvalid(rowResultDto, 1);
        assertEquals(1, rowResultDto.getInvalidRows().getInvalidTermLength().size());
    }

    @Test
    void testHandleNullTermString_shouldReturn1_whenUse() {
        RowResultDto rowResultDto = new RowResultDto();
        termService.handleNullTermString(rowResultDto, 1);
        assertEquals(1, rowResultDto.getInvalidRows().getTermIsNull().size());
    }

    @Test
    void testHandleDescriptionLengthInvalid_shouldReturn1_whenUse() {
        RowResultDto rowResultDto = new RowResultDto();
        termService.handleDescriptionLengthInvalid(rowResultDto, 1);
        assertEquals(1, rowResultDto.getInvalidRows().getInvalidDescriptionLength().size());
    }

    @Test
    void testHandleDuplicatedRow_shouldReturn1_whenUse() {
        RowResultDto rowResultDto = new RowResultDto();
        TermImportDto termImportDto = new TermImportDto();
        termService.handleDuplicatedRow(rowResultDto, termImportDto);
        assertEquals(1, rowResultDto.getInvalidRows().getDuplicatedDescriptionInFile().size());
    }

    @Test
    void testHandleRowExistedInDatabase_shouldReturn1_whenUse() {
        RowResultDto rowResultDto = new RowResultDto();
        TermImportDto termImportDto = new TermImportDto();
        List<TermImportDto> termImportDtoList = new ArrayList<>();
        termService.handleRowExistedInDatabase(rowResultDto, termImportDto, termImportDtoList);
        assertEquals(1, rowResultDto.getInvalidRows().getExistedInTheDatabase().size());
    }

    @Test
    void testIsRowDuplicated_shouldReturnTrue_whenInputExistedTermInDataBase() {
        RowResultDto rowResultDto = new RowResultDto();
        TermImportDto termImportDto = new TermImportDto(1, "dod", "definition of done");
        List<TermImportDto> syntaxValidList = new ArrayList<>();
        rowResultDto.getValidRowExistedTermInDataBase().add(termImportDto);
        termService.isRowDuplicated(rowResultDto, termImportDto, syntaxValidList);
        assertTrue(rowResultDto.getValidRowExistedTermInDataBase().contains(termImportDto));
    }

    @Test
    void testIsRowDuplicated_shouldReturnTrue_whenInputNotExistedTermInDataBase() {
        RowResultDto rowResultDto = new RowResultDto();
        TermImportDto termImportDto = new TermImportDto(1, "dod", "definition of done");
        List<TermImportDto> syntaxValidList = new ArrayList<>();
        rowResultDto.getValidRowNotExistedTermInDataBase().add(termImportDto);
        termService.isRowDuplicated(rowResultDto, termImportDto, syntaxValidList);
        assertTrue(rowResultDto.getValidRowNotExistedTermInDataBase().contains(termImportDto));
    }

    @Test
    void testIsRowDuplicated_shouldReturnTrue_whenDuplicateInSyntaxValidList() {
        RowResultDto rowResultDto = new RowResultDto();
        TermImportDto termImportDto = new TermImportDto(1, "dod", "definition of done");
        List<TermImportDto> syntaxValidList = new ArrayList<>();
        syntaxValidList.add(termImportDto);
        termService.isRowDuplicated(rowResultDto, termImportDto, syntaxValidList);
        assertTrue(syntaxValidList.contains(termImportDto));
    }

    @Test
    void testIsRowDuplicated_shouldReturnFalse_whenNoDuplicateInDataBaseOrSyntaxValidList() {
        RowResultDto rowResultDto = new RowResultDto();
        TermImportDto termImportDto = new TermImportDto();
        List<TermImportDto> syntaxValidList = new ArrayList<>();
        assertFalse(termService.isRowDuplicated(rowResultDto, termImportDto, syntaxValidList));
    }

    @Test
    void testGetStopCountingRow_shouldReturnLastCountedIndexRow_whenInputListOf2TermImport() {
        TermImportDto termImportDto1 = new TermImportDto(1, "DD", "dobadu");
        TermImportDto termImportDto2 = new TermImportDto(5, "TDD", "ToiDiDay");
        List<TermImportDto> rawDataList = new ArrayList<>();
        rawDataList.add(termImportDto1);
        rawDataList.add(termImportDto2);
        assertEquals(5, termService.getStopCountingRow(rawDataList));
    }

    @Test
    void testGetStopCountingRow_shouldReturn1_whenInputEmptyList() {

        List<TermImportDto> rawDataList = new ArrayList<>();

        assertEquals(1, termService.getStopCountingRow(rawDataList));
    }

    @Test
    void testSaveNewDescriptionWithExistedTerm_shouldReturnListWith1NewDescription_whenInputExistedTermWithDifferentDescription() {

        when(userService.findUserEntityByUserName("admin")).thenReturn(admin);
        when(termDAO.findTermByTermName("Dod")).thenReturn(dodTerm);
        when(descriptionService.saveAll(any(List.class))).thenReturn(Arrays.asList(dodDescription));
        assertEquals(1, termService.saveNewDescriptionWithExistedTerm("Dod", Arrays.asList(dodDescription.getContent())).size());

    }

    @Test
    void testSaveNewTermNewDescription_shouldReturnNameOfNewTerm_whenInputNewTermAndNewDescription() {

        when(termDAO.save(any(TermEntity.class))).thenReturn(dodTerm);
        when(userService.findUserEntityByUserName("admin")).thenReturn(admin);
        assertEquals(0, termService.saveNewTermNewDescription("Dod", new ArrayList<>()).getDescriptionEntityList().size());

        assertEquals(0, termService.saveNewTermNewDescription("Dod", new ArrayList<>()).getDescriptionEntityList().size());
    }

    @Test
    void testSaveAllListOfValidRows_shouldReturnListOf1ExistedTermWithNewDescription_whenInputExistedTermWithNewDescription() {
        RowResultDto rowResultDto = new RowResultDto();
        TermImportDto existedTerm = new TermImportDto(1, "Dod", "Definition of done");
        TermImportDto existedTerm2 = new TermImportDto(2, "Dod", "DoubleDz");
        TermImportDto nonExistedTerm = new TermImportDto(3, "rum", "dasd");
        rowResultDto.getValidRowExistedTermInDataBase().add(existedTerm);
        rowResultDto.getValidRowExistedTermInDataBase().add(existedTerm2);
        rowResultDto.getValidRowNotExistedTermInDataBase().add(nonExistedTerm);


        List<DescriptionEntity> existedTermWithNewDescriptionEntityList = new ArrayList<>();
        existedTermWithNewDescriptionEntityList.add(new DescriptionEntity(2, "Definition of done", LocalDate.now(), dodTerm, admin, 0));

        existedTermWithNewDescriptionEntityList.add(new DescriptionEntity(3, "DoubleDz", LocalDate.now(), dodTerm, admin, 0));


        List<DescriptionEntity> newTermWithDescriptionEntityList = new ArrayList<>();

        TermEntity newTerm = new TermEntity();
        newTerm.setName("rum");
        newTermWithDescriptionEntityList.add(new DescriptionEntity(null, "dasd", LocalDate.now(), newTerm, admin, 0));
        newTerm.setDescriptionEntityList(newTermWithDescriptionEntityList);


        when(userService.findUserEntityByUserName("admin"))
                .thenReturn(admin);

        when(termDAO.findTermByTermName("Dod")).thenReturn(dodTerm);

        when(descriptionService.saveAll(any(List.class))).thenReturn(existedTermWithNewDescriptionEntityList);

        when(termDAO.save(any(TermEntity.class))).thenReturn(newTerm);

        Map<String, Integer> returnMapFromSaveAll = termService.saveAllListOfValidRows(rowResultDto);
        assertTrue(returnMapFromSaveAll.containsKey("Dod"));
        assertTrue(returnMapFromSaveAll.containsKey("rum"));
        assertEquals(2, returnMapFromSaveAll.get("Dod"));
        assertEquals(1, returnMapFromSaveAll.get("rum"));
    }

    @Test
    void testSaveNewTermNewDescription_shouldReturnNameOfNewTerm_whenInputNewTermAndDescriptionList() {
        List<DescriptionEntity> descriptionEntityList = new ArrayList<>();
        DescriptionEntity descriptionOne =
                DescriptionEntity.builder()
                        .id(1)
                        .content("abc")
                        .term(dodTerm)
                        .userEntity(admin)
                        .votePoint(0)
                        .build();

        DescriptionEntity descriptionTwo =
                DescriptionEntity.builder()
                        .id(2)
                        .content("abcef")
                        .term(dodTerm)
                        .userEntity(admin)
                        .votePoint(0)
                        .build();
        descriptionEntityList.add(descriptionOne);
        descriptionEntityList.add(descriptionTwo);

        dodTerm.setDescriptionEntityList(descriptionEntityList);
        List<String> descriptions = new ArrayList<>();
        descriptions.add("abc");
        descriptions.add("abcdef");

        when(termDAO.save(any(TermEntity.class))).thenReturn(dodTerm);
        when(userService.findUserEntityByUserName("admin")).thenReturn(admin);

        assertEquals(descriptionEntityList.size(),
                termService.saveNewTermNewDescription("Dod", descriptions)
                        .getDescriptionEntityList().size());
    }

    @Test
    void isTermNotExistedInDatabase_shouldReturnTrue_whenSearchingForDod() {
        when(termDAO.findTermByTermName("Dod")).thenReturn(dodTerm);
        assertFalse(termService.isTermNotExistedInDatabase("Dod"));
    }

    @Test
    void isTermNotExistedDatabase_shouldReturnFalse_whenSearchingForS() {
        when(termDAO.findTermByTermName("s")).thenReturn(null);
        assertTrue(termService.isTermNotExistedInDatabase("s"));
    }

    @Test
    void testSave_sizeShouldIncrease_whenSaveNewRequest() {
        TermEntity topicToBeSaved = TermEntity.builder()
                .name("Clean Code")
                .descriptionEntityList(new ArrayList<>())
                .build();

        Term termRequest = Term.builder()
                .name("Clean Code")
                .relatedTermIdList(new ArrayList<>())
                .descriptionList(new ArrayList<>())
                .topicIdList(new ArrayList<>())
                .build();

        lenient().when(termDAO.save(any(TermEntity.class))).thenReturn(topicToBeSaved);

        TermEntity expectedTopic = termService.save(termRequest);
        assertEquals(expectedTopic.getName(), topicToBeSaved.getName());
    }

    @Test
    void testUpdate_shouldUpdateOldTermAndReturnNewTerm_whenGiveEncodeIdAndTerm() {
        Term termRequest = Term.builder()
                .name("Daily Scrum")
                .relatedTermIdList(new ArrayList<>())
                .descriptionList(new ArrayList<>())
                .topicIdList(new ArrayList<>())
                .build();

        TermEntity termNeedToBeUpdated = TermEntity.builder()
                .name("Daily Scrum")
                .descriptionEntityList(new ArrayList<>())
                .build();

        String encodedId = java.util.Base64.getEncoder().encodeToString((terms.get(0).getName() + "_" + terms.get(0).getId()).getBytes());

        when(termDAO.findTermById(1)).thenReturn(terms.get(0));
        when(termDAO.save(any(TermEntity.class))).thenReturn(termNeedToBeUpdated);

        TermEntity expectedTermAfterUpdate = termService.update(encodedId, termRequest);
        assertEquals("Daily Scrum", expectedTermAfterUpdate.getName());
    }

    @Test
    void testFindTermDetailById_shouldReturnATerm_whenEnterEncodeId() {

        TopicDto topicComputerDto = new TopicDto(1, "computer", "#000000");
        TopicDto topicScrumDto = new TopicDto(2, "scrum team", "#ffffff");

        List<TopicDto> topicDtoList = new ArrayList<>();
        topicDtoList.add(topicComputerDto);
        topicDtoList.add(topicScrumDto);

        TermEntity termDod = TermEntity.builder()
                .id(1)
                .name("Dod")
                .descriptionEntityList(new ArrayList<>())
                .build();

        String encodedId = java.util.Base64.getEncoder().encodeToString((terms.get(0).getName() + "_" + terms.get(0).getId()).getBytes());

        TermDto termDto = new TermDto(encodedId, "Dod", new ArrayList<>(), new ArrayList<>());


        when(termTopicService.findListOfTopicEntityFromTermId(1)).thenReturn(topicEntityList);
        when(topicMapper.toDtos(topicEntityList)).thenReturn(topicDtoList);

        when(termDAO.findTermById(1)).thenReturn(termDod);
        when(termMapper.toDto(termDod)).thenReturn(termDto);


        TermDto expectedTerm = termService.findTermDetailById(encodedId);
        assertEquals("Dod", expectedTerm.getName());
    }


    @Test
    void testFindTermByTermId_shouldThrowResourceNotFoundException_whenTermIdIsNull() {
        when(termDAO.findTermById(null)).thenReturn(null);
        assertThrows(ResourceNotFoundException.class, () -> {
            termService.findTermByTermId(null);
        });
    }

    @Test
    void testFindTermByTermId_shouldReturnTermEntity_whenFound() {
        when(termDAO.findTermById(1)).thenReturn(dodTerm);
        assertEquals(dodTerm, termService.findTermByTermId(1));
    }

    @Test
    void testFindTop10TermsByTermNameContain_shouldReturnAListOfTermDto_whenInputAString() {
        //Arrange
        TermDto termDto = new TermDto(Base64.getEncoder().encodeToString(("Acceptance Criteria" + "_" + 1).getBytes()), "Acceptance Criteria", null, null);
        List<TermDto> termDtoArrayList = new ArrayList<>();
        termDtoArrayList.add(termDto);
        TermEntity termEntity = new TermEntity(1, "Acceptance Criteria", null);
        List<TermEntity> termEntityArrayList = new ArrayList<>();
        termEntityArrayList.add(termEntity);
        when(termDAO.findTop10TermsByTermNameContain("a")).thenReturn(termEntityArrayList);

        when(termMapper.toDtos(termEntityArrayList)).thenReturn(termDtoArrayList);

        //Action
        List<TermDto> expectedTermDtoArrayList = termService.findTop10TermsByTermNameContain("a");

        //Assert
        assertEquals(expectedTermDtoArrayList, termDtoArrayList);

    }

    @Test
    void testFind10RecentTerm_shouldReturnScrum_whenTermEntityOfScrumHasIdOf2() {
        TermEntity dod = new TermEntity();
        dod.setId(1);
        dod.setName("dod");

        TermEntity scrum = new TermEntity();
        scrum.setId(2);
        scrum.setName("Scrum");

        List<TermEntity> termEntityList = new ArrayList<>();
        termEntityList.add(scrum);
        termEntityList.add(dod);

        TermDto dodDto = new TermDto();
        dodDto.setName("dod");

        TermDto scrumDto = new TermDto();
        scrumDto.setName("Scrum");

        List<TermDto> termDtos = new ArrayList<>();
        termDtos.add(scrumDto);
        termDtos.add(dodDto);

        when(termDAO.findRecentTerm()).thenReturn(termEntityList);
        when(termMapper.toDtos(termEntityList)).thenReturn(termDtos);


        assertEquals(termEntityList.get(0).getName(), termService.find10RecentTerm().get(0).getName());
    }

    @Nested
    @DisplayName("Test get row result from raw data list")
    class testGetRowResult {
        @InjectMocks
        private TermService termService;

        @Mock
        private TermDAO termDAO;

        @Mock
        private DescriptionService descriptionService;

        RowResultDto rowResultDto = new RowResultDto();
        List<TermImportDto> syntaxValidImportTermList = new ArrayList<>();
        List<TermImportDto> importList = new ArrayList<>();

        TermImportDto termImportValid1 = new TermImportDto(2, "dod", "dod valid 1");
        TermImportDto termImportValid2 = new TermImportDto(3, "dod", "dod valid 2");

        TermImportDto termImportIsBlank = new TermImportDto(4, "   ", "This term is blank");
        TermImportDto termImportIsMoreThan50 = new TermImportDto(5, "abcde12345abcde12345abcde12345abcde12345abcde123456", "This term length is more than 50");
        TermImportDto termWithDescriptionInvalid = new TermImportDto(6, "Description is more than 1000", "      12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde  12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde   12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde  12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde    12345abcde 12345a    12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde  12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde   12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde  12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde    12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde  12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde   12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde  12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde 12345abcde ");

        TermImportDto termDuplicatedWithtermImportValid1 = new TermImportDto(7, "dod", "dod valid 1");

        TermImportDto termNotExistedInDatabase = new TermImportDto(8, "This term not existed in database", "hello world");


        TermEntity termDod = TermEntity.builder()
                .id(1)
                .name("dod")
                .descriptionEntityList(new ArrayList<>())
                .build();

        @Test
        void getRowResultFromRawDataList_shouldHandleNullTermString_whenTermIsNull() {
            importList.add(termImportIsBlank);
            rowResultDto = termService.getRowResultFromRawDataList(importList);
            assertEquals(termImportIsBlank.getRowIndex(),
                    rowResultDto.getInvalidRows().getTermIsNull().get(0));
        }

        @Test
        void getRowResultFromRawDataList_shouldHandleTermLengthInvalid_whenTermLengthInvalid() {
            importList.add(termImportIsMoreThan50);
            rowResultDto = termService.getRowResultFromRawDataList(importList);
            assertEquals(termImportIsMoreThan50.getRowIndex(),
                    rowResultDto.getInvalidRows().getInvalidTermLength().get(0));
        }

        @Test
        void getRowResultFromRawDataList_shouldHandleDescriptionLengthInvalid_whenImportDescriptionIsTooLong() {
            importList.add(termWithDescriptionInvalid);
            rowResultDto = termService.getRowResultFromRawDataList(importList);

            assertEquals(termWithDescriptionInvalid.getRowIndex(),
                    rowResultDto.getInvalidRows().getInvalidDescriptionLength().get(0));
        }

        @Test
        void getRowResultFromRawDataList_shouldHandleRowDuplicated_whenImportDuplicatedRows() {
            importList.add(termImportValid1);
            importList.add(termDuplicatedWithtermImportValid1);

            rowResultDto = termService.getRowResultFromRawDataList(importList);

            assertEquals(termDuplicatedWithtermImportValid1.getRowIndex(),
                    rowResultDto.getInvalidRows().getDuplicatedDescriptionInFile().get(0));
        }

        @Test
        void getRowResultFromRawDataList_shouldHandleRowExistedInDatabase_whenImportRowExistedInDatabase() {
            DescriptionEntity existedDescriptionOne =
                    DescriptionEntity.builder()
                            .id(1)
                            .content("dod valid 1")
                            .term(termDod)
                            .userEntity(admin)
                            .votePoint(0)
                            .build();
            List<DescriptionEntity> existedDescriptionList = new ArrayList<>();
            existedDescriptionList.add(existedDescriptionOne);
            importList.add(termImportValid1);

            when(termDAO.findTermByTermName("dod")).thenReturn(termDod);
            when(descriptionService.findDescriptionByTermNameAndDescriptionString("dod", "dod valid 1")).thenReturn(Arrays.asList(existedDescriptionOne));

            rowResultDto = termService.getRowResultFromRawDataList(importList);
            assertEquals(termImportValid1.getRowIndex(),
                    rowResultDto.getInvalidRows().getExistedInTheDatabase().get(0));
        }

        @Test
        void testGetValidRowExistedTermInDataBase_shouldAddNewTermAndDescription_whenImportNewTermAndDescription() {
            when(termDAO.findTermByTermName("dod")).thenReturn(termDod);
            importList.add(termImportValid1);
            importList.add(termImportValid2);
            importList.add(termNotExistedInDatabase);

            RowResultDto rowResultDto = termService.getRowResultFromRawDataList(importList);

            assertEquals(2, rowResultDto.getValidRowExistedTermInDataBase().size());
        }

        @Test
        void testFindTermByTermName_shouldReturnATerm_whenInputTermName() {
            when(termDAO.findTermByTermName("dod")).thenReturn(termDod);
            assertEquals(termDod.getName(), termService.findTermByTermName("dod").getName());
        }




    }

    @Test
    void getMostUpvoteDescriptionOfATerm_shouldReturnListOf1PopularTerm_whenInput(){
        List<TermEntity> dataList = Arrays.asList(dodTerm);
        List<TermEntity> returnList = new ArrayList<>();
        termService.getMostUpvoteDescriptionOfATerm(returnList,dataList);
        assertEquals(1,returnList.size());
    }

    @Test
    void getTop10PopularTerms_shouldReturnListOf2PopularTerm_whenRun(){
        TermEntity dod = new TermEntity();
        dod.setId(1);
        dod.setName("dod");
        dod.setDescriptionEntityList(new ArrayList<>());

        TermEntity scrum = new TermEntity();
        scrum.setId(2);
        scrum.setName("Scrum");
        scrum.setDescriptionEntityList(new ArrayList<>());


        List<TermEntity> termEntityList = new ArrayList<>();
        termEntityList.add(scrum);
        termEntityList.add(dod);

        TermDto dodDto = new TermDto();
        dodDto.setName("dod");
        dodDto.setEncodedId(Base64.getEncoder().encodeToString(("dod_1").getBytes()));
        dodDto.setDescriptionList(List.of());

        TermDto scrumDto = new TermDto();
        scrumDto.setName("Scrum");
        scrumDto.setEncodedId(Base64.getEncoder().encodeToString(("Scrum_2").getBytes()));
        scrumDto.setDescriptionList(List.of());

        List<TermDto> termDtos = new ArrayList<>();
        termDtos.add(scrumDto);
        termDtos.add(dodDto);


        when(termDAO.findTop10PopularTerms()).thenReturn(termEntityList);


        when(termMapper.toDtos(anyList())).thenReturn(termDtos);

        System.out.println();
        System.out.println(termService.getTop10PopularTerms());

        assertEquals(2,termService.getTop10PopularTerms().size());
    }
}



