package com.axonactive.agileterm.service;

import com.axonactive.agileterm.dao.UserDAO;
import com.axonactive.agileterm.dao.VerificationTokenDAO;
import com.axonactive.agileterm.entity.Role;
import com.axonactive.agileterm.entity.UserEntity;
import com.axonactive.agileterm.entity.UserRoleAssignmentEntity;
import com.axonactive.agileterm.entity.VerificationTokenEntity;
import com.axonactive.agileterm.exception.ErrorMessage;
import com.axonactive.agileterm.exception.ResourceNotFoundException;
import com.axonactive.agileterm.exception.SecurityException;
import com.axonactive.agileterm.rest.client.model.User;
import com.axonactive.agileterm.rest.model.UserDto;
import com.axonactive.agileterm.service.mapper.UserMapper;
import net.bytebuddy.utility.RandomString;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mindrot.jbcrypt.BCrypt;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @InjectMocks
    private UserService userService;
    @Mock
    private UserDAO userDAO;

    @Mock
    private UserMapper userMapper;
    @Mock
    private VerificationTokenDAO verificationTokenDAO;

    List<UserRoleAssignmentEntity> roleAssignments = new ArrayList<>();
    UserRoleAssignmentEntity role1 = new UserRoleAssignmentEntity();
    List<UserEntity> users = new ArrayList<>();

    UserEntity user1 = UserEntity.builder()
            .username("nhthinh")
            .password("12345")
            .email("nhthinh@gmail.com")
            .roles(null)
            .verificationTokenEntity(new VerificationTokenEntity())
            .build();

    UserEntity user2 = UserEntity.builder()
            .username("mquang")
            .password("12345")
            .email("quang@gmail.com")
            .roles(null)
            .verificationTokenEntity(new VerificationTokenEntity())
            .build();

    UserEntity user3 = UserEntity.builder()
            .username("nntanh")
            .password("12345")
            .email("ahihidongok@gmail.com")
            .roles(null)
            .activated(true)
            .verificationTokenEntity(new VerificationTokenEntity())
            .build();

    @BeforeEach
    void setUp() {
        users.add(user1);
        users.add(user2);
        users.add(user3);
    }

    @Test
    void testGetAll_shouldReturnData_WhenUsed() {
        when(userDAO.getAll()).thenReturn(users);

        List<UserEntity> actualUsers = userService.getAll();

        assertEquals(users.size(), actualUsers.size());
    }

    @Test
    void testFindUserEntityByUserName_shouldReturnOneUser_whenFound() {
        when(userDAO.findUserByUserName("mquang")).thenReturn(user2);
        UserEntity expectedUsername = userService.findUserEntityByUserName("mquang");
        assertEquals(expectedUsername.getUsername(), user2.getUsername());
    }

    @Test
    void testFindUserEntityByUserName_shouldThrowException_whenNotFound() {
        when(userDAO.findUserByUserName("nonexistinguser")).thenReturn(null);

        assertThrows(ResourceNotFoundException.class , ()->{
            userService.findUserEntityByUserName("nonexistinguser");
        });
    }


    @Test
    void testCountUserWithUsername_shouldReturnProperNumber_whenFound_andNotFound() {
        when(userDAO.countUsersWithUsername("mquang")).thenReturn(1L);
        assertEquals(1, userService.countUserWithUsername("mquang"));
        assertEquals(0, userService.countUserWithUsername("notExistingUsername"));
    }

    @Test
    void testCountUserWithEmail_shouldReturnProperNumber_whenFound_andNotFound() {
        when(userDAO.countUsersWithEmail("quang@gmail.com")).thenReturn(1L);
        assertEquals(1, userService.countUserWithEmail("quang@gmail.com"));
        assertEquals(0, userService.countUserWithEmail("notExisting@mail.com"));
    }


    @Test
    void testIsExistingEmail_shouldReturnProperBoolean_whenFound_andNotFound() {
        when(userDAO.countUsersWithEmail("quang@gmail.com")).thenReturn(1L);
        assertTrue(userService.isExistingEmail("quang@gmail.com"));
        assertFalse(userService.isExistingEmail("notExisting@gmail.com"));
    }


    @Test
    void testIsExistingUsername_shouldReturnProperBoolean_whenFound_andNotFound() {
        when(userDAO.countUsersWithUsername("mquang")).thenReturn(1L);
        assertTrue(userService.isExistingUsername("mquang"));
        assertFalse(userService.isExistingUsername("notExistingUsername"));
    }

    @Test
    void testPasswordMatchesValid_shouldReturnTrue_whenMatched() {
        String password = "aavn123";
        String matchingPassword = "aavn123";
        assertTrue(userService.passwordMatchesValid(password, matchingPassword));
    }

    @Test
    void testValidateUserName_shouldThrowSecurityException_whenExistingUsername() {
        when(userDAO.countUsersWithUsername("notexisting"))
                .thenReturn(1L);
        try{
            userService.validateUserName("notExisting");
        } catch (SecurityException e){
            assertEquals( ErrorMessage.USERNAME_EXISTED, e.getMessage());
        }
    }

    @Test
    void testValidateEmail_shouldThrowSecurityException_whenExistingEmail() {
        when(userDAO.countUsersWithEmail("quang@gmail.com")).thenReturn(1L);
        assertThrows(SecurityException.class, () -> {
            userService.validateEmail("quang@gmail.com");
        });
    }
    @Test
    void testSaveMethod_ShouldThrowException_whenInputEmailExisted(){
        when(userDAO.countUsersWithEmail("admin@axonactive.com")).thenReturn(1L);


        User existedEmailRequest = new User();
        existedEmailRequest.setEmail("admin@axonactive.com");


        //assert
        try{
            userService.save(existedEmailRequest);
        } catch (SecurityException e){
            assertEquals( ErrorMessage.EMAIL_EXISTED, e.getMessage());
        }

    }

    @Test
    void testSaveMethod_ShouldThrowException_whenInputUsernameExisted(){
        when(userDAO.countUsersWithEmail("newemail@axonactive.com")).thenReturn(0L);
        when(userDAO.countUsersWithUsername("user")).thenReturn(1L);

        User existedUserNameRequest = new User();
        existedUserNameRequest.setEmail("newEmail@axonactive.com");
        existedUserNameRequest.setUserName("user");

        //assert
        try{
            userService.save(existedUserNameRequest);
        } catch (SecurityException e){
            assertEquals( ErrorMessage.USERNAME_EXISTED,e.getMessage());
        }
    }

    @Test
    void testSaveMethod_ShouldThrowException_whenEmailIsInvalid(){
        when(userDAO.countUsersWithEmail("newemail@com")).thenReturn(0L);
        when(userDAO.countUsersWithUsername("newuser")).thenReturn(0L);

        User invalidUsernameRequest = new User();
        invalidUsernameRequest.setEmail("newEmail@com");
        invalidUsernameRequest.setUserName("newUser");

        //assert
        try{
            userService.save(invalidUsernameRequest);
        } catch (SecurityException e){
            assertEquals( ErrorMessage.EMAIL_INVALID,e.getMessage());
        }
    }

    @Test
    void testSave_shouldThrowException_whenPasswordIsInvalid(){
        when(userDAO.countUsersWithEmail("newemail@axonactive.com")).thenReturn(0L);
        when(userDAO.countUsersWithUsername("newuser")).thenReturn(0L);

        User invalidPasswordRequest = new User();
        invalidPasswordRequest.setEmail("newemail@axonactive.com");
        invalidPasswordRequest.setUserName("newUser");
        invalidPasswordRequest.setPassword("123");

        //assert
        try{
            userService.save(invalidPasswordRequest);
        } catch (SecurityException e){
            assertEquals( ErrorMessage.PASSWORD_INVALID,e.getMessage());
        }
    }

    @Test
    void testSave_shouldThrowException_whenConfirmPasswordNotMatch(){
        when(userDAO.countUsersWithEmail("newemail@axonactive.com")).thenReturn(0L);
        when(userDAO.countUsersWithUsername("newuser")).thenReturn(0L);

        User invalidPasswordMatchesRequest = new User();
        invalidPasswordMatchesRequest.setEmail("newemail@axonactive.com");
        invalidPasswordMatchesRequest.setUserName("newUser");
        invalidPasswordMatchesRequest.setPassword("Aavn123!@#");
        invalidPasswordMatchesRequest.setMatchingPassword("Aavn123!#");

        //assert
        try{
            userService.save(invalidPasswordMatchesRequest);
        } catch (SecurityException e){
            assertEquals( ErrorMessage.CONFIRM_PASSWORD_NOT_MATCH,e.getMessage());
        }
    }

    @Test
    void testSave_saveNewUser_whenUserRequestValid(){
        //Arrange
        VerificationTokenEntity expectedVerificationToken = new VerificationTokenEntity();

        User validUserRequest = new User();
        validUserRequest.setEmail("newemail@axonactive.com");
        validUserRequest.setUserName("newUser");
        validUserRequest.setPassword("Aavn123!@#");
        validUserRequest.setMatchingPassword("Aavn123!@#");

        UserDto sampleUserDto = new UserDto(1,"newUser","newemail@axonactive.com",false);

        UserEntity validUserEntity = new UserEntity();
        validUserEntity.setId(10);
        validUserEntity.setUsername("newUser");
        validUserEntity.setEmail("newemail@axonactive.com");
        String hashedPassword = BCrypt.hashpw("Aavn123!@#", BCrypt.gensalt(12));
        List<UserRoleAssignmentEntity> userRoleAssignmentEntityList = new ArrayList<>();
        userRoleAssignmentEntityList.add(new UserRoleAssignmentEntity(null, Role.ROLE_USER, validUserEntity));
        validUserEntity.setPassword(hashedPassword);
        validUserEntity.setRoles(userRoleAssignmentEntityList);
        validUserEntity.setVerificationTokenEntity(expectedVerificationToken);

        when(userDAO.save(any(UserEntity.class))).thenReturn(validUserEntity);
        when(userMapper.toDto(validUserEntity)).thenReturn(sampleUserDto);
        when(userDAO.countUsersWithEmail("newemail@axonactive.com")).thenReturn(0L);
        when(userDAO.countUsersWithUsername("newuser")).thenReturn(0L);
        when(verificationTokenDAO.save(any(VerificationTokenEntity.class))).thenReturn(expectedVerificationToken);

        //Action
        UserDto expectedUserDto = userService.save(validUserRequest);

        //Assert
        assertEquals(expectedUserDto,sampleUserDto);
    }

    @Test
    void testVerifyUser_shouldSetUserActivatedTrue_whenSendActivationCode(){
        UserDto sampleUserDto = new UserDto(2,"mquang","quang@gmail.com",true);
        when(userDAO.findUserEntityByVerificationCode(user2.getVerificationTokenEntity().getVerificationCode())).thenReturn(user2);
        when(userMapper.toDto(user2)).thenReturn(sampleUserDto);
        UserDto expectedUserDto = userService.verifyUser(user2.getVerificationTokenEntity().getVerificationCode());

        assertEquals(expectedUserDto.getActivated(),sampleUserDto.getActivated());
    }

    @Test
    void testVerifyUser_shouldThrowUserNotFoundException_WhenSendActiveCode(){

        String fakeCode = RandomString.make(64);
        when(userDAO.findUserEntityByVerificationCode(fakeCode)).thenReturn(null);
        assertThrows(SecurityException.class,() -> {
            userService.verifyUser(fakeCode);
        });
    }

    @Test
    void testVerifyUser_shouldThrowSecurityException_whenSendActiveCodeThatAlreadyActivated(){
        String verifyCodeOfUser3 = user3.getVerificationTokenEntity().getVerificationCode();

        when(userDAO.findUserEntityByVerificationCode(verifyCodeOfUser3)).thenReturn(user3);

        assertThrows(SecurityException.class,() -> {
            userService.verifyUser(verifyCodeOfUser3);
        });

    }

    @Test
    void testValidateUser_shouldReturnCorrectUser_whenSearchThatUserName() {
        when(userDAO.findUserByUserName("mquang")).thenReturn(user2);
        UserEntity expectedUsername = userService.validateUser("mquang");
        assertEquals(expectedUsername.getUsername(), user2.getUsername());
    }

    @Test
    void testValidateUser_shouldThrowException_whenNotFound() {
        when(userDAO.findUserByUserName("nonexistinguser")).thenReturn(null);

        assertThrows(SecurityException.class , ()->{
            userService.validateUser("nonexistinguser");
        });
    }


}
