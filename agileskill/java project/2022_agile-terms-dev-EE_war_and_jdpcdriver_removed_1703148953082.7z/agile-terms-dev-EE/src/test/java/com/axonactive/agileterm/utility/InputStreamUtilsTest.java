package com.axonactive.agileterm.utility;

import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.axonactive.agileterm.utility.InputStreamUtils.getInputStream;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
 class InputStreamUtilsTest {
    @InjectMocks
    private com.axonactive.agileterm.utility.InputStreamUtils inputStreamUtils;


    @Test
     void testGetInputPart_shouldReturnOneInputPart_whenReceivedValidMultipartFromDataInput() {
        MultipartFormDataInput multipartFormDataInput = mock(MultipartFormDataInput.class);
        InputPart inputPart1 = mock(InputPart.class);
        InputPart inputPart2 = mock(InputPart.class);
        List<InputPart> inputParts = new ArrayList<>();
        inputParts.add(inputPart1);
        inputParts.add(inputPart2);
        Map<String, List<InputPart>> formDataMap = mock(HashMap.class);

        when(multipartFormDataInput.getFormDataMap()).thenReturn(formDataMap);
        when(formDataMap.get("file")).thenReturn(inputParts);

        InputPart inputPartExpected = inputStreamUtils.getInputPart(multipartFormDataInput);

        assertEquals(inputPartExpected, inputPart1);
    }

    @Test
     void testGetInputStrseam_shouldReturnInputStream_whenReceivedValidInputPart() {
        InputPart inputPart = mock(InputPart.class);
        MultivaluedMap<String, String> header = new MultivaluedHashMap<>();
        header.add("Content-Disposition", "filename=docker.doc;ji");
        String finalFileName = "docker.doc";

        when(inputPart.getHeaders()).thenReturn(header);

        String expectedFinalName = inputStreamUtils.getFileName(inputPart);
        assertEquals(expectedFinalName, finalFileName);

    }

    @Test
     void testGetInputStream_shouldReturnInputStream_whenReceivedValidInputPart() throws IOException {
        InputPart inputPart = mock(InputPart.class);
        InputStream inputStream = mock(InputStream.class);

        when(inputPart.getBody(InputStream.class, null)).thenReturn(inputStream);

        InputStream inputStreamExpected = getInputStream(inputPart);
        assertEquals(inputStreamExpected, inputStream);
    }
}
