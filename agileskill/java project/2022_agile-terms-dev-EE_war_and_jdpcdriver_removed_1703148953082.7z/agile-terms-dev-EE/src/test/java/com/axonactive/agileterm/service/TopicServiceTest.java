package com.axonactive.agileterm.service;

import com.axonactive.agileterm.dao.TermDAO;
import com.axonactive.agileterm.dao.TermTopicDAO;
import com.axonactive.agileterm.dao.TopicDAO;
import com.axonactive.agileterm.entity.TermEntity;
import com.axonactive.agileterm.entity.TermTopicEntity;
import com.axonactive.agileterm.entity.TopicEntity;
import com.axonactive.agileterm.exception.ErrorMessage;
import com.axonactive.agileterm.exception.ResourceNotFoundException;
import com.axonactive.agileterm.rest.client.model.Topic;
import com.axonactive.agileterm.service.mapper.TopicMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class})
class TopicServiceTest {
    @InjectMocks
    private TopicService topicService;

    @Mock
    private TopicDAO topicDAO;

    @Mock
    private TopicMapper topicMapper;

    @Mock
    private TermTopicDAO termTopicDAO;

    @Mock
    private TermDAO termDAO;

    List<TopicEntity> topics = new ArrayList<>();

    TopicEntity topic1 = new TopicEntity(1, "Agile", "#000000");
    TopicEntity topic2 = new TopicEntity(2, "Scrum", "#ffffff");


    @BeforeEach
    void setUp() {
        topics.add(topic1);
        topics.add(topic2);
    }

    @Test
    void testGetAll_shouldReturnData_whenUsed() {
        when(topicDAO.findAll()).thenReturn(topics);

        List<TopicEntity> actualTopics = topicService.getAll();

        assertEquals(topics.size(), actualTopics.size());
    }

    @Test
    void testFindById_shouldReturn1_whenInput1() {
        when(topicDAO.findById(1)).thenReturn(topic1);

        TopicEntity actualTopic = topicService.findTopicById(1);

        assertEquals(actualTopic.getName(), topic1.getName());
        assertEquals(actualTopic.getColor(), topic1.getColor());
    }

    @Test
    void testFindById_shouldThrowResourceNotFoundException_whenInput3() {
        when(topicDAO.findById(100)).thenThrow(new ResourceNotFoundException(ErrorMessage.TOPIC_NOT_FOUND));

        assertThrows(ResourceNotFoundException.class, () -> {
            topicService.findTopicById(100);
        });
    }

    @Test
    void testSave_sizeShouldIncrease_whenSaveNewRequest() {
        TopicEntity topic3ToBeReturn = new TopicEntity(3, "Clean", "#112233");
        Topic topicRequest3 = new Topic("Clean", "#112233");
        when(topicDAO.save(any(TopicEntity.class))).thenReturn(topic3ToBeReturn);

        TopicEntity expectedTopic = topicService.save(topicRequest3);

        assertEquals(expectedTopic.getName(), topic3ToBeReturn.getName());

    }

    @Test
    void testGetPopularTopic_shouldReturnTopPopularTopics_whenUsed() {
        TopicEntity topic1 = new TopicEntity(1, "programming", "#b4d6d3");
        TopicEntity topic2 = new TopicEntity(2, "Scrum", "#aa78a6");
        TopicEntity topic3 = new TopicEntity(3, "process", "#D7FDF0");
        TopicEntity topic4 = new TopicEntity(4, "artifact", "#B49FCC");
        TopicEntity topic5 = new TopicEntity(5, "event", "#b2ffd6");
        TopicEntity topic6 = new TopicEntity(6, "value", "#00ff00");
        TopicEntity topic7 = new TopicEntity(7, "principle", "#F2F5DE");
        TopicEntity topic8 = new TopicEntity(8, "role", "#ED6A5A");
        TopicEntity topic9 = new TopicEntity(9, "rule", "#F4F1BB");
        TopicEntity topic10 = new TopicEntity(10, "methods", "#E6EBE0");
        List<TopicEntity> actual = Arrays.asList(topic1,topic2,topic3,topic4,topic5,topic6,topic7,topic8,topic9,topic10);
        when(topicDAO.findPopularTopics()).thenReturn(actual);
        List<TopicEntity> expected = topicService.getPopularTopic();
        assertEquals(10,expected.size());
    }

}
