package com.axonactive.agileterm.service;

import com.axonactive.agileterm.entity.UserEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mindrot.jbcrypt.BCrypt;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.lenient;

@ExtendWith({MockitoExtension.class})
class AuthenticationServiceTest {

    @InjectMocks
    AuthenticationService authenticationService;
    @Mock
    UserService userService;

    @Test
    void checkAuthentication() {

        String username = "user";
        String password = "1234";

        String encryptedPassword = BCrypt.hashpw(password, BCrypt.gensalt(12));

        UserEntity user = new UserEntity();
        user.setUsername(username);
        user.setPassword(encryptedPassword);


        lenient().when(userService.validateUser(username)).thenReturn(user);


        assertTrue(authenticationService.checkAuthentication(username, password));
    }
}