package com.axonactive.agileterm.service;

import com.axonactive.agileterm.dao.DescriptionDAO;
import com.axonactive.agileterm.dao.TermDAO;
import com.axonactive.agileterm.dao.UserDAO;
import com.axonactive.agileterm.entity.DescriptionEntity;
import com.axonactive.agileterm.entity.TermEntity;
import com.axonactive.agileterm.entity.UserEntity;
import com.axonactive.agileterm.rest.client.model.Description;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith({MockitoExtension.class})
class DescriptionServiceTest {
    @Mock
    private DescriptionDAO descriptionDAO;
    @Mock
    private TermDAO termDAO;
    @Mock
    private UserDAO userDAO;
    @Mock
    private UserService userService;

    @InjectMocks
    private  DescriptionService descriptionService;

    @Test
    void testisDescriptionListValid_shouldReturnFalse_whenInputNullOrEmptyList(){
        //Arrange
        List<Description> emptyDescriptionList = new ArrayList<>();
        //Action
        Boolean expectedNullListResult = descriptionService.isDescriptionListValid(null);
        Boolean expectedEmptyListResult = descriptionService.isDescriptionListValid(emptyDescriptionList);
        //Assert
        assertFalse(expectedNullListResult);
        assertFalse(expectedEmptyListResult);
    }

    @Test
    void testFindDescriptionByTermNameAndDescriptionString_shouldReturnAListOfDescription_whenInputTermAndDescriptionString(){
        //Arrange
        List<DescriptionEntity> descriptionEntityList = new ArrayList<>();
        DescriptionEntity descriptionEntity = mock(DescriptionEntity.class);
        descriptionEntityList.add(descriptionEntity);
        when(descriptionDAO.findDescriptionByTermNameAndDescriptionString("dod","definition of done")).thenReturn(descriptionEntityList);

        //Action
        List<DescriptionEntity> expectedDescriptionList = descriptionService.findDescriptionByTermNameAndDescriptionString("dod","definition of done" );

        //Assert
        assertEquals(expectedDescriptionList,descriptionEntityList);
    }

    @Test
    void testSaveAll_shouldReturnAListOfEntity_whenInputDescriptionEntityList(){
        List<DescriptionEntity> descriptionEntityList = new ArrayList<>();
        DescriptionEntity descriptionEntity = mock(DescriptionEntity.class);
        descriptionEntityList.add(descriptionEntity);
        when(descriptionDAO.save(any(DescriptionEntity.class))).thenReturn(descriptionEntity);

        List<DescriptionEntity> expectedDescriptionEntityList = descriptionService.saveAll(descriptionEntityList);
        assertEquals(expectedDescriptionEntityList,descriptionEntityList);
    }

    @Test
    void testConvertDescriptionToDescriptionEntity_shouldReturnDescriptionEntity_whenInputDescription(){
        //Arrange
        UserEntity mockAdminUser = new UserEntity(1,"admin","a@axon.com",null,true,null,null);
        when(userService.findUserEntityByUserName("admin")).thenReturn(mockAdminUser);

        Description inputRequest = new Description("definition of done","admin");
        TermEntity dod = TermEntity.builder().id(1).name("dod").build();
        DescriptionEntity convertedDescriptionEntity = new DescriptionEntity(null,"definition of done",null,null,mockAdminUser,null);

        //Action
        DescriptionEntity expectedDescriptionEntity = descriptionService.convertDescriptionToDescriptionEntity(inputRequest,dod);

        //Assert
        assertEquals(expectedDescriptionEntity.getContent(),convertedDescriptionEntity.getContent());
        assertEquals(expectedDescriptionEntity.getUserEntity().getUsername(),mockAdminUser.getUsername());
    }

    @Test
    void testConvertListOfDescriptionToListOfDescriptionEntity_shouldReturnListOfDescriptionEntity_whenInputListOfDescription(){
        //Arrange
        UserEntity fakeAdmin = new UserEntity(1,"admin","a@axon.com",null,true,null,null);
        when(userService.findUserEntityByUserName("admin")).thenReturn(fakeAdmin);

        Description inputRequest1 = new Description("definition of done","admin");
        Description inputRequest2 = new Description("check list before set status of done","admin");
        DescriptionEntity convertedDescriptionEntity1 = new DescriptionEntity(null,"definition of done",null,null,fakeAdmin,null);
        DescriptionEntity convertedDescriptionEntity2 = new DescriptionEntity(null,"check list before set status of done",null,null,fakeAdmin,null);
        TermEntity dod = TermEntity.builder()
                .name("Dod")
                .id(1)
                .build();
        List<Description> descriptionList = new ArrayList<>();
        descriptionList.add(inputRequest1);
        descriptionList.add(inputRequest2);
        List<DescriptionEntity> descriptionEntityList = new ArrayList<>();
        descriptionEntityList.add(convertedDescriptionEntity1);
        descriptionEntityList.add(convertedDescriptionEntity2);



        //Action
        List<DescriptionEntity> expectedDescriptionEntityList = descriptionService.convertListOfDescriptionToListOfDescriptionEntity(descriptionList,dod);

        //Assert
        assertEquals(expectedDescriptionEntityList.size(),descriptionEntityList.size());
        assertEquals(expectedDescriptionEntityList.get(0).getContent(),descriptionEntityList.get(0).getContent());
    }
}
