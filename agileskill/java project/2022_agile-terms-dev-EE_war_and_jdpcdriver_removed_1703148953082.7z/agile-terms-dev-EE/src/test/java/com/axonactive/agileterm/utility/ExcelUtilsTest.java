package com.axonactive.agileterm.utility;

import com.axonactive.agileterm.exception.InputValidationException;
import com.axonactive.agileterm.service.dto.TermImportDto;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
 class ExcelUtilsTest {

    @Mock
    Sheet sheet;
    @Mock
    Row dataRow;
    @Mock
    Row validHeaderRow;
    @Mock
    Row invalidHeaderRow;
    @Mock
    Cell validHeaderTermCell;
    @Mock
    Cell validHeaderDescriptionCell;
    @Mock
    Cell stringCell;
    @Mock
    Cell numericCell;
    @Mock
    MultipartFormDataInput XSSFMultipartFormDataInput;
    @Mock
    MultipartFormDataInput HSSFMultipartFormDataInput;
    @Mock
    MultipartFormDataInput InvalidMultipartFormDataInput;
    @Mock
    InputPart XSSFWorkbookInputPart;
    @Mock
    InputPart HSSFWorkbookInputPart;
    @Mock
    InputPart invalidInputPart;
    @Mock
    Cell blankCell;
    @Mock
    Cell booleanCell;
    @Mock
    Cell errorCell;

    @Test
    void testIsCellTypeString_shouldReturnTrue_whenInputAStringCell() {
        //Arrange
        when(dataRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(stringCell);
        when(stringCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);

        //Action
        Boolean expectedBoolean = com.axonactive.agileterm.utility.ExcelUtils.isCellTypeString(dataRow, 0);

        //Assert
        assertTrue(expectedBoolean);
    }

    @Test
    void testIsCellTypeNumeric_shouldReturnTrue_whenInputANumericCell() {
        //Arrange
        when(dataRow.getCell(1, Row.CREATE_NULL_AS_BLANK)).thenReturn(numericCell);
        when(numericCell.getCellType()).thenReturn(Cell.CELL_TYPE_NUMERIC);

        //Action
        Boolean expectedBoolean = com.axonactive.agileterm.utility.ExcelUtils.isCellTypeNumeric(dataRow, 1);

        //Assert
        assertTrue(expectedBoolean);
    }

    @Test
    void testIsCellValid_shouldReturnTrue_whenInputValidCell() {
        //Arrange
        when(dataRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(stringCell);
        when(stringCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);

        when(dataRow.getCell(1, Row.CREATE_NULL_AS_BLANK)).thenReturn(numericCell);
        when(numericCell.getCellType()).thenReturn(Cell.CELL_TYPE_NUMERIC);

        //Action
        Boolean expectedBooleanStringCell = com.axonactive.agileterm.utility.ExcelUtils.isCellValid(dataRow, 0);
        Boolean expectedBooleanNumericCell = com.axonactive.agileterm.utility.ExcelUtils.isCellValid(dataRow, 1);

        //Assert
        assertTrue(expectedBooleanStringCell);
        assertTrue(expectedBooleanNumericCell);
    }

    @Test
    void testIsCellValid_shouldReturnFalse_whenInputInValidCell() {
        //Arrange
        when(dataRow.getCell(2, Row.CREATE_NULL_AS_BLANK)).thenReturn(blankCell);
        when(blankCell.getCellType()).thenReturn(Cell.CELL_TYPE_BLANK);
        when(dataRow.getCell(3, Row.CREATE_NULL_AS_BLANK)).thenReturn(booleanCell);
        when(booleanCell.getCellType()).thenReturn(Cell.CELL_TYPE_BOOLEAN);
        when(dataRow.getCell(4, Row.CREATE_NULL_AS_BLANK)).thenReturn(errorCell);
        when(errorCell.getCellType()).thenReturn(Cell.CELL_TYPE_ERROR);

        //Action
        Boolean expectedBooleanBlankCell = com.axonactive.agileterm.utility.ExcelUtils.isCellValid(dataRow, 2);
        Boolean expectedBooleanBooleanCell = com.axonactive.agileterm.utility.ExcelUtils.isCellValid(dataRow, 3);
        Boolean expectedBooleanErrorCell = com.axonactive.agileterm.utility.ExcelUtils.isCellValid(dataRow, 4);

        //Assert
        assertFalse(expectedBooleanBooleanCell);
        assertFalse(expectedBooleanErrorCell);
        assertFalse(expectedBooleanBlankCell);
    }

    @Test
     void testIsRowValidString_shouldReturnTrue_whenInputValidRow() {
        //Arrange
        when(dataRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(stringCell);
        when(stringCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);

        //Action
        Boolean expectedBooleanRowValid = com.axonactive.agileterm.utility.ExcelUtils.isRowValid(dataRow);

        //Assert
        assertTrue(expectedBooleanRowValid);
    }

    @Test
    void testIsRowValidNumeric_shouldReturnTrue_whenInputValidRow() {
        //Arrange
        when(dataRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(blankCell);
        when(blankCell.getCellType()).thenReturn(Cell.CELL_TYPE_BLANK);

        when(dataRow.getCell(1, Row.CREATE_NULL_AS_BLANK)).thenReturn(numericCell);
        when(numericCell.getCellType()).thenReturn(Cell.CELL_TYPE_NUMERIC);

        //Action
        Boolean expectedBooleanRowValid = com.axonactive.agileterm.utility.ExcelUtils.isRowValid(dataRow);

        //Assert
        assertTrue(expectedBooleanRowValid);
    }

    @Test
    void testGetFileExtension_shouldReturnExtension_whenInputFileName() {
        //Arrange
        String fileName = "example.doc";
        String fileExtension = "doc";

        //Action
        String expectedFileExtension = com.axonactive.agileterm.utility.ExcelUtils.getFileExtension(fileName);

        //Assert
        assertEquals(expectedFileExtension, fileExtension);
    }

    @Test
     void testGetCellData_shouldCellValue_whenInputValidCell() {
        //Arrange
        String stringCellVale = "String";
        String numericCellValue = "1234.0";

        when(dataRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(stringCell);
        when(stringCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);
        when(stringCell.getStringCellValue()).thenReturn("String");

        when(dataRow.getCell(1, Row.CREATE_NULL_AS_BLANK)).thenReturn(numericCell);
        when(numericCell.getCellType()).thenReturn(Cell.CELL_TYPE_NUMERIC);
        when(numericCell.getNumericCellValue()).thenReturn(1234.0);

        //Action
        String expectedStringCellValue = com.axonactive.agileterm.utility.ExcelUtils.getCellData(dataRow, 0);
        String expectedNumericCellValue = com.axonactive.agileterm.utility.ExcelUtils.getCellData(dataRow, 1);

        //Assert
        assertEquals(expectedStringCellValue, stringCellVale);
        assertEquals(expectedNumericCellValue, numericCellValue);
    }

    @Test
    void testGetDataFromARow_shouldReturnTermImportDto_whenInputValidRow() {
        //Arrange
        String stringCellVale = "String";
        TermImportDto sample = new TermImportDto();
        sample.setTermString(stringCellVale);
        sample.setDescriptionString("1234.0");

        when(dataRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(stringCell);
        when(stringCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);
        when(stringCell.getStringCellValue()).thenReturn("String");

        when(dataRow.getCell(1, Row.CREATE_NULL_AS_BLANK)).thenReturn(numericCell);
        when(numericCell.getCellType()).thenReturn(Cell.CELL_TYPE_NUMERIC);
        when(numericCell.getNumericCellValue()).thenReturn(1234.0);

        //Action
        TermImportDto expectedTermImportDto = com.axonactive.agileterm.utility.ExcelUtils.getDataFromARow(dataRow);

        //Assert
        assertEquals(expectedTermImportDto, sample);
    }

    @Test
    void testIsSheetTemplateValid_shouldReturnTrue_whenInputValidHeaderRow() {
        //Arrange
        when(sheet.getRow(0)).thenReturn(validHeaderRow);

        when(validHeaderRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(validHeaderTermCell);
        when(validHeaderRow.getCell(0)).thenReturn(validHeaderTermCell);
        when(validHeaderTermCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);
        when(validHeaderTermCell.getStringCellValue()).thenReturn("Term");

        when(validHeaderRow.getCell(1, Row.CREATE_NULL_AS_BLANK)).thenReturn(validHeaderDescriptionCell);
        when(validHeaderRow.getCell(1)).thenReturn(validHeaderDescriptionCell);
        when(validHeaderDescriptionCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);
        when(validHeaderDescriptionCell.getStringCellValue()).thenReturn("Description");
        //Action
        Boolean expectedSheetTemplateValidBoolean = com.axonactive.agileterm.utility.ExcelUtils.isSheetTemplateValid(sheet);

        //Assert
        assertTrue(expectedSheetTemplateValidBoolean);
    }

    @Test
    void testIsSheetTemplateValid_shouldThrowException_whenInputInValidHeaderRow() {
        //Arrange
        when(sheet.getRow(0)).thenReturn(invalidHeaderRow);

        when(invalidHeaderRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(stringCell);

        //Action

        //Assert
        try {
            com.axonactive.agileterm.utility.ExcelUtils.isSheetTemplateValid(sheet);
        } catch (InputValidationException e) {
            assertEquals("File template is not supported", e.getMessage());
        }
    }

    @Test
     void testIsHeaderTemplateValid_shouldReturnTrue_whenInputValidHeaderRow() {
        //Arrange
        when(validHeaderRow.getCell(0, Row.CREATE_NULL_AS_BLANK)).thenReturn(validHeaderTermCell);
        when(validHeaderRow.getCell(0)).thenReturn(validHeaderTermCell);
        when(validHeaderTermCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);
        when(validHeaderTermCell.getStringCellValue()).thenReturn("Term");

        when(validHeaderRow.getCell(1, Row.CREATE_NULL_AS_BLANK)).thenReturn(validHeaderDescriptionCell);
        when(validHeaderRow.getCell(1)).thenReturn(validHeaderDescriptionCell);
        when(validHeaderDescriptionCell.getCellType()).thenReturn(Cell.CELL_TYPE_STRING);
        when(validHeaderDescriptionCell.getStringCellValue()).thenReturn("Description");

        //Action
        Boolean expectedSheetTemplateValidBoolean = com.axonactive.agileterm.utility.ExcelUtils.isHeaderTemplateValid(validHeaderRow);

        //Assert
        assertTrue(expectedSheetTemplateValidBoolean);
    }

    @Test
     void getTermAndDefinitionMap() {
        //Arrange
        List<TermImportDto> termImportDtoList = new ArrayList<>();
        TermImportDto termImportDtoDod1 = new TermImportDto(1, "Dod", "definition of done");
        TermImportDto termImportDtoDod2 = new TermImportDto(2, "Dod", "thing to do before done");
        termImportDtoList.add(termImportDtoDod1);
        termImportDtoList.add(termImportDtoDod2);

        Map<String, List<String>> stringListMap = new HashMap<>();
        List<String> definitionList = new ArrayList<>();
        definitionList.add("definition of done");
        definitionList.add("thing to do before done");
        stringListMap.put("Dod", definitionList);

        //Action
        Map<String, List<String>> expectedStringListMap = com.axonactive.agileterm.utility.ExcelUtils.getTermAndDefinitionMap(termImportDtoList);

        //Assert
        assertEquals(expectedStringListMap, stringListMap);
    }

    @Test
     void testConvertToWorkBook_shouldReturnWorkBook_whenInputValidHSSFFile() throws IOException, InvalidFormatException {
        //Arrange
        //set up for xls file
        List<InputPart> HSSFInputParts = new ArrayList<>();
        HSSFInputParts.add(HSSFWorkbookInputPart);
        Map<String, List<InputPart>> HSSFFormDataMap = new HashMap<>();
        HSSFFormDataMap.put("file", HSSFInputParts);
        MultivaluedMap<String, String> HSSFHeader = new MultivaluedHashMap<>();
        HSSFHeader.add("Content-Disposition", "filename=excel.xls;ai");
        File xlsFile = new File("./src/test/resources/AgileTerm_Topic_Template.xls");
        InputStream xlsInputStream = new FileInputStream(xlsFile);

        Workbook sampleXLSWorkBook = WorkbookFactory.create(xlsFile);
        when(HSSFMultipartFormDataInput.getFormDataMap()).thenReturn(HSSFFormDataMap);
        when(HSSFWorkbookInputPart.getHeaders()).thenReturn(HSSFHeader);
        when(HSSFWorkbookInputPart.getBody(InputStream.class, null)).thenReturn(xlsInputStream);

        ////set up for xlsx file
        List<InputPart> XSSFInputParts = new ArrayList<>();
        XSSFInputParts.add(XSSFWorkbookInputPart);
        Map<String, List<InputPart>> XSSFFormDataMap = new HashMap<>();
        XSSFFormDataMap.put("file", XSSFInputParts);
        MultivaluedMap<String, String> XSSFHeader = new MultivaluedHashMap<>();
        XSSFHeader.add("Content-Disposition", "filename=excel.xlsx;ai");
        File xlsxFile = new File("./src/test/resources/VALID.xlsx");
        InputStream xlsxInputStream = new FileInputStream(xlsxFile);

        Workbook sampleXLSXWorkBook = WorkbookFactory.create(xlsxFile);
        when(XSSFMultipartFormDataInput.getFormDataMap()).thenReturn(XSSFFormDataMap);
        when(XSSFWorkbookInputPart.getHeaders()).thenReturn(XSSFHeader);
        when(XSSFWorkbookInputPart.getBody(InputStream.class, null)).thenReturn(xlsxInputStream);

        ////set up for invalid file
        List<InputPart> invalidInputParts = new ArrayList<>();
        invalidInputParts.add(invalidInputPart);
        Map<String, List<InputPart>> invalidFormDataMap = new HashMap<>();
        invalidFormDataMap.put("file", invalidInputParts);
        MultivaluedMap<String, String> invalidHeader = new MultivaluedHashMap<>();
        invalidHeader.add("Content-Disposition", "filename=INVALID_File_Type.dotx;ai");
//        File invalidFile = new File("./src/test/resources/INVALID_File_Type.dotx");

        when(InvalidMultipartFormDataInput.getFormDataMap()).thenReturn(invalidFormDataMap);
        when(invalidInputPart.getHeaders()).thenReturn(invalidHeader);
//        when(XSSFWorkbookInputPart.getBody(InputStream.class, null)).thenReturn(xlsxInputStream);

        //Action
        Workbook expectedXLSWorkbook = com.axonactive.agileterm.utility.ExcelUtils.convertToWorkBook(HSSFMultipartFormDataInput);
        Workbook expectedXLSXWorkbook = com.axonactive.agileterm.utility.ExcelUtils.convertToWorkBook(XSSFMultipartFormDataInput);

        //Assert
        assertEquals(expectedXLSWorkbook.getSheetAt(0).getRow(0).getCell(0).getCellType(), sampleXLSWorkBook.getSheetAt(0).getRow(0).getCell(0).getCellType());
        assertEquals(expectedXLSXWorkbook.getSheetAt(0).getRow(0).getCell(0).getCellType(), sampleXLSXWorkBook.getSheetAt(0).getRow(0).getCell(0).getCellType());
        try {
            com.axonactive.agileterm.utility.ExcelUtils.convertToWorkBook(InvalidMultipartFormDataInput);
        } catch (InputValidationException e) {
            assertEquals( "File not supported",e.getMessage());
        }
    }


    @Test
     void testGetListOfTermAndDescriptionImportDto_shouldReturnListOfTermAndDescriptionImportDto_whenInputValidHSSFFile() throws IOException {
        //Arrange
        List<InputPart> HSSFInputParts = new ArrayList<>();
        HSSFInputParts.add(HSSFWorkbookInputPart);
        Map<String, List<InputPart>> HSSFFormDataMap = new HashMap<>();
        HSSFFormDataMap.put("file", HSSFInputParts);
        MultivaluedMap<String, String> HSSFHeader = new MultivaluedHashMap<>();
        HSSFHeader.add("Content-Disposition", "filename=excel.xls;ai");
        File xlsFile = new File("./src/test/resources/file_xls.xls");
        InputStream xlsInputStream = new FileInputStream(xlsFile);
        when(HSSFMultipartFormDataInput.getFormDataMap()).thenReturn(HSSFFormDataMap);
        when(HSSFWorkbookInputPart.getHeaders()).thenReturn(HSSFHeader);
        when(HSSFWorkbookInputPart.getBody(InputStream.class, null)).thenReturn(xlsInputStream);

        List<TermImportDto> termImportDtoList = new ArrayList<>();
        termImportDtoList.add(new TermImportDto(2, "Acceptance criteria", "A set of conditions that software must meet in order to be accepted by a customer or stakeholder"));
        termImportDtoList.add(new TermImportDto(3, "Dod", "Definition Of Done"));
        termImportDtoList.add(new TermImportDto(4, "1000.0", ""));
        termImportDtoList.add(new TermImportDto(5, "", "10.0"));

        //Action
        List<TermImportDto> expectedTermImportDtoList = com.axonactive.agileterm.utility.ExcelUtils.getListOfTermAndDescriptionImportDto(HSSFMultipartFormDataInput);

        //Assert
        assertEquals(expectedTermImportDtoList, termImportDtoList);
    }
}
