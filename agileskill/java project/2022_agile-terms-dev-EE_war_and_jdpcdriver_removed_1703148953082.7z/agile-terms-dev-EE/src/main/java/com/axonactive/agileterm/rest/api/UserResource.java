package com.axonactive.agileterm.rest.api;

import com.axonactive.agileterm.rest.client.model.User;
import com.axonactive.agileterm.rest.model.UserDto;
import com.axonactive.agileterm.service.UserService;
import com.axonactive.agileterm.service.mapper.UserMapper;
import com.axonactive.agileterm.utility.EmailUtils;
import io.swagger.annotations.*;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;

@Stateless
@Path(UserResource.PATH)
@Api(tags={"User"}, value = "APIs to manipulate User in Agile-term")
public class UserResource {

    public static final String PATH = "/users";

    @Inject
    UserService userService;

    @Inject
    UserMapper userMapper;

    @Inject
    EmailUtils emailUtils;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get list of all users")
    @ApiResponses({
            @ApiResponse(code=200, message="Return a list of user", response = UserDto.class, responseContainer = "List"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getAll() {
        return Response.ok(userMapper.toDtos(userService.getAll())).build();
    }

    @POST
    @Path("/signup")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Sign up new user")
    @ApiResponses({
            @ApiResponse(code=201, message="Successfully signed up", response = UserDto.class),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response save(@ApiParam(value="User's registration info inputted",name ="Registration form's input", required = true ) @Valid User userRequest) {
        UserDto createdUser = userService.save(userRequest);
        emailUtils.sendVerificationEmail(userRequest);
        return Response.created(URI.create(PATH + "/" + createdUser.getId())).entity(createdUser).status(Response.Status.CREATED).build();
    }


    @GET
    @Path("validate-username/{username}")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Check if username exist in database")
    @ApiResponses({
            @ApiResponse(code=204, message="Available username"),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=404, message="Not found"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response usernameExistValidate(@ApiParam(value ="User's username input", name="username", required = true ) @PathParam("username") String username) {
        userService.validateUserName(username);
        return Response.noContent().build();
    }

    @GET
    @Path("validate-email/{email}")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Check if email exist in database")
    @ApiResponses({
            @ApiResponse(code=204, message="Available email"),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=404, message="Not found"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response emailExistValidate(@ApiParam(value ="User's email input",name ="email", required = true ) @PathParam("email") String email) {
        userService.validateEmail(email);
        return Response.noContent().build();
    }

}
