package com.axonactive.agileterm.rest.api;

import com.axonactive.agileterm.rest.model.TopicDto;
import com.axonactive.agileterm.service.TopicService;
import com.axonactive.agileterm.service.mapper.TopicMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

@Stateless
@Path(TopicResource.PATH)
@Api(tags={"Topic"}, value = "APIs to manipulate Topic in Agile-term")
public class TopicResource {
    public static final String PATH = "/topics";
    @Inject
    TopicService topicService;

    @Inject
    TopicMapper topicMapper;

    @Context
    private UriInfo uriInfo;

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get all topics")
    @ApiResponses({
            @ApiResponse(code=200, message="Return a list of all topics",response = TopicDto.class, responseContainer = "List"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getAll() {
        return Response.ok(topicMapper.toDtos(topicService.getAll())).build();
    }

    @GET
    @Path("popular")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get 10 most popular topics")
    @ApiResponses({
            @ApiResponse(code=200, message="Return a list of top 10 popular topics", response = TopicDto.class, responseContainer = "List"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),})
    public Response getListOfPopularTopic() {
        return Response.ok(topicMapper.toDtos(topicService.getPopularTopic())).build();
    }
}
