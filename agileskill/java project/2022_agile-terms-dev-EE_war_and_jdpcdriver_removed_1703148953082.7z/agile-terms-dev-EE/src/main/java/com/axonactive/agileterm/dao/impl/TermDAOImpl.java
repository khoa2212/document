package com.axonactive.agileterm.dao.impl;

import com.axonactive.agileterm.dao.TermDAO;
import com.axonactive.agileterm.entity.TermEntity;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class TermDAOImpl implements TermDAO {
@PersistenceContext(name = "agileterm")
EntityManager em;


@Override
public List<TermEntity> getAll() {
    return em.createQuery(
                    "SELECT DISTINCT t FROM TermEntity t LEFT JOIN FETCH t.descriptionEntityList d LEFT JOIN FETCH d.userEntity u ")
            .getResultList();
}

@Override
public TermEntity findTermById(Integer id) {
    List<TermEntity> termEntityList = em.createQuery(
                    "SELECT DISTINCT t FROM TermEntity t LEFT JOIN FETCH t.descriptionEntityList d " +
                            "LEFT JOIN FETCH d.userEntity u WHERE t.id = :id", TermEntity.class)
            .setParameter("id", id)
            .getResultList();
    if (!termEntityList.isEmpty())
        return termEntityList.get(0);
    return null;
}

@Override
public TermEntity save(TermEntity termEntity) {
    TermEntity savedEntity = this.em.merge(termEntity);
    this.em.flush();
    return savedEntity;
}

@Override
public TermEntity findTermByTermName(String name) {
    List<TermEntity> termEntityList = em.createQuery(
                    "SELECT DISTINCT t FROM TermEntity t LEFT JOIN FETCH t.descriptionEntityList d " +
                            "LEFT JOIN FETCH d.userEntity u WHERE LOWER(t.name) = LOWER(:inputName)", TermEntity.class)
            .setParameter("inputName", name)
            .getResultList();
    if (!termEntityList.isEmpty())
        return termEntityList.get(0);
    return null;
}

@Override
public List<TermEntity> findTop10TermsByTermNameContain(String keyword) {
    return em.createQuery(
                    "SELECT new com.axonactive.agileterm.entity.TermEntity(t.id, t.name) FROM TermEntity t WHERE LOWER(t.name) LIKE LOWER(CONCAT('%',:keyword,'%')) ORDER BY t.name")
            .setParameter("keyword", keyword)
            .setMaxResults(10)
            .getResultList();
}

@Override
public List<TermEntity> findRecentTerm() {
    return em.createQuery("SELECT t FROM TermEntity t LEFT JOIN FETCH t.descriptionEntityList d LEFT JOIN FETCH d.userEntity ORDER BY t.id DESC")
            .setMaxResults(10)
            .getResultList();
}

@Override
public List<TermEntity> findTop10PopularTerms() {
    List<Integer> top10PopularTerms = em.createNativeQuery("SELECT t.id from term t LEFT JOIN description d ON t.id = d.term_id GROUP BY t.id ORDER BY COUNT(d) DESC LIMIT 10").getResultList();
    return em.createQuery("SELECT DISTINCT t1 FROM TermEntity t1 LEFT JOIN FETCH t1.descriptionEntityList d1 LEFT JOIN FETCH d1.userEntity u WHERE t1.id IN (:idList)", TermEntity.class).setParameter("idList", top10PopularTerms).getResultList();
}
}
