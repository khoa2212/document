package com.axonactive.agileterm.entity;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER
}
