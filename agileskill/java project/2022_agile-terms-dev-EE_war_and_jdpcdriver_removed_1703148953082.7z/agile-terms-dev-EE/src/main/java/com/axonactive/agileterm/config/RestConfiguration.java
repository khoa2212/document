package com.axonactive.agileterm.config;


import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@ApplicationPath("api")
public class RestConfiguration extends Application {

}
