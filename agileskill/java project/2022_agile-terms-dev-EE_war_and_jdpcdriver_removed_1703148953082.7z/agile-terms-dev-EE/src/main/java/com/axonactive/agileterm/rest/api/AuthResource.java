package com.axonactive.agileterm.rest.api;


import com.axonactive.agileterm.entity.Role;
import com.axonactive.agileterm.rest.client.model.JwtRequest;
import com.axonactive.agileterm.rest.model.JwtResponse;
import com.axonactive.agileterm.rest.model.UserDto;
import com.axonactive.agileterm.service.AuthenticationService;
import com.axonactive.agileterm.service.UserService;
import com.axonactive.agileterm.utility.JwtUtils;
import io.swagger.annotations.*;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Stateless
@Path(AuthResource.PATH)
@Api(tags={"Authenticate"}, value = "Authentication Api")
public class AuthResource {
    public static final String PATH = "/auth";

    @Inject
    private JwtUtils jwtUtils;

    @Inject
    private UserService userService;

    @Inject
    private AuthenticationService authenticationService;

    @POST
    @Path("login")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @ApiOperation(value = "Login")
    @ApiResponses({
            @ApiResponse(code=200, message="Successfully logged in",response = JwtResponse.class),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getJwtResponse(@ApiParam(value="User's login input",name ="Login input", required = true ) @Valid JwtRequest jwtRequest) {
        JwtResponse jwtResponse = jwtUtils.generateJwtResponse(jwtRequest);
        return Response.ok(jwtResponse).build();
    }


    @GET
    @Path("getRoleFromToken")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @ApiOperation(value = "Get user role from Jwt token")
    @ApiResponses({
            @ApiResponse(code=200, message="User is existed in database and return corresponding role",response = Role.class, responseContainer = "List"),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=404, message="Not found"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getRoleFromToken(@ApiParam(value = "User's token received after login",name ="Authorization", required = true) @HeaderParam("Authorization") String authorization){
       List<Role> roles = jwtUtils.getRoleFromToken(authorization);
        return Response.ok(roles).build();
    }

    @ApiOperation(value = "Verify User by verification code")
    @ApiResponses({
            @ApiResponse(code=200, message="Verification Successfully",response = UserDto.class),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    @GET
    @Path("/verify/{verifyCode}")
    @Produces({MediaType.APPLICATION_JSON})
    public Response verifyUser(@ApiParam(value = "User verification code",name ="verifyCode", required = true) @PathParam("verifyCode") String verifyCode){
        return Response.ok(userService.verifyUser(verifyCode)).build();
    }

    @GET
    @Path("/verify-token-session/{token}")
    @Produces({MediaType.APPLICATION_JSON})
    public Response verifySessionToken(@ApiParam(value = "JWT Token",name = "token",required = true) @PathParam("token") String token){
        jwtUtils.isTokenExpired("Bearer "+token);
       return Response.ok().build();
    }
}
