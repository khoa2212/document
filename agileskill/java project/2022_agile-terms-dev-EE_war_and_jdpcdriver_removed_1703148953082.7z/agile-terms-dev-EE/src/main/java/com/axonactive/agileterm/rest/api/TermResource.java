package com.axonactive.agileterm.rest.api;


import com.axonactive.agileterm.entity.TermEntity;
import com.axonactive.agileterm.rest.client.model.Term;
import com.axonactive.agileterm.rest.model.ResponseForUploadFile;
import com.axonactive.agileterm.rest.model.TermDto;
import com.axonactive.agileterm.service.TermService;
import com.axonactive.agileterm.service.TermTopicService;
import com.axonactive.agileterm.service.mapper.TermMapper;
import com.axonactive.agileterm.service.mapper.TopicMapper;
import com.axonactive.agileterm.utility.JwtUtils;
import io.swagger.annotations.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.servlet.annotation.MultipartConfig;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;

@Stateless
@Path(TermResource.PATH)
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 10)// 10MB
@Api(tags={"Term"}, value = "APIs to manipulate Term in Agile-term")

public class TermResource {

    Logger logger = LogManager.getLogger(TermResource.class);

    public static final String PATH = "/terms";

    @Inject
    private TermService termService;

    @Inject
    private TermMapper termMapper;

    @Inject
    private TermTopicService termTopicService;

    @Inject
    private JwtUtils jwtUtils;

    @Inject
    private TopicMapper topicMapper;


    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get all terms")
    @ApiResponses({
            @ApiResponse(code=200, message="Return a list of all terms", response = TermDto.class, responseContainer = "List"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),

    })
    public Response getAll() {
        logger.info("Get All Terms:");
        return Response.ok(termMapper.toDtos(termService.getAll())).build();
    }


    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Add a new term")
    @ApiResponses({
            @ApiResponse(code=201, message="Return a list of all terms",response = TermDto.class),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response save( @HeaderParam("Authorization") String authorization,@ApiParam(value ="Agile term to be created", required = true, name="New term's info") @Valid Term term) {
        jwtUtils.validateAccountIsActive(authorization);
        TermEntity savedTerm = termService.save(term);
        TermDto createdTerm = termMapper.toDto(savedTerm);
        createdTerm.setTopicList(topicMapper.toDtos(termTopicService.findListOfTopicEntityFromTermId(savedTerm.getId())));
        return Response.created(URI.create(PATH + "/" + createdTerm.getEncodedId())).entity(createdTerm).build();
    }

    @GET
    @Path("{encodedTermId}/details")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Find term, its related descriptions and topics by term encoded id")
    @ApiResponses({
            @ApiResponse(code=200, message="Return a term",response = TermDto.class),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=404, message="Term not found"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getTermDetailById( @PathParam("encodedTermId") @ApiParam(value="Term encoded Id",name="encodedTermId", required = true) String encodedId) {
        return Response.ok(termService.findTermDetailById(encodedId)).build();
    }

    @POST
    @Path("/upload-file")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Upload an excel file of terms and descriptions")
    @ApiResponses({
            @ApiResponse(code=200, message="File process successfully and return result",response = ResponseForUploadFile.class),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=413, message="File size exceed limit"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    @ApiImplicitParams({
            @ApiImplicitParam(value = "File to be uploaded with list of terms and their descriptions",dataType = "file",paramType = "formData")})
    public Response uploadTermWithExcelFile(@HeaderParam("Authorization") String authorization,@ApiParam(hidden = true) MultipartFormDataInput excelFile) throws IOException {
        jwtUtils.validateUserIsAdmin(authorization);
        return Response.ok(termService.uploadTermAndDescriptionExcelFile(excelFile)).build();
    }

    @POST
    @Path("/contain-key")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get 10 terms contain a specific keyword")
    @ApiResponses({
            @ApiResponse(code=200, message="Found out related terms and return to user",response = TermDto.class, responseContainer = "List"),
            @ApiResponse(code=400, message="Request sent to the server is invalid or corrupted"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getListOf10TermContainKeyWord(@ApiParam(value="User's inputted term's keyword",name ="Keyword", required = true ) Term term) {
        return Response.ok(termService.findTop10TermsByTermNameContain(term.getName())).build();
    }

    @GET
    @Path("/popular")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get 10 popular terms")
    @ApiResponses({
            @ApiResponse(code=200, message="Return a list of 10 popular terms", response = TermDto.class, responseContainer = "List"),
            @ApiResponse(code=401, message="Sign-in required"),
            @ApiResponse(code=403, message="Unauthorized access"),
            @ApiResponse(code=500, message="Request cannot be fulfilled through browser due to server-side problems"),

    })
    public Response getPopularTerms() {
        return Response.ok(termService.getTop10PopularTerms()).build();
    }

    @GET
    @Path("/recent")
    @Produces({MediaType.APPLICATION_JSON})
    @ApiOperation(value = "Get 10 most recent term")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Return 10 most recent term", response = TermDto.class, responseContainer = "List"),
            @ApiResponse(code = 401, message = "Sign-in require"),
            @ApiResponse(code = 403, message = "Unauthorized access"),
            @ApiResponse(code = 500, message = "Request cannot be fulfilled through browser due to server-side problems"),
    })
    public Response getListOf10MostRecentTerm(){
        return Response.ok(termService.find10RecentTerm()).build();
    }


}
