package com.axonactive.agileterm.exception;

import java.util.ResourceBundle;

public class ErrorMessage {

    private static final ResourceBundle bundle = ResourceBundle.getBundle("message");

    public static final String INVALID_ID = bundle.getString("exception.input.validation");

    public static final String TOPIC_NOT_FOUND= bundle.getString("exception.resource-not-found-topic");

    public static final String TERM_NOT_FOUND= bundle.getString("exception.resource-not-found-term");

    public static final String TERM_TOPIC_NOT_FOUND= bundle.getString("exception.resource-not-found-term-topic");

    public static final String DESCRIPTION_NOT_FOUND= bundle.getString("exception.resource-not-found-description");

    public static final String AUTHOR_NOT_FOUND= bundle.getString("exception.resource-not-found-author");

    public static final String USER_NOT_FOUND= bundle.getString("exception.resource-not-found-user");

    public static final String VOTE_NOT_FOUND= bundle.getString("exception.resource-not-found-vote");

    public static final String EMAIL_EXISTED= bundle.getString("exception.security.user-email-existed");

    public static final String USERNAME_EXISTED= bundle.getString("exception.security.username-existed");

    public static final String CONFIRM_PASSWORD_NOT_MATCH= bundle.getString("exception.security.confirm-password-not-match");

    public static final String EMAIL_INVALID= bundle.getString("exception.security.user-email-invalid");

    public static final String PASSWORD_INVALID= bundle.getString("exception.security.password-invalid");

    public static final String ACCOUNT_ALREADY_ACTIVATED= bundle.getString("exception.system.account-already-activate");

    public static final String TERM_ALREADY_EXISTED= bundle.getString("exception.system.term-already-existed");

    public static final String UNAUTHORIZED_ACCESS= bundle.getString("exception.security.unauthorized-access");

    public static final String DESCRIPTION_ALREADY_EXISTED = bundle.getString("exception.system.description-already-existed");

    public static final String DESCRIPTION_MUST_NOT_BE_NULL = bundle.getString("exception.system.description-is-blank");

    public static final String SESSION_TIMED_OUT = bundle.getString("exception.security.session-timed-out");

    private ErrorMessage() {
    }
}
