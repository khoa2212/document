package com.axonactive.agileterm.rest.api;

import com.axonactive.agileterm.rest.client.model.Term;
import com.axonactive.agileterm.rest.model.TermDto;
import com.axonactive.agileterm.service.TermService;
import com.axonactive.agileterm.service.mapper.TermMapper;
import com.axonactive.agileterm.utility.JwtUtils;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.net.URI;

@Stateless
@Path(DescriptionResource.PATH)
public class DescriptionResource {
    public static final String PATH = "/decriptions";
    @Inject
    private JwtUtils jwtUtils;

    @Inject
    private TermMapper termMapper;

    @Inject
    private TermService termService;

    @Context
    private UriInfo uriInfo;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Response save(@HeaderParam("Authorization")String authorization, @Valid Term term){
        jwtUtils.validateAccountIsActive(authorization);
        TermDto updatedTerm = termMapper.toDto((termService.save(term))) ;
        return Response.created(URI.create(PATH + "/" + updatedTerm.getEncodedId())).entity(updatedTerm).build();
    }
}
