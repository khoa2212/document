package com.axonactive.agileterm.dao;

import com.axonactive.agileterm.entity.TermEntity;

import javax.ejb.Stateless;
import java.util.List;

@Stateless
public interface TermDAO {
    List<TermEntity> getAll();

    TermEntity findTermById(Integer id);

    TermEntity save(TermEntity termEntity);

    TermEntity findTermByTermName(String name);

    List<TermEntity> findTop10TermsByTermNameContain(String keyword);

    List<TermEntity> findRecentTerm();


    List<TermEntity> findTop10PopularTerms();
}
