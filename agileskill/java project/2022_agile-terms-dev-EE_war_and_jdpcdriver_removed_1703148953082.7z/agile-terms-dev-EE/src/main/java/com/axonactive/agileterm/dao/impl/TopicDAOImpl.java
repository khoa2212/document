package com.axonactive.agileterm.dao.impl;

import com.axonactive.agileterm.dao.TopicDAO;
import com.axonactive.agileterm.entity.TopicEntity;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Stateless
public class TopicDAOImpl implements TopicDAO {
    @PersistenceContext(name = "agileterm")
    EntityManager em;

    @Override
    public List<TopicEntity> findAll() {
        return em.createQuery("SELECT t FROM TopicEntity t", TopicEntity.class).getResultList();
    }

    @Override
    public TopicEntity save(TopicEntity topicEntity) {
        return this.em.merge(topicEntity);
    }

    @Override
    public TopicEntity findById(Integer topicId) {
            List<TopicEntity> topicEntityList = em.createQuery("SELECT t FROM TopicEntity t WHERE t.id = :topicId", TopicEntity.class)
                .setParameter("topicId", topicId).getResultList();
        if (!topicEntityList.isEmpty())
            return topicEntityList.get(0);
        return null;
    }

    @Override
    public List<TopicEntity> findPopularTopics() {
     Query queryFindPopularTopics = em.createNativeQuery(
                "SELECT  t1.id, t1.name , t1.color " +
                        "FROM topic t1 " +
                        "LEFT JOIN term_topic t2 " +
                        "ON t1.id = t2.topic_id " +
                        "GROUP BY t2.topic_id, t1.name, t1.id, t1.color " +
                        "ORDER BY COUNT(t2.topic_id) DESC "
                        ,TopicEntity.class)
             .setMaxResults(10);
                List<TopicEntity> topicEntityList = (List<TopicEntity>) queryFindPopularTopics.getResultList();
                return topicEntityList;
    }
}
