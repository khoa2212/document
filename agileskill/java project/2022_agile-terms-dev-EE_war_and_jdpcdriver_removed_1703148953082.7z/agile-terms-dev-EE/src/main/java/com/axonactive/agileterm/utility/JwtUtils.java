package com.axonactive.agileterm.utility;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.axonactive.agileterm.config.AppConfigService;
import com.axonactive.agileterm.entity.Role;
import com.axonactive.agileterm.entity.UserEntity;
import com.axonactive.agileterm.entity.UserRoleAssignmentEntity;
import com.axonactive.agileterm.exception.ErrorMessage;
import com.axonactive.agileterm.exception.SecurityException;
import com.axonactive.agileterm.rest.client.model.JwtRequest;
import com.axonactive.agileterm.rest.model.JwtResponse;
import com.axonactive.agileterm.service.AuthenticationService;
import com.axonactive.agileterm.service.UserService;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Stateless
public class JwtUtils {

    private static final String USERNAME = "username";

    private static final String BEARER = "Bearer ";
    @Inject
    private AuthenticationService authenticationService;
    @Inject
    private UserService userService;

    public String generateToken(@Valid JwtRequest jwtRequest) {

        if (!authenticationService.checkAuthentication(jwtRequest.getUsername(), jwtRequest.getPassword())) {
            throw new SecurityException(ErrorMessage.UNAUTHORIZED_ACCESS);
        }

        String token = null;
        String secretKey = AppConfigService.getSecretKey();
        String issuer = AppConfigService.getIssuer();

        int timeToLive = AppConfigService.getTimeToLive();

        try {
            Algorithm algorithm = Algorithm.HMAC512(secretKey);
            token = JWT.create()
                    .withIssuer(issuer)
                    .withIssuedAt(new Date())
                    .withJWTId(UUID.randomUUID().toString())
                    .withClaim(USERNAME, jwtRequest.getUsername())
                    .withExpiresAt(new Date(System.currentTimeMillis() + timeToLive))
                    .sign(algorithm);
        } catch (IllegalArgumentException | JWTCreationException e) {
            throw new SecurityException(ErrorMessage.UNAUTHORIZED_ACCESS);
        }

        return token;
    }

    public void validateJwtToken(String authorization) {
        if (authorization == null) {
            throw new SecurityException(ErrorMessage.UNAUTHORIZED_ACCESS);
        }

        try {
            String secretKey = AppConfigService.getSecretKey();
            String issuer = AppConfigService.getIssuer();

            Algorithm algorithm = Algorithm.HMAC512(secretKey);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withIssuer(issuer)
                    .build();
            verifier.verify(authorization.substring(BEARER.length()).trim());
        } catch (IllegalArgumentException | JWTVerificationException e) {
            throw new SecurityException(ErrorMessage.UNAUTHORIZED_ACCESS);
        }
    }

    public JwtResponse generateJwtResponse(@Valid JwtRequest jwtRequest) {

        String token = generateToken(jwtRequest);

        String username = jwtRequest.getUsername();

        UserEntity user = userService.validateUser(username);

        List<String> roleList = user.getRoles().stream()
                .map(UserRoleAssignmentEntity::getRole)
                .map(Role::toString)
                .collect(Collectors.toList());
        Boolean isActive = user.getActivated();
        return new JwtResponse(token, username, roleList, isActive);
    }

    public List<Role> getRoleFromToken(String authorization) {
        String token = authorization.substring(BEARER.length()).trim();
        DecodedJWT decodedJWT = JWT.decode(token);
        String usernameFromToken = decodedJWT.getClaim(USERNAME).asString();
        UserEntity user = userService.validateUser(usernameFromToken);
        return user.getRoles().stream()
                .map(UserRoleAssignmentEntity::getRole)
                .collect(Collectors.toList());
    }


    public boolean isUserActivated(String authorization) {
        String token = authorization.substring(BEARER.length()).trim();

        DecodedJWT decodedJWT = JWT.decode(token);

        String usernameFromToken = decodedJWT.getClaim(USERNAME).asString();

        UserEntity user = userService.validateUser(usernameFromToken);

        return user.getActivated();
    }
    public Date getTimeToLiveFromToken(String authorization) {
        String token = authorization.substring(BEARER.length()).trim();
        DecodedJWT decodedJWT = JWT.decode(token);
        Date timeToLive = decodedJWT.getExpiresAt();
        return timeToLive;
    }


    public void isTokenExpired(String token) {
        validateJwtToken(token);
        Date expiredDate = getTimeToLiveFromToken(token);
        if (expiredDate.before(Calendar.getInstance().getTime())) {
            throw new SecurityException(ErrorMessage.SESSION_TIMED_OUT);
        }
    }


    public void validateUserIsAdmin(String authorization) {

        validateJwtToken(authorization);

        List<Role> roleList = getRoleFromToken(authorization);

        if (!roleList.contains(Role.ROLE_ADMIN)) {
            throw new SecurityException(ErrorMessage.UNAUTHORIZED_ACCESS);
        }
    }

    public void validateAccountIsActive(String authorization) {

        validateJwtToken(authorization);


        if (!isUserActivated(authorization)) {
            throw new SecurityException(ErrorMessage.UNAUTHORIZED_ACCESS);
        }


    }


}
