package com.axonactive.agileterm.rest.client.model;

import lombok.*;

import javax.validation.constraints.NotBlank;
import java.util.Locale;
import java.util.Objects;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Description {
    @NotBlank
    private String content;

    @NotBlank
    private String userName;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Description that = (Description) o;
        return Objects.equals(content.toLowerCase(Locale.ROOT), that.content.toLowerCase(Locale.ROOT));
    }

    @Override
    public int hashCode() {
        return Objects.hash(content);
    }
}
