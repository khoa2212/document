package com.axonactive.agileterm.service;

import com.axonactive.agileterm.dao.DescriptionDAO;
import com.axonactive.agileterm.entity.DescriptionEntity;
import com.axonactive.agileterm.entity.TermEntity;
import com.axonactive.agileterm.rest.client.model.Description;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Stateless
public class DescriptionService {
    @Inject
    private DescriptionDAO descriptionDAO;

    @Inject
    private UserService userService;

    public boolean isDescriptionListValid(List<Description> descriptionList){
        return descriptionList != null &&
                !descriptionList.isEmpty();
    }


    public DescriptionEntity convertDescriptionToDescriptionEntity(Description description,TermEntity term) {
        DescriptionEntity descriptionEntity = new DescriptionEntity();
        descriptionEntity.setUserEntity(userService.findUserEntityByUserName(description.getUserName()));
        descriptionEntity.setContent(description.getContent());
        descriptionEntity.setTerm(term);
        return descriptionEntity;
    }

    public List<DescriptionEntity> convertListOfDescriptionToListOfDescriptionEntity(List<Description> descriptionList, TermEntity term) {
        List<DescriptionEntity> descriptionEntityList = new ArrayList<>();
        for (Description inputDescription : descriptionList
        ) {
            if(!inputDescription.getContent().trim().isEmpty()){
                descriptionEntityList.add(convertDescriptionToDescriptionEntity(inputDescription,term));
            }
        }
        return descriptionEntityList;
    }


    public List<DescriptionEntity> saveAll(List<DescriptionEntity> descriptionList) {
        List<DescriptionEntity> descriptionEntityList = new ArrayList<>();
        for (DescriptionEntity descriptionEntity : descriptionList
        ) {
            descriptionEntityList.add(descriptionDAO.save(descriptionEntity));
        }
        return descriptionEntityList;
    }

    public List<DescriptionEntity> findDescriptionByTermNameAndDescriptionString(String termName, String descriptionString) {
        return descriptionDAO.findDescriptionByTermNameAndDescriptionString(termName, descriptionString);
    }


}

