package com.axonactive.agileterm.service;

import com.axonactive.agileterm.dao.TermTopicDAO;
import com.axonactive.agileterm.entity.TermEntity;
import com.axonactive.agileterm.entity.TermTopicEntity;
import com.axonactive.agileterm.entity.TopicEntity;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Stateless
public class TermTopicService {
    @Inject
    private TermTopicDAO termTopicDAO;
    @Inject
    private TopicService topicService;

    public List<TopicEntity> findListOfTopicEntityFromTermId(Integer id) {
        return termTopicDAO.findListOfTopicByTermId(id);
    }

    public boolean isTopicListValid(List<Integer> topicIdList) {
        return topicIdList != null &&
                !topicIdList.isEmpty();
    }

    public List<TermTopicEntity> saveAllTermTopic(TermEntity term, List<Integer> topicIdList) {
        List<TermTopicEntity> termTopicEntityList = new ArrayList<>();
        for (Integer topicId : topicIdList
        ) {
            termTopicEntityList.add(new TermTopicEntity(null, term, topicService.findTopicById(topicId)));
        }
        return termTopicDAO.saveAllAndFlush(termTopicEntityList);
    }
}

