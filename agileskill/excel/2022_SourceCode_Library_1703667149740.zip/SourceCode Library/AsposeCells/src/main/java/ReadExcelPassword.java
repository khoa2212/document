import com.aspose.cells.*;

public class ReadExcelPassword {
    public static void main(String[] args) throws Exception {
        //---------Read file xlsx with password----------
        LoadOptions options = new LoadOptions();
        options.setPassword("abc123");
        Workbook workbook = new Workbook("C:\\Users\\ntmanh\\Desktop\\check_password.xlsx", options);
        Worksheet worksheet = workbook.getWorksheets().get(0);
        Range range = worksheet.getCells().getMaxDisplayRange();
        Cells cells = worksheet.getCells();
        RowCollection rowCollection = cells.getRows();
        int tcols = range.getColumnCount();
        for (int i = 0; i < rowCollection.getCount(); i++) {
            for (int j = 0; j < tcols; j++) {
                if (cells.get(i,j).getType() != CellValueType.IS_NULL) {
                    System.out.print(cells.get(i,j).getValue() + "  ");
                }
            }
            System.out.println("");
        }
    }
}
