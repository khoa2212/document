import com.aspose.cells.*;

public class WriteXLSX {
    public static void main(String[] args) throws Exception {
        //-----------Write to xlsx file------------:
        Workbook workbook = new Workbook();
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        Cells cells = worksheet.getCells();
        cells.get("A1").setValue("Hello");
        cells.get("B1").setValue("World");
        cells.get("A2").setValue("This");
        cells.get("B2").setValue("is");
        cells.get("C2").setValue("a");
        cells.get("D2").setValue("test");
        workbook.save("C:\\Users\\ntmanh\\Desktop\\output_xlsx.xlsx");
    }
}
