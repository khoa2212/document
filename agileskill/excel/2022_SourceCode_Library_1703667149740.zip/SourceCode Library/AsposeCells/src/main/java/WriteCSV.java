import com.aspose.cells.*;

public class WriteCSV {
    public static void main(String[] args) throws Exception {
        //-----------Write to csv file------------:
        Workbook workbook = new Workbook();
        Worksheet worksheet = workbook.getWorksheets().get(0);
        Cells cells = worksheet.getCells();
        cells.get("A1").setValue("Hello");
        cells.get("B1").setValue("World");
        cells.get("A2").setValue("This");
        cells.get("B2").setValue("is");
        cells.get("C2").setValue("a");
        cells.get("D2").setValue("test");
        workbook.save("C:\\Users\\ntmanh\\Desktop\\output_csv.csv");
    }
}
