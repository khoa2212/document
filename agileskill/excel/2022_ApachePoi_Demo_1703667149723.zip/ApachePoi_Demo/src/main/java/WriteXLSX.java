import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class WriteXLSX {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        //Write .xlsx file
        Workbook wookbook = new XSSFWorkbook();
        try(OutputStream fileOut = new FileOutputStream("C:\\Users\\ntmanh\\Desktop\\output_xlsx.xlsx")) {
            Sheet sheet1 = wookbook.createSheet("First Sheet");
            Sheet sheet2 = wookbook.createSheet("Second Sheet");
            Sheet sheet3 = wookbook.createSheet("Third Sheet");
            Row row     = sheet1.createRow(2);
            Cell cell   = row.createCell(5);
            cell.setCellValue("Example");

            row = sheet1.createRow(0);
            cell   = row.createCell(0);
            cell.setCellValue("French: Comment ça va | Ma chérie");

            row = sheet1.createRow(1);
            cell   = row.createCell(0);
            cell.setCellValue("German: Tschüss, bis zum nächsten Mal | Ich weiß nicht");
            wookbook.write(fileOut);
        } catch(Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
