import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.util.Iterator;

import org.apache.poi.poifs.crypt.Decryptor;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadXLSXPassword {
    public static void main(String[] args) {

        // Creating a xlsx file object with specific file path to read
        File xlsxFile = new File("C:\\Users\\ntmanh\\Desktop\\check_password.xlsx");

        try {
            POIFSFileSystem fs = new POIFSFileSystem(xlsxFile);
            EncryptionInfo info = new EncryptionInfo(fs);
            Decryptor decryptor = Decryptor.getInstance(info);

            //Verifying the password
            if (!decryptor.verifyPassword("abc123")) {
                throw new RuntimeException("Incorrect password: Unable to process");
            }

            InputStream dataStream = decryptor.getDataStream(fs);

            // Now parse dataStream

            XSSFWorkbook workbook = new XSSFWorkbook(dataStream);
            // Reading the first sheet of the excel file
            Sheet sheet = workbook.getSheetAt(0);

            Iterator<Row> iterator = sheet.iterator();

            // Iterating all the rows
            while (iterator.hasNext()) {
                Row nextRow = iterator.next();
                Iterator<Cell> cellIterator = nextRow.cellIterator();

                // Iterating all the columns in a row
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    switch (cell.getCellType()) {
                        case STRING:
                            System.out.print(cell.getStringCellValue());
                            break;
                        case BOOLEAN:
                            System.out.print(cell.getBooleanCellValue());
                            break;
                        case NUMERIC:
                            System.out.print(cell.getNumericCellValue());
                            break;
                        default:
                            break;
                    }
                    System.out.print("  ");
                }
                System.out.println();
            }
            workbook.close();
        } catch (GeneralSecurityException | IOException ex) {
            throw new RuntimeException("Unable to process encrypted document", ex);
        }
    }
}
